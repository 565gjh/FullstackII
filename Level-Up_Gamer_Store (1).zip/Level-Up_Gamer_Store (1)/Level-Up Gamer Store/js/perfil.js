// carga los datos guardados del usuario y calcula su rango según los puntos que tenga
function cargarPerfil() {
    const usuario = JSON.parse(localStorage.getItem('usuarioPerfil'));

    if (!usuario) {
        document.getElementById('lblNombre').textContent = 'No registrado';
        return;
    }

    // Determinamos el rango según los puntos acumulados
    let rangoActual = 'Hierro 🛡️';
    if (usuario.puntos >= 1200) {
        rangoActual = 'Challenger 👑';
    } else if (usuario.puntos >= 600) {
        rangoActual = 'Platino 💎';
    } else if (usuario.puntos >= 200) {
        rangoActual = 'Oro 🪙';
    }

    document.getElementById('lblNombre').textContent = usuario.nombre || 'Invitado';
    document.getElementById('lblPuntos').textContent = usuario.puntos || 0;
    document.getElementById('lblNivel').textContent = rangoActual;
    document.getElementById('lblCodigoRef').textContent = 'REF-' + (usuario.nombre ? usuario.nombre.toUpperCase().slice(0, 4) : '2026');
    document.getElementById('editNombre').value = usuario.nombre || '';
}

// resta los puntos y entrega el premio, siempre que el usuario tenga suficientes puntos
function canjearPremio(costoPuntos, premio) {
    const usuario = JSON.parse(localStorage.getItem('usuarioPerfil'));
    const msgCanje = document.getElementById('mensajeCanje');

    if (!usuario) {
        msgCanje.style.color = '#ff4d4d';
        msgCanje.textContent = 'Debes registrarte primero para acumular y canjear puntos.';
        return;
    }

    if (usuario.puntos < costoPuntos) {
        msgCanje.style.color = '#ff4d4d';
        msgCanje.textContent = 'No tienes suficientes puntos LevelUp para este beneficio.';
        return;
    }

    usuario.puntos -= costoPuntos;

    // mismo cálculo de rango que usamos en cargarPerfil() y en eventos.js,
    // para que el nivel guardado no quede desactualizado tras el canje
    if (usuario.puntos >= 1200) {
        usuario.nivel = 'Challenger 👑';
    } else if (usuario.puntos >= 600) {
        usuario.nivel = 'Platino 💎';
    } else if (usuario.puntos >= 200) {
        usuario.nivel = 'Oro 🪙';
    } else {
        usuario.nivel = 'Hierro 🛡️';
    }

    localStorage.setItem('usuarioPerfil', JSON.stringify(usuario));

    msgCanje.style.color = '#39FF14';
    msgCanje.textContent = `¡Canje exitoso! Obtuviste: ${premio}.`;
    cargarPerfil();
}

document.getElementById('perfilForm').addEventListener('submit', function (e) {
    e.preventDefault();
    const usuario = JSON.parse(localStorage.getItem('usuarioPerfil')) || { puntos: 100 };
    usuario.nombre = document.getElementById('editNombre').value.trim();
    localStorage.setItem('usuarioPerfil', JSON.stringify(usuario));
    cargarPerfil();

    const msg = document.getElementById('mensajePerfil');
    msg.style.color = '#39FF14';
    msg.textContent = '¡Nombre actualizado con éxito!';
});

document.addEventListener('DOMContentLoaded', cargarPerfil);
