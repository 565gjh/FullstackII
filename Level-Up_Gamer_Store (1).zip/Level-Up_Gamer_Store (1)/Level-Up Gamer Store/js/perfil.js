// carga los datos guardados del usuario y calcula su rango según los puntos que tenga
document.addEventListener('DOMContentLoaded', function () {
    // Verificar el estado de la sesión en localStorage
    const sesionIniciada = localStorage.getItem('sesionIniciada');
    
    // Obtener los botones del header
    const navLogin = document.getElementById('navLogin');
    const navPerfil = document.getElementById('navPerfil');

    if (sesionIniciada === 'true') {
        // SI TIENE SESIÓN: Ocultar Iniciar Sesión, Mostrar Mi Perfil
        if (navLogin) navLogin.style.display = 'none';
        if (navPerfil) navPerfil.style.display = 'inline-block'; // Usa 'block' o 'flex' dependiendo de tu diseño
    } else {
        // SI NO TIENE SESIÓN: Mostrar Iniciar Sesión, Ocultar Mi Perfil
        if (navLogin) navLogin.style.display = 'inline-block';
        if (navPerfil) navPerfil.style.display = 'none';
    }
});
function cargarPerfil() {
    const usuario = JSON.parse(localStorage.getItem('usuarioPerfil'));

    if (!usuario) {
        document.getElementById('lblNombre').textContent = 'No registrado';
        return;
    }

    // Determinamos el rango según los puntos acumulados
    let rangoActual = 'Hierro 🛡️';
    if (usuario.puntos >= 1200) {
        rangoActual = 'Challenger 👑';
    } else if (usuario.puntos >= 600) {
        rangoActual = 'Platino 💎';
    } else if (usuario.puntos >= 200) {
        rangoActual = 'Oro 🪙';
    }

    document.getElementById('lblNombre').textContent = usuario.nombre || 'Invitado';
    document.getElementById('lblPuntos').textContent = usuario.puntos || 0;
    document.getElementById('lblNivel').textContent = rangoActual;
    document.getElementById('lblCodigoRef').textContent = 'REF-' + (usuario.nombre ? usuario.nombre.toUpperCase().slice(0, 4) : '2026');
    document.getElementById('editNombre').value = usuario.nombre || '';
}

// resta los puntos y entrega el premio, siempre que el usuario tenga suficientes puntos
function canjearPremio(costoPuntos, premio) {
    const usuario = JSON.parse(localStorage.getItem('usuarioPerfil'));
    const msgCanje = document.getElementById('mensajeCanje');

    if (!usuario) {
        msgCanje.style.color = '#ff4d4d';
        msgCanje.textContent = 'Debes registrarte primero para acumular y canjear puntos.';
        return;
    }

    if (usuario.puntos < costoPuntos) {
        msgCanje.style.color = '#ff4d4d';
        msgCanje.textContent = 'No tienes suficientes puntos LevelUp para este beneficio.';
        return;
    }

    usuario.puntos -= costoPuntos;

    // mismo cálculo de rango que usamos en cargarPerfil() y en eventos.js,
    // para que el nivel guardado no quede desactualizado tras el canje
    if (usuario.puntos >= 1200) {
        usuario.nivel = 'Challenger 👑';
    } else if (usuario.puntos >= 600) {
        usuario.nivel = 'Platino 💎';
    } else if (usuario.puntos >= 200) {
        usuario.nivel = 'Oro 🪙';
    } else {
        usuario.nivel = 'Hierro 🛡️';
    }

    localStorage.setItem('usuarioPerfil', JSON.stringify(usuario));

    msgCanje.style.color = '#39FF14';
    msgCanje.textContent = `¡Canje exitoso! Obtuviste: ${premio}.`;
    cargarPerfil();
}

document.getElementById('perfilForm').addEventListener('submit', function (e) {
    e.preventDefault();
    const usuario = JSON.parse(localStorage.getItem('usuarioPerfil')) || { puntos: 100 };
    usuario.nombre = document.getElementById('editNombre').value.trim();
    localStorage.setItem('usuarioPerfil', JSON.stringify(usuario));
    cargarPerfil();

    const msg = document.getElementById('mensajePerfil');
    msg.style.color = '#39FF14';
    msg.textContent = '¡Nombre actualizado con éxito!';
});

document.addEventListener('DOMContentLoaded', cargarPerfil);
document.addEventListener('DOMContentLoaded', function () {
    
    // 1. Obtener estados de localStorage
    const sesionIniciada = localStorage.getItem('sesionIniciada');
    const usuario = JSON.parse(localStorage.getItem('usuarioPerfil'));

    // 2. Obtener los contenedores HTML
    const vistaInvitado = document.getElementById('vistaInvitado');
    const vistaUsuario = document.getElementById('vistaUsuario');

    // 3. Lógica de visualización
    if (sesionIniciada === 'true' && usuario) {
        // SI INICIÓ SESIÓN: Mostramos sus datos y ocultamos el mensaje de invitado
        if (vistaInvitado) vistaInvitado.style.display = 'none';
        if (vistaUsuario) vistaUsuario.style.display = 'block';

        // Cargamos los datos en la pantalla
        document.getElementById('perfilNombre').textContent = usuario.nombre;
        document.getElementById('perfilCorreo').textContent = usuario.correo;
        document.getElementById('perfilNivel').textContent = usuario.nivel;
        document.getElementById('perfilPuntos').textContent = usuario.puntos + ' Puntos LevelUp';

    } else {
        // SI ES INVITADO: Se queda viendo el botón de iniciar sesión
        if (vistaInvitado) vistaInvitado.style.display = 'block';
        if (vistaUsuario) vistaUsuario.style.display = 'none';
    }

    // 4. Lógica para cerrar sesión (solo funciona si el botón está visible)
    const btnCerrarSesion = document.getElementById('btnCerrarSesion');
    if (btnCerrarSesion) {
        btnCerrarSesion.addEventListener('click', function () {
            // Cambiamos el estado de la sesión a falso
            localStorage.setItem('sesionIniciada', 'false');
            
            // Recargamos la página actual para que vuelva a la vista de "Invitado"
            window.location.reload();
        });
    }
});