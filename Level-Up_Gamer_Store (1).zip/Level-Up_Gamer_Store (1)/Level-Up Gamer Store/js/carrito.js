// pinta el carrito completo: si está vacío muestra el mensaje, si no,
// arma una fila por producto y calcula el total sumando cada subtotal
document.addEventListener('DOMContentLoaded', function () {
    // Verificar el estado de la sesión en localStorage
    const sesionIniciada = localStorage.getItem('sesionIniciada');
    
    // Obtener los botones del header
    const navLogin = document.getElementById('navLogin');
    const navPerfil = document.getElementById('navPerfil');

    if (sesionIniciada === 'true') {
        // SI TIENE SESIÓN: Ocultar Iniciar Sesión, Mostrar Mi Perfil
        if (navLogin) navLogin.style.display = 'none';
        if (navPerfil) navPerfil.style.display = 'inline-block'; // Usa 'block' o 'flex' dependiendo de tu diseño
    } else {
        // SI NO TIENE SESIÓN: Mostrar Iniciar Sesión, Ocultar Mi Perfil
        if (navLogin) navLogin.style.display = 'inline-block';
        if (navPerfil) navPerfil.style.display = 'none';
    }
});
function renderizarCarrito() {
    const carrito = JSON.parse(localStorage.getItem('carrito')) || [];
    const contenedor = document.getElementById('contenedorCarrito');
    const seccionTotal = document.getElementById('seccionTotal');
    const montoTotal = document.getElementById('montoTotal');

    if (carrito.length === 0) {
        contenedor.innerHTML = `
            <div class="cart-empty">
                <p>Tu carrito se encuentra vacío actualmente.</p>
                <a href="productos.html" class="btn-blue">Explorar Catálogo</a>
            </div>
        `;
        seccionTotal.style.display = 'none';
        return;
    }

    let sumaTotal = 0;
    let html = '';

    carrito.forEach((item, index) => {
        const subtotal = item.precio * item.cantidad;
        sumaTotal += subtotal;

        html += `
            <div class="cart-item">
                <div class="cart-item-info">
                    <h4>${item.nombre}</h4>
                    <span>$${item.precio.toLocaleString('es-CL')} CLP c/u</span>
                </div>
                <div class="cart-item-actions">
                    <div class="qty-controls">
                        <button onclick="cambiarCantidad(${index}, -1)" class="btn-qty" title="Restar unidad">-</button>
                        <span class="qty-tag">Cant: ${item.cantidad}</span>
                        <button onclick="cambiarCantidad(${index}, 1)" class="btn-qty" title="Sumar unidad">+</button>
                    </div>
                    <span class="item-subtotal">$${subtotal.toLocaleString('es-CL')}</span>
                    <button onclick="eliminarItem(${index})" class="btn-remove" title="Eliminar producto completo">✕</button>
                </div>
            </div>
        `;
    });

    contenedor.innerHTML = html;
    montoTotal.textContent = `$${sumaTotal.toLocaleString('es-CL')} CLP`;
    seccionTotal.style.display = 'block';
}

// suma o resta una unidad al producto. si llega a 0 directamente se saca del carrito
function cambiarCantidad(index, cambio) {
    const carrito = JSON.parse(localStorage.getItem('carrito')) || [];

    if (carrito[index]) {
        carrito[index].cantidad += cambio;

        if (carrito[index].cantidad <= 0) {
            carrito.splice(index, 1);
        }

        localStorage.setItem('carrito', JSON.stringify(carrito));
        actualizarContador();
        renderizarCarrito();
    }
}

function eliminarItem(index) {
    const carrito = JSON.parse(localStorage.getItem('carrito')) || [];
    carrito.splice(index, 1);
    localStorage.setItem('carrito', JSON.stringify(carrito));
    actualizarContador();
    renderizarCarrito();
}

// simula el pago: si no hay usuario registrado lo manda a crear perfil primero,
// si hay, vacía el carrito y lo redirige a su perfil
function procederPago() {
    const usuario = JSON.parse(localStorage.getItem('usuarioPerfil'));
    if (!usuario) {
        alert('Por favor, inicia sesión o regístrate en tu perfil para procesar tu orden.');
        window.location.href = 'perfil.html';
        return;
    }

    alert(`¡Compra procesada con éxito, ${usuario.nombre}! Revisa los detalles en tu perfil.`);
    localStorage.removeItem('carrito');
    actualizarContador();
    window.location.href = 'perfil.html';
}

document.addEventListener('DOMContentLoaded', renderizarCarrito);