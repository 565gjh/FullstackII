// se usa en todas las páginas para que el número del carrito del nav
// siempre esté al día, sin importar en qué página estés parado
function actualizarContador() {
    const carrito = JSON.parse(localStorage.getItem('carrito')) || [];
    const totalItems = carrito.reduce((sum, item) => sum + item.cantidad, 0);
    const enlace = document.getElementById('enlaceCarrito');
    if (enlace) {
        enlace.textContent = `Carrito (${totalItems})`;
    }
}

// abre WhatsApp con un mensaje ya armado, usando el nombre del perfil si existe
function abrirSoporteTecnico() {
    const telefono = "56912345678"; // número de contacto del soporte técnico
    const usuario = JSON.parse(localStorage.getItem('usuarioPerfil'));
    const nombreUsuario = usuario ? usuario.nombre : 'Cliente';
    const mensaje = encodeURIComponent(`Hola, soy ${nombreUsuario}. Necesito ayuda con el servicio técnico de Level-Up Gamer.`);
    window.open(`https://api.whatsapp.com/send?phone=${telefono}&text=${mensaje}`, '_blank');
}

// el contador del carrito se actualiza solo al cargar cualquier página
document.addEventListener('DOMContentLoaded', actualizarContador);
