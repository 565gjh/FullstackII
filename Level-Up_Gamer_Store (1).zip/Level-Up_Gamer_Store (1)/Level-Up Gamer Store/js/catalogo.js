// acá vive todo el catálogo. cada producto tiene su ícono/foto, categoría
// (para el filtro) y datos de fabricante/distribuidor que pide el caso
document.addEventListener('DOMContentLoaded', function () {
    // Verificar el estado de la sesión en localStorage
    const sesionIniciada = localStorage.getItem('sesionIniciada');
    
    // Obtener los botones del header
    const navLogin = document.getElementById('navLogin');
    const navPerfil = document.getElementById('navPerfil');

    if (sesionIniciada === 'true') {
        // SI TIENE SESIÓN: Ocultar Iniciar Sesión, Mostrar Mi Perfil
        if (navLogin) navLogin.style.display = 'none';
        if (navPerfil) navPerfil.style.display = 'inline-block'; // Usa 'block' o 'flex' dependiendo de tu diseño
    } else {
        // SI NO TIENE SESIÓN: Mostrar Iniciar Sesión, Ocultar Mi Perfil
        if (navLogin) navLogin.style.display = 'inline-block';
        if (navPerfil) navPerfil.style.display = 'none';
    }
});
const productosOficiales = [
    {
        codigo: "JM001", categoria: "Juegos de Mesa", nombre: "Catan", precio: 29990,
        icono: "img/catannew.png",
        descripcion: "Un clásico juego de estrategia donde los jugadores compiten por colonizar y expandirse en la isla de Catan. Ideal para 3-4 jugadores y perfecto para noches de juego en familia o con amigos.",
        fabricante: "KOSMOS / Devir", distribuidor: "Devir Chile"
    },
    {
        codigo: "JM002", categoria: "Juegos de Mesa", nombre: "Carcassonne", precio: 24990,
        icono: "img/images.jpg",
        descripcion: "Un juego de colocación de fichas donde los jugadores construyen el paisaje alrededor de la fortaleza medieval de Carcassonne. Ideal para 2-5 jugadores y fácil de aprender.",
        fabricante: "Hans im Glück / Devir", distribuidor: "Devir Chile"
    },
    {
        codigo: "AC001", categoria: "Accesorios", nombre: "Controlador Inalámbrico Xbox Series X", precio: 59990,
        icono: "img/controlxboxsx.png",
        descripcion: "Ofrece una experiencia de juego cómoda con botones mapeables y una respuesta táctil mejorada. Compatible con consolas Xbox y PC.",
        fabricante: "Microsoft", distribuidor: "Distribuidores Oficiales Latam"
    },
    {
        codigo: "AC002", categoria: "Accesorios", nombre: "Auriculares Gamer HyperX Cloud II", precio: 79990,
        icono: "img/hyperxcloudii.avif",
        descripcion: "Proporcionan un sonido envolvente de calidad con un micrófono desmontable y almohadillas de espuma viscoelástica para mayor comodidad durante largas sesiones de juego.",
        fabricante: "HP / HyperX", distribuidor: "HyperX Chile"
    },
    {
        codigo: "CO001", categoria: "Consolas", nombre: "PlayStation 5", precio: 549900,
        icono: "img/ps5-product.webp",
        descripcion: " La consola de última generación de Sony, que ofrece gráficos impresionantes y tiempos de carga ultrarrápidos para una experiencia de juego inmersiva.",
        fabricante: "Sony Interactive Entertainment", distribuidor: "Sony Chile / Microplay"
    },
    {
        codigo: "CG001", categoria: "Computadores Gamers", nombre: "PC Gamer ASUS ROG Strix", precio: 1299900,
        icono: "img/h732.png",
        descripcion: "Un potente equipo diseñado para los gamers más exigentes, equipado con los últimos componentes para ofrecer un rendimiento excepcional en cualquier juego.",
        fabricante: "ASUS / Republic of Gamers", distribuidor: "ASUS Chile / Ingram Micro"
    },
    {
        codigo: "SG001", categoria: "Sillas Gamers", nombre: "Silla Gamer Secretlab Titan", precio: 349900,
        icono: "img/teamsecret-titanevo.webp",
        descripcion: "Diseñada para el máximo confort, esta silla ofrece un soporte ergonómico y personalización ajustable para sesiones de juego prolongadas.",
        fabricante: "Secretlab", distribuidor: "ErgoGamer Corp Latam"
    },
    {
        codigo: "MS001", categoria: "Mouse", nombre: "Mouse Gamer Logitech G502 HERO", precio: 49990,
        icono: "img/640.webp",
        descripcion: "Con sensor de alta precisión y botones personalizables, este mouse es ideal para gamers que buscan un control preciso y personalización.",
        fabricante: "Logitech G", distribuidor: "Logitech Chile"
    },
    {
        codigo: "MP001", categoria: "Mousepad", nombre: "Mousepad Razer Goliathus Extended Chroma", precio: 29990,
        icono: "img/razer67.png",
        descripcion: "Ofrece un área de juego amplia con iluminación RGB personalizable, asegurando una superficie suave y uniforme para el movimiento del mouse.",
        fabricante: "Razer", distribuidor: "Razer Official Distributor"
    },
    {
        codigo: "PP001", categoria: "Poleras Personalizadas", nombre: "Polera Gamer Personalizada 'Level-Up'", precio: 14990,
        icono: "img/3041941_01.webp",
        descripcion: "Una camiseta cómoda y estilizada, con la posibilidad de personalizarla con tu gamer tag o diseño favorito.",
        fabricante: "Level-Up Custom Textiles", distribuidor: "Taller Gráfico Propio (Melipilla)"
    }
];

// dibuja las tarjetas de producto en el grid. recibe la lista ya filtrada
// (o el catálogo completo) y arma el HTML de cada card
function renderizarProductos(lista) {
    const grid = document.getElementById('gridCatalogo');
    grid.innerHTML = '';

    lista.forEach(item => {
        const card = document.createElement('div');
        card.className = 'card';
        card.innerHTML = `
            <div>
                <img src="${item.icono}" alt="Ícono de categoría ${item.categoria}" class="card-icon">
                <span class="card-tag">[${item.codigo}] ${item.categoria}</span>
                <h3>${item.nombre}</h3>
                <p class="desc">${item.descripcion}</p>
                <div class="card-origen">
                    <p><strong>Fabricante:</strong> ${item.fabricante}</p>
                    <p><strong>Distribuidor:</strong> ${item.distribuidor}</p>
                </div>
            </div>
            <div>
                <div class="precio">$${item.precio.toLocaleString('es-CL')} CLP</div>
                <button class="btn-blue" onclick="agregarAlCarrito('${item.codigo}')">Añadir al Carrito</button>
            </div>
        `;
        grid.appendChild(card);
    });
}

// filtra el catálogo por categoría y deja marcado (visualmente) el botón que se apretó
function filtrarCategoria(categoria, boton) {
    document.querySelectorAll('.filtro-btn').forEach(b => b.classList.remove('activo'));
    boton.classList.add('activo');

    if (categoria === 'todos') {
        renderizarProductos(productosOficiales);
    } else {
        renderizarProductos(productosOficiales.filter(p => p.categoria === categoria));
    }
}

function agregarAlCarrito(codigo) {
    const producto = productosOficiales.find(p => p.codigo === codigo);
    if (!producto) return;

    const carrito = JSON.parse(localStorage.getItem('carrito')) || [];
    const index = carrito.findIndex(item => item.codigo === codigo);

    // si el producto ya estaba en el carrito solo le sumamos 1, si no, se agrega nuevo
    if (index !== -1) {
        carrito[index].cantidad += 1;
    } else {
        carrito.push({ codigo: producto.codigo, nombre: producto.nombre, precio: producto.precio, cantidad: 1 });
    }

    localStorage.setItem('carrito', JSON.stringify(carrito));
    actualizarContador();
    alert(`"${producto.nombre}" se agregó al carrito.`);
}

document.addEventListener('DOMContentLoaded', () => {
    renderizarProductos(productosOficiales);

    // en vez de un onclick por cada botón de filtro, se escucha el click una sola vez
    // en el contenedor y se revisa qué botón fue (delegación de eventos)
    document.getElementById('filtrosLista').addEventListener('click', (e) => {
        if (e.target.classList.contains('filtro-btn')) {
            filtrarCategoria(e.target.dataset.cat, e.target);
        }
    });
});
