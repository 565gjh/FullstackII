function realizarCheckIn(nombreEvento, puntos) {
    const usuario = JSON.parse(localStorage.getItem('usuarioPerfil'));

    if (!usuario) {
        alert('Debes registrarte o iniciar sesión en la página de inicio para acumular puntos por tus check-ins.');
        window.location.href = 'index.html';
        return;
    }

    usuario.puntos += puntos;

    // Actualizamos el nivel según los nuevos rangos
    if (usuario.puntos >= 1200) {
        usuario.nivel = 'Challenger 👑';
    } else if (usuario.puntos >= 600) {
        usuario.nivel = 'Platino 💎';
    } else if (usuario.puntos >= 200) {
        usuario.nivel = 'Oro 🪙';
    } else {
        usuario.nivel = 'Hierro 🛡️';
    }

    localStorage.setItem('usuarioPerfil', JSON.stringify(usuario));
    alert(`¡Check-in realizado con éxito en "${nombreEvento}"! Has ganado +${puntos} Puntos LevelUp.`);
}