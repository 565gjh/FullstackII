document.addEventListener('DOMContentLoaded', function () {
    // Verificar el estado de la sesión en localStorage
    const sesionIniciada = localStorage.getItem('sesionIniciada');
    
    // Obtener los botones del header
    const navLogin = document.getElementById('navLogin');
    const navPerfil = document.getElementById('navPerfil');

    if (sesionIniciada === 'true') {
        // SI TIENE SESIÓN: Ocultar Iniciar Sesión, Mostrar Mi Perfil
        if (navLogin) navLogin.style.display = 'none';
        if (navPerfil) navPerfil.style.display = 'inline-block'; // Usa 'block' o 'flex' dependiendo de tu diseño
    } else {
        // SI NO TIENE SESIÓN: Mostrar Iniciar Sesión, Ocultar Mi Perfil
        if (navLogin) navLogin.style.display = 'inline-block';
        if (navPerfil) navPerfil.style.display = 'none';
    }
});
function realizarCheckIn(nombreEvento, puntos) {
    const usuario = JSON.parse(localStorage.getItem('usuarioPerfil'));

    if (!usuario) {
        alert('Debes registrarte o iniciar sesión en la página de inicio para acumular puntos por tus check-ins.');
        window.location.href = 'index.html';
        return;
    }

    usuario.puntos += puntos;

    // Actualizamos el nivel según los nuevos rangos
    if (usuario.puntos >= 1200) {
        usuario.nivel = 'Challenger 👑';
    } else if (usuario.puntos >= 600) {
        usuario.nivel = 'Platino 💎';
    } else if (usuario.puntos >= 200) {
        usuario.nivel = 'Oro 🪙';
    } else {
        usuario.nivel = 'Hierro 🛡️';
    }

    localStorage.setItem('usuarioPerfil', JSON.stringify(usuario));
    alert(`¡Check-in realizado con éxito en "${nombreEvento}"! Has ganado +${puntos} Puntos LevelUp.`);
}