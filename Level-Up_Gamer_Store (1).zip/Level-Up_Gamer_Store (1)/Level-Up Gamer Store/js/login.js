// login.js
const loginForm = document.getElementById('loginForm');

if (loginForm) {
    loginForm.addEventListener('submit', function (e) {
        e.preventDefault(); // Evita que la página se recargue

        const correoIngresado = document.getElementById('correoLogin').value.trim();
        const passwordIngresada = document.getElementById('passwordLogin').value;
        const msg = document.getElementById('mensajeErrorLogin');

        // 1. Obtener los datos del usuario que se guardaron en el registro
        const usuarioGuardado = JSON.parse(localStorage.getItem('usuarioPerfil'));

        // 2. Verificar si el usuario existe y si los datos coinciden
        if (usuarioGuardado && usuarioGuardado.correo === correoIngresado && usuarioGuardado.password === passwordIngresada) {
            
            // Credenciales correctas: Iniciar sesión
            localStorage.setItem('sesionIniciada', 'true');
            
            msg.style.color = '#4ade80'; // Verde de éxito
            msg.textContent = '¡Inicio de sesión exitoso! Entrando a tu cuenta...';
            
            // Redirigir al perfil después de 1.5 segundos
            setTimeout(() => {
                window.location.href = 'perfil.html';
            }, 1500);

        } else {
            // Credenciales incorrectas o usuario no registrado
            msg.style.color = '#ef4444'; // Rojo de error
            msg.textContent = 'Correo o contraseña incorrectos. Intenta de nuevo.';
        }
    });
}

document.addEventListener('DOMContentLoaded', function () {
    const sesionIniciada = localStorage.getItem('sesionIniciada');
    const usuario = JSON.parse(localStorage.getItem('usuarioPerfil'));

    const vistaInvitado = document.getElementById('vistaInvitado');
    const vistaUsuario = document.getElementById('vistaUsuario');

    if (sesionIniciada === 'true' && usuario) {
        // Mostrar contenedor de usuario y ocultar de invitado
        if (vistaInvitado) vistaInvitado.style.display = 'none';
        if (vistaUsuario) vistaUsuario.style.display = 'block';

        // Inyectar datos en el HTML
        document.getElementById('perfilNombre').textContent = usuario.nombre;
        document.getElementById('perfilCorreo').textContent = usuario.correo;
        document.getElementById('perfilNivel').textContent = usuario.nivel;
        document.getElementById('perfilPuntos').textContent = `${usuario.puntos} Puntos LevelUp`;

    } else {
        // Mostrar vista de invitado si no hay sesión
        if (vistaInvitado) vistaInvitado.style.display = 'block';
        if (vistaUsuario) vistaUsuario.style.display = 'none';
    }

    // Botón de Cerrar Sesión
    const btnCerrarSesion = document.getElementById('btnCerrarSesion');
    if (btnCerrarSesion) {
        btnCerrarSesion.addEventListener('click', function () {
            localStorage.setItem('sesionIniciada', 'false');
            window.location.reload(); // Recarga para volver a la vista de invitado
        });
    }
});