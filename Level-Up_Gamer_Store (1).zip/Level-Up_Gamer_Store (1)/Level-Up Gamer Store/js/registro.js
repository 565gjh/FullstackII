// Esperar a que todo el HTML cargue
document.addEventListener('DOMContentLoaded', function () {
    const registroForm = document.getElementById('registroForm');
    
    if (!registroForm) {
        console.error("ERROR: No se encontró el formulario con id='registroForm'.");
        return;
    }

    console.log("Formulario de registro detectado correctamente.");

    registroForm.addEventListener('submit', function (e) {
        e.preventDefault(); // Evita que la página recargue

        try {
            // 1. Capturar los valores (Asegúrate de que estos IDs existan en tu HTML)
            const nombre = document.getElementById('nombre').value.trim();
            const correo = document.getElementById('correo').value.trim();
            const password = document.getElementById('password').value;
            const edad = parseInt(document.getElementById('edad').value);
            
            // El referido puede estar vacío
            const referidoInput = document.getElementById('referido');
            const codigoRef = referidoInput ? referidoInput.value.trim() : "";
            
            const msg = document.getElementById('mensajeError');

            console.log("Datos capturados:", { nombre, correo, password, edad });

            // 2. Validar edad mínima
            if (edad < 18) {
                msg.style.color = '#ef4444';
                msg.textContent = 'Debes ser mayor de 18 años para registrarte.';
                return;
            }

            // 3. Calcular Puntos e incentivos
            let puntosIniciales = 100;
            if (codigoRef !== "") {
                puntosIniciales += 50; 
            }

            let nivelInicial = 'Hierro 🛡️';
            if (puntosIniciales >= 200) {
                nivelInicial = 'Oro 🪙';
            }

            // 4. Crear el objeto con las credenciales
            const datosUsuario = {
                nombre: nombre,
                correo: correo,
                password: password,
                puntos: puntosIniciales,
                nivel: nivelInicial
            };

            // 5. Guardar en localStorage
            localStorage.setItem('usuarioPerfil', JSON.stringify(datosUsuario));
            localStorage.setItem('sesionIniciada', 'false');
            
            console.log("¡Datos guardados en LocalStorage exitosamente!");

            // 6. Feedback visual
            msg.style.color = '#4ade80';
            msg.textContent = '¡Cuenta creada con éxito! Redirigiendo al inicio de sesión...';

            // 7. Redirigir
            setTimeout(() => {
                window.location.href = 'login.html';
            }, 2000);

        } catch (error) {
            console.error("Hubo un error al procesar el registro:", error);
            alert("Error en el formulario. Revisa la consola para más detalles.");
        }
    });
});