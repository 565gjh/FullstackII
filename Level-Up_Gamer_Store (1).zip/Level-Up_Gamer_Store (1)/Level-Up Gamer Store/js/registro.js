function verificarRecomendaciones() {
    const usuario = JSON.parse(localStorage.getItem('usuarioPerfil'));
    const seccion = document.getElementById('seccionRecomendaciones');
    const grid = document.getElementById('gridRecomendaciones');

    if (!usuario) {
        seccion.style.display = 'none';
        return;
    }

    seccion.style.display = 'block';
    grid.innerHTML = `
        <div class="mini-card">
            <h4>PC Gamer ASUS ROG Strix</h4>
            <p class="mini-price">$1.299.900 CLP</p>
            <a href="productos.html">Ver detalles →</a>
        </div>
        <div class="mini-card">
            <h4>Auriculares Gamer HyperX Cloud II</h4>
            <p class="mini-price">$79.990 CLP</p>
            <a href="productos.html">Ver detalles →</a>
        </div>
        <div class="mini-card">
            <h4>Silla Gamer Secretlab Titan</h4>
            <p class="mini-price">$349.900 CLP</p>
            <a href="productos.html">Ver detalles →</a>
        </div>
    `;
}

document.getElementById('registroForm').addEventListener('submit', function (e) {
    e.preventDefault();

    const nombre = document.getElementById('nombre').value.trim();
    const correo = document.getElementById('correo').value.trim();
    const edad = parseInt(document.getElementById('edad').value);
    const codigoRef = document.getElementById('referido').value.trim();
    const msg = document.getElementById('mensajeError');

    if (edad < 18) {
        msg.style.color = '#ef4444';
        msg.textContent = 'Acceso restringido: debes ser mayor de 18 años para registrarte.';
        return;
    }

    let puntosIniciales = 100;
    if (codigoRef !== "") {
        puntosIniciales += 50;
    }

    // Calcular nivel inicial según los nuevos rangos
    let nivelInicial = 'Hierro 🛡️';
    if (puntosIniciales >= 1200) {
        nivelInicial = 'Challenger 👑';
    } else if (puntosIniciales >= 600) {
        nivelInicial = 'Platino 💎';
    } else if (puntosIniciales >= 200) {
        nivelInicial = 'Oro 🪙';
    }

    const datosUsuario = {
        nombre: nombre,
        correo: correo,
        puntos: puntosIniciales,
        nivel: nivelInicial
    };
    
    localStorage.setItem('usuarioPerfil', JSON.stringify(datosUsuario));

    let mensajeExito = `¡Registro exitoso! +${puntosIniciales} Puntos LevelUp ganados.`;
    if (codigoRef) mensajeExito += ' (bonus por referido aplicado).';

    if (correo.endsWith('@duocuc.cl') || correo.endsWith('@duoc.cl')) {
        msg.style.color = 'var(--accent-blue)';
        mensajeExito += ' ¡20% de descuento de por vida activado!';
    } else {
        msg.style.color = 'var(--accent-green)';
    }

    msg.textContent = mensajeExito;
    document.getElementById('registroForm').reset();
    verificarRecomendaciones();
});

document.addEventListener('DOMContentLoaded', verificarRecomendaciones);