const consejoPorDefecto = { autor: 'AlexPro', texto: 'Para juegos de mundo abierto pesados, instala el juego en un SSD NVMe para evitar tirones de carga.' };

function cargarConsejos() {
    const consejos = JSON.parse(localStorage.getItem('consejosComunidad')) || [consejoPorDefecto];
    const contenedor = document.getElementById('contenedorConsejosDinamicos');
    contenedor.innerHTML = '';

    consejos.forEach((c, index) => {
        contenedor.innerHTML += `
            <div class="comment-card">
                <div>
                    <strong>${c.autor}:</strong>
                    <p>${c.texto}</p>
                </div>
                <button onclick="eliminarConsejo(${index})" class="btn-remove" title="Eliminar">✕</button>
            </div>
        `;
    });
}

function eliminarConsejo(index) {
    const consejos = JSON.parse(localStorage.getItem('consejosComunidad')) || [];
    consejos.splice(index, 1);
    localStorage.setItem('consejosComunidad', JSON.stringify(consejos));
    cargarConsejos();
}

document.getElementById('foroForm').addEventListener('submit', function (e) {
    e.preventDefault();
    const autor = document.getElementById('autorConsejo').value.trim();
    const texto = document.getElementById('textoConsejo').value.trim();
    if (!autor || !texto) return;

    const consejos = JSON.parse(localStorage.getItem('consejosComunidad')) || [consejoPorDefecto];
    consejos.unshift({ autor, texto });
    localStorage.setItem('consejosComunidad', JSON.stringify(consejos));

    this.reset();
    cargarConsejos();
});

document.addEventListener('DOMContentLoaded', () => {
    cargarConsejos();
    const usuario = JSON.parse(localStorage.getItem('usuarioPerfil'));
    if (usuario && usuario.nombre) {
        document.getElementById('autorConsejo').value = usuario.nombre;
    }
});
