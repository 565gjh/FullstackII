// Pruebas de funciones puras (utils): no necesitan DOM, solo entradas y salidas.
import { formatearPrecio } from '../utils/formato.js'
import { calcularNivel } from '../utils/niveles.js'
import { leerGuardado, guardar } from '../utils/almacenamiento.js'
import { eventoFinalizado } from '../utils/eventos.js'
import { recomendarProductos } from '../utils/recomendaciones.js'
import { catan, carcassonne, mouse, agotado } from './datos-prueba.js'

describe('formatearPrecio', () => {
  it('usa separador de miles chileno y termina en CLP', () => {
    const texto = formatearPrecio(29990)
    expect(texto).toContain('29.990')
    expect(texto.endsWith('CLP')).toBeTrue()
  })

  it('formatea el cero', () => {
    expect(formatearPrecio(0)).toContain('0')
  })
})

describe('calcularNivel (límites de cada rango)', () => {
  it('asigna Hierro bajo 200 puntos', () => {
    expect(calcularNivel(0)).toContain('Hierro')
    expect(calcularNivel(199)).toContain('Hierro')
  })

  it('sube de rango exactamente en 200, 600 y 1200', () => {
    expect(calcularNivel(200)).toContain('Oro')
    expect(calcularNivel(600)).toContain('Platino')
    expect(calcularNivel(1200)).toContain('Challenger')
  })
})

describe('almacenamiento (localStorage)', () => {
  it('devuelve el valor por defecto si la clave no existe', () => {
    expect(leerGuardado('no-existe', 'por-defecto')).toBe('por-defecto')
  })

  it('guarda y vuelve a leer un objeto', () => {
    guardar('prueba', { a: 1 })
    expect(leerGuardado('prueba', null)).toEqual({ a: 1 })
  })

  it('devuelve el valor por defecto si el JSON guardado está dañado', () => {
    localStorage.setItem('dañado', '{esto no es json')
    expect(leerGuardado('dañado', [])).toEqual([])
  })

  // MOCK: spyOn reemplaza temporalmente el método real para simular un navegador sin espacio.
  it('no lanza error si localStorage falla al guardar', () => {
    spyOn(Storage.prototype, 'setItem').and.throwError('almacenamiento lleno')
    expect(() => guardar('x', 1)).not.toThrow()
  })

  it('devuelve el valor por defecto si localStorage falla al leer', () => {
    spyOn(Storage.prototype, 'getItem').and.throwError('bloqueado')
    expect(leerGuardado('x', 'seguro')).toBe('seguro')
  })
})

describe('eventoFinalizado', () => {
  const hoy = new Date('2026-10-21T10:00:00')

  it('es false si el evento no tiene fecha', () => {
    expect(eventoFinalizado({}, hoy)).toBeFalse()
  })

  it('es true si la fecha de término ya pasó', () => {
    expect(eventoFinalizado({ fechaFin: '2026-10-04' }, hoy)).toBeTrue()
  })

  it('es false el mismo día del término y en fechas futuras', () => {
    expect(eventoFinalizado({ fechaFin: '2026-10-21' }, hoy)).toBeFalse()
    expect(eventoFinalizado({ fechaFin: '2026-12-10' }, hoy)).toBeFalse()
  })
})

describe('recomendarProductos', () => {
  const catalogo = [catan, carcassonne, mouse]

  it('sin carrito entrega un producto por categoría (destacados)', () => {
    const { motivo, productos } = recomendarProductos(catalogo, [])
    expect(motivo).toBe('destacados')
    expect(productos.map((p) => p.id)).toEqual([1, 8])
  })

  it('con carrito prioriza la misma categoría y excluye lo que ya está en el carrito', () => {
    const { motivo, productos } = recomendarProductos(catalogo, [{ ...catan, cantidad: 1 }])
    expect(motivo).toBe('afines')
    expect(productos.map((p) => p.id)).toEqual([2, 8])
  })

  it('excluye los productos sin stock', () => {
    const { productos } = recomendarProductos([agotado, ...catalogo], [])
    expect(productos.some((p) => p.id === agotado.id)).toBeFalse()
  })

  it('respeta el máximo pedido', () => {
    const { productos } = recomendarProductos(catalogo, [], 1)
    expect(productos.length).toBe(1)
  })
})
