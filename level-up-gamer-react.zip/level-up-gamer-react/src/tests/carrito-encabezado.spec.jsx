// Pruebas del carrito (panel lateral), el encabezado y componentes pequeños.
import { render, screen, fireEvent } from '@testing-library/react'
import Carrito from '../components/Carrito.jsx'
import Encabezado from '../components/Encabezado.jsx'
import Portada from '../components/Portada.jsx'
import Aviso from '../components/Aviso.jsx'
import BotonSoporte from '../components/BotonSoporte.jsx'
import PiePagina from '../components/PiePagina.jsx'
import contacto from '../data/contacto.js'
import { catan, mouse } from './datos-prueba.js'

describe('Carrito', () => {
  function dibujar(items) {
    const props = {
      mostrar: true,
      onCerrar: jasmine.createSpy('onCerrar'),
      items,
      onCambiarCantidad: jasmine.createSpy('onCambiarCantidad'),
      onQuitar: jasmine.createSpy('onQuitar'),
      onVaciar: jasmine.createSpy('onVaciar'),
      onPagar: jasmine.createSpy('onPagar'),
    }
    render(<Carrito {...props} />)
    return props
  }

  it('muestra el mensaje de carrito vacío', () => {
    dibujar([])
    expect(screen.getByText('Tu carrito se encuentra vacío actualmente.')).toBeTruthy()
  })

  it('calcula el total sumando precio × cantidad de cada producto', () => {
    // 29.990 × 2 + 49.990 × 1 = 109.970
    dibujar([
      { ...catan, cantidad: 2 },
      { ...mouse, cantidad: 1 },
    ])
    expect(screen.getByText(/109\.970/)).toBeTruthy()
  })

  it('los botones + y − avisan con el id y el cambio (+1 / −1)', () => {
    const props = dibujar([{ ...catan, cantidad: 2 }])
    fireEvent.click(screen.getByLabelText('Sumar una unidad de Catan'))
    fireEvent.click(screen.getByLabelText('Restar una unidad de Catan'))
    expect(props.onCambiarCantidad.calls.allArgs()).toEqual([
      [1, 1],
      [1, -1],
    ])
  })

  it('bloquea el botón + cuando se llega al stock disponible', () => {
    dibujar([{ ...catan, cantidad: 10 }]) // stock de catan = 10
    expect(screen.getByLabelText('Sumar una unidad de Catan').disabled).toBeTrue()
    expect(screen.getByText('Máximo disponible')).toBeTruthy()
  })

  it('mantiene activo el botón + si aún hay stock', () => {
    dibujar([{ ...catan, cantidad: 2 }])
    expect(screen.getByLabelText('Sumar una unidad de Catan').disabled).toBeFalse()
    expect(screen.queryByText('Máximo disponible')).toBeNull()
  })

  it('permite quitar un producto, vaciar el carrito y pagar', () => {
    const props = dibujar([{ ...catan, cantidad: 1 }])
    fireEvent.click(screen.getByLabelText('Quitar Catan del carrito'))
    fireEvent.click(screen.getByText('Vaciar carrito'))
    fireEvent.click(screen.getByText('Proceder al Pago'))
    expect(props.onQuitar).toHaveBeenCalledWith(1)
    expect(props.onVaciar).toHaveBeenCalled()
    expect(props.onPagar).toHaveBeenCalled()
  })
})

describe('Encabezado', () => {
  const base = { pagina: 'inicio', sesionIniciada: false, cantidad: 0, onVerCarrito: () => {} }

  it('muestra la cantidad de productos del carrito en la insignia', () => {
    render(<Encabezado {...base} cantidad={3} />)
    expect(screen.getByText('3')).toBeTruthy()
  })

  it('sin sesión ofrece "Iniciar Sesión"; con sesión, "Mi Perfil"', () => {
    const { unmount } = render(<Encabezado {...base} />)
    expect(screen.getByText('Iniciar Sesión')).toBeTruthy()
    expect(screen.queryByText('Mi Perfil')).toBeNull()
    unmount()

    render(<Encabezado {...base} sesionIniciada />)
    expect(screen.getByText('Mi Perfil')).toBeTruthy()
    expect(screen.queryByText('Iniciar Sesión')).toBeNull()
  })

  it('marca como activo el enlace de la página abierta', () => {
    render(<Encabezado {...base} pagina="catalogo" />)
    expect(screen.getByText('Catálogo').className).toContain('active')
  })

  it('el botón del carrito ejecuta onVerCarrito', () => {
    const onVerCarrito = jasmine.createSpy('onVerCarrito')
    render(<Encabezado {...base} onVerCarrito={onVerCarrito} />)
    fireEvent.click(screen.getByRole('button', { name: /^🛒 Carrito/ }))
    expect(onVerCarrito).toHaveBeenCalled()
  })
})

describe('Encabezado · lupa de búsqueda', () => {
  function dibujar(pagina, buscadorExtra = {}) {
    const buscador = {
      texto: '',
      onCambiarTexto: jasmine.createSpy('onCambiarTexto'),
      categoria: 'Todas',
      onCambiarCategoria: () => {},
      categorias: ['Mouse'],
      ...buscadorExtra,
    }
    render(
      <Encabezado pagina={pagina} sesionIniciada={false} cantidad={0} onVerCarrito={() => {}} buscador={buscador} />,
    )
    return buscador
  }

  it('no muestra la lupa fuera del catálogo', () => {
    dibujar('inicio')
    expect(screen.queryByLabelText('Buscar productos')).toBeNull()
  })

  it('en el catálogo muestra la lupa y la barra parte cerrada', () => {
    dibujar('catalogo')
    expect(screen.getByLabelText('Buscar productos')).toBeTruthy()
    expect(screen.queryByLabelText('Buscar producto por nombre')).toBeNull()
  })

  it('al tocar la lupa se abre la barra y escribir avisa al padre', () => {
    const buscador = dibujar('catalogo')
    fireEvent.click(screen.getByLabelText('Buscar productos'))
    fireEvent.change(screen.getByLabelText('Buscar producto por nombre'), { target: { value: 'ps5' } })
    expect(buscador.onCambiarTexto).toHaveBeenCalledWith('ps5')
  })

  it('con un filtro activo la barra se muestra sola', () => {
    dibujar('catalogo', { texto: 'ps5' })
    expect(screen.getByLabelText('Buscar producto por nombre').value).toBe('ps5')
  })
})

describe('PiePagina (contacto y redes)', () => {
  it('muestra el correo y el teléfono de contacto', () => {
    render(<PiePagina />)
    expect(screen.getByText(contacto.email).getAttribute('href')).toBe(`mailto:${contacto.email}`)
    expect(screen.getByText(contacto.telefono)).toBeTruthy()
  })

  it('muestra un enlace por cada red social, abriendo en pestaña segura', () => {
    render(<PiePagina />)
    contacto.redes.forEach((red) => {
      const enlace = screen.getByLabelText(`${red.nombre} de Level-Up Gamer`)
      expect(enlace.getAttribute('href')).toBe(red.url)
      expect(enlace.getAttribute('rel')).toContain('noopener')
      expect(enlace.getAttribute('target')).toBe('_blank')
    })
  })
})

describe('Portada', () => {
  it('muestra título, texto y contenido hijo', () => {
    render(
      <Portada titulo="Hola" texto="Texto de portada">
        <button>Extra</button>
      </Portada>,
    )
    expect(screen.getByRole('heading', { name: 'Hola' })).toBeTruthy()
    expect(screen.getByText('Texto de portada')).toBeTruthy()
    expect(screen.getByText('Extra')).toBeTruthy()
  })

  it('solo dibuja la imagen si se entrega una', () => {
    const { unmount } = render(<Portada titulo="A" texto="B" />)
    expect(screen.queryByRole('img')).toBeNull()
    unmount()
    render(<Portada titulo="A" texto="B" imagen="data:image/gif;base64,R0lGODlhAQABAAAAACw=" altImagen="Logo" />)
    expect(screen.getByAltText('Logo')).toBeTruthy()
  })
})

describe('Aviso (mensaje emergente)', () => {
  it('muestra el texto y permite cerrarlo', () => {
    const onCerrar = jasmine.createSpy('onCerrar')
    render(<Aviso aviso={{ id: 1, texto: 'Listo', variante: 'success' }} onCerrar={onCerrar} />)
    expect(screen.getByText('Listo')).toBeTruthy()
    fireEvent.click(screen.getByLabelText('Cerrar aviso'))
    expect(onCerrar).toHaveBeenCalled()
  })

  it('no muestra nada cuando el aviso es null', () => {
    render(<Aviso aviso={null} onCerrar={() => {}} />)
    expect(screen.queryByLabelText('Cerrar aviso')).toBeNull()
  })
})

describe('BotonSoporte', () => {
  it('abre WhatsApp con el nombre del usuario (window.open simulado)', () => {
    const abrir = spyOn(window, 'open') // mock: no abre una pestaña real
    render(<BotonSoporte nombreUsuario="Ana" />)
    fireEvent.click(screen.getByRole('button', { name: /Soporte Técnico/ }))
    const [url, destino, opciones] = abrir.calls.mostRecent().args
    expect(url).toContain('api.whatsapp.com')
    expect(url).toContain(encodeURIComponent('soy Ana'))
    expect(destino).toBe('_blank')
    expect(opciones).toBe('noopener,noreferrer')
  })
})
