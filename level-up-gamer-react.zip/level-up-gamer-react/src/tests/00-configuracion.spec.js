// Configuración global de Jasmine: los hooks de nivel superior se aplican a TODAS las pruebas.
// Después de cada prueba se desmonta lo dibujado y se deja limpio el navegador,
// para que ninguna prueba dependa del resultado de otra (Jasmine las ejecuta en orden aleatorio).
import { cleanup } from '@testing-library/react'

afterEach(() => {
  cleanup()
  localStorage.clear()
  window.location.hash = ''
})
