// Pruebas de los componentes del catálogo: props, eventos y renderizado condicional.
import { render, screen, fireEvent } from '@testing-library/react'
import TarjetaProducto from '../components/TarjetaProducto.jsx'
import Catalogo from '../components/Catalogo.jsx'
import Buscador from '../components/Buscador.jsx'
import Recomendaciones from '../components/Recomendaciones.jsx'
import { catan, carcassonne, mouse, agotado } from './datos-prueba.js'

describe('TarjetaProducto', () => {
  it('muestra nombre, precio, fabricante y distribuidor recibidos por props', () => {
    render(<TarjetaProducto producto={catan} onAgregar={() => {}} />)
    expect(screen.getByText('Catan')).toBeTruthy()
    expect(screen.getByText(/29\.990/)).toBeTruthy()
    expect(screen.getByText(/KOSMOS/)).toBeTruthy()
    expect(screen.getByText(/Devir Chile/)).toBeTruthy()
  })

  it('al presionar "Añadir al Carrito" llama onAgregar con el producto', () => {
    const onAgregar = jasmine.createSpy('onAgregar') // función espía (mock)
    render(<TarjetaProducto producto={catan} onAgregar={onAgregar} />)
    fireEvent.click(screen.getByRole('button', { name: 'Añadir al Carrito' }))
    expect(onAgregar).toHaveBeenCalledOnceWith(catan)
  })
})

describe('TarjetaProducto · stock', () => {
  it('con stock normal muestra las unidades disponibles', () => {
    render(<TarjetaProducto producto={catan} onAgregar={() => {}} />)
    expect(screen.getByText('10 unidades disponibles')).toBeTruthy()
  })

  it('con pocas unidades avisa "Últimas unidades"', () => {
    render(<TarjetaProducto producto={{ ...catan, stock: 3 }} onAgregar={() => {}} />)
    expect(screen.getByText('¡Últimas 3 unidades!')).toBeTruthy()
  })

  it('sin stock muestra el mensaje y bloquea el botón', () => {
    const onAgregar = jasmine.createSpy('onAgregar')
    render(<TarjetaProducto producto={agotado} onAgregar={onAgregar} />)
    expect(screen.getByText('No hay stock disponible')).toBeTruthy()
    const boton = screen.getByRole('button', { name: 'Sin stock' })
    expect(boton.disabled).toBeTrue()
    fireEvent.click(boton)
    expect(onAgregar).not.toHaveBeenCalled()
  })
})

describe('Catalogo', () => {
  it('dibuja una tarjeta por producto', () => {
    render(<Catalogo productos={[catan, carcassonne]} onAgregar={() => {}} />)
    expect(screen.getAllByRole('button', { name: 'Añadir al Carrito' }).length).toBe(2)
  })

  it('muestra un aviso cuando no hay productos', () => {
    render(<Catalogo productos={[]} onAgregar={() => {}} />)
    expect(screen.getByText('No hay productos que coincidan con tu búsqueda.')).toBeTruthy()
  })
})

describe('Buscador (formulario controlado)', () => {
  function dibujar(extra = {}) {
    const props = {
      texto: '',
      onCambiarTexto: jasmine.createSpy('onCambiarTexto'),
      categoria: 'Todas',
      onCambiarCategoria: jasmine.createSpy('onCambiarCategoria'),
      categorias: ['Mouse', 'Consolas'],
      ...extra,
    }
    render(<Buscador {...props} />)
    return props
  }

  it('avisa al padre cada vez que cambia el texto', () => {
    const props = dibujar()
    fireEvent.change(screen.getByLabelText('Buscar producto por nombre'), { target: { value: 'xbox' } })
    expect(props.onCambiarTexto).toHaveBeenCalledWith('xbox')
  })

  it('avisa al padre cuando se elige una categoría', () => {
    const props = dibujar()
    fireEvent.change(screen.getByLabelText('Filtrar por categoría'), { target: { value: 'Mouse' } })
    expect(props.onCambiarCategoria).toHaveBeenCalledWith('Mouse')
  })

  it('muestra el valor que le entrega el estado del padre', () => {
    dibujar({ texto: 'ps5' })
    expect(screen.getByLabelText('Buscar producto por nombre').value).toBe('ps5')
  })
})

describe('Recomendaciones', () => {
  it('con el carrito vacío muestra productos destacados', () => {
    render(<Recomendaciones catalogo={[catan, mouse]} itemsCarrito={[]} onAgregar={() => {}} />)
    expect(screen.getByText('Recomendado para ti')).toBeTruthy()
    expect(screen.getAllByRole('button', { name: 'Añadir al Carrito' }).length).toBe(2)
  })

  it('no recomienda productos agotados', () => {
    render(<Recomendaciones catalogo={[agotado, mouse]} itemsCarrito={[]} onAgregar={() => {}} />)
    expect(screen.getAllByRole('button', { name: 'Añadir al Carrito' }).length).toBe(1)
    expect(screen.queryByText('Auriculares')).toBeNull()
  })

  it('no dibuja nada si no queda nada por recomendar', () => {
    const { container } = render(
      <Recomendaciones catalogo={[catan]} itemsCarrito={[{ ...catan, cantidad: 1 }]} onAgregar={() => {}} />,
    )
    expect(container.innerHTML).toBe('')
  })
})
