// Pruebas de formularios (Login, Registro, Comunidad), Perfil y eventos.
import { render, screen, fireEvent } from '@testing-library/react'
import Login from '../paginas/Login.jsx'
import Registro from '../paginas/Registro.jsx'
import Perfil from '../paginas/Perfil.jsx'
import Comunidad from '../paginas/Comunidad.jsx'
import TarjetaEvento from '../components/TarjetaEvento.jsx'
import { usuarioAna } from './datos-prueba.js'

// fireEvent.submit envía el formulario sin pasar por la validación nativa del navegador,
// así probamos SOLO la lógica de validación que escribimos en React.
const enviarFormulario = (contenedor) => fireEvent.submit(contenedor.querySelector('form'))
const escribir = (etiqueta, valor) =>
  fireEvent.change(screen.getByLabelText(etiqueta), { target: { value: valor } })

describe('Login', () => {
  it('con datos correctos (sin importar mayúsculas del correo) inicia sesión', () => {
    const onIniciarSesion = jasmine.createSpy('onIniciarSesion')
    const { container } = render(<Login usuarioGuardado={usuarioAna} onIniciarSesion={onIniciarSesion} />)
    escribir('Correo Electrónico', 'ANA@duocuc.cl')
    escribir('Contraseña', 'clave123')
    enviarFormulario(container)
    expect(onIniciarSesion).toHaveBeenCalled()
  })

  it('con contraseña incorrecta muestra error y no inicia sesión', () => {
    const onIniciarSesion = jasmine.createSpy('onIniciarSesion')
    const { container } = render(<Login usuarioGuardado={usuarioAna} onIniciarSesion={onIniciarSesion} />)
    escribir('Correo Electrónico', 'ana@duocuc.cl')
    escribir('Contraseña', 'otra')
    enviarFormulario(container)
    expect(screen.getByRole('alert').textContent).toContain('incorrectos')
    expect(onIniciarSesion).not.toHaveBeenCalled()
  })

  it('si no existe usuario registrado rechaza el ingreso', () => {
    const onIniciarSesion = jasmine.createSpy('onIniciarSesion')
    const { container } = render(<Login usuarioGuardado={null} onIniciarSesion={onIniciarSesion} />)
    escribir('Correo Electrónico', 'ana@duocuc.cl')
    escribir('Contraseña', 'clave123')
    enviarFormulario(container)
    expect(onIniciarSesion).not.toHaveBeenCalled()
  })
})

describe('Registro', () => {
  function llenar(edad, referido = '') {
    escribir('Nombre de Usuario', ' Ana ')
    escribir('Correo Electrónico', 'ana@duocuc.cl')
    escribir('Contraseña', 'clave123')
    escribir('Edad', edad)
    if (referido) escribir(/Código de Referido/, referido)
  }

  it('rechaza a menores de 18 años', () => {
    const onRegistrar = jasmine.createSpy('onRegistrar')
    const { container } = render(<Registro onRegistrar={onRegistrar} />)
    llenar('17')
    enviarFormulario(container)
    expect(screen.getByRole('alert').textContent).toContain('mayor de 18')
    expect(onRegistrar).not.toHaveBeenCalled()
  })

  it('registra con 100 puntos de bienvenida y nombre sin espacios sobrantes', () => {
    const onRegistrar = jasmine.createSpy('onRegistrar')
    const { container } = render(<Registro onRegistrar={onRegistrar} />)
    llenar('20')
    enviarFormulario(container)
    expect(onRegistrar).toHaveBeenCalledWith(
      jasmine.objectContaining({ nombre: 'Ana', correo: 'ana@duocuc.cl', puntos: 100 }),
    )
  })

  it('suma +50 puntos si se ingresa un código de referido', () => {
    const onRegistrar = jasmine.createSpy('onRegistrar')
    const { container } = render(<Registro onRegistrar={onRegistrar} />)
    llenar('20', 'GAMER2026')
    enviarFormulario(container)
    expect(onRegistrar.calls.mostRecent().args[0].puntos).toBe(150)
  })
})

describe('Perfil', () => {
  it('sin sesión invita a iniciar sesión o crear cuenta', () => {
    render(<Perfil usuario={null} sesionIniciada={false} onCerrarSesion={() => {}} onCanjear={() => {}} />)
    expect(screen.getByText('Aún no has iniciado sesión')).toBeTruthy()
    expect(screen.queryByText(/Canjear Puntos/)).toBeNull()
  })

  it('con sesión muestra datos y deshabilita premios que los puntos no alcanzan', () => {
    render(<Perfil usuario={usuarioAna} sesionIniciada onCerrarSesion={() => {}} onCanjear={() => {}} />)
    expect(screen.getByText(/Bienvenido, Ana/)).toBeTruthy()
    // 130 puntos: alcanza para Envío Gratis (125) pero no para el descuento (375)
    expect(screen.getByRole('button', { name: /Envío Gratis/ }).disabled).toBeFalse()
    expect(screen.getByRole('button', { name: /5\.000 dcto/ }).disabled).toBeTrue()
  })

  it('al canjear avisa con el costo y el nombre del premio', () => {
    const onCanjear = jasmine.createSpy('onCanjear')
    render(<Perfil usuario={usuarioAna} sesionIniciada onCerrarSesion={() => {}} onCanjear={onCanjear} />)
    fireEvent.click(screen.getByRole('button', { name: /Envío Gratis/ }))
    expect(onCanjear).toHaveBeenCalledOnceWith(125, 'Envío Gratis Nacional')
  })

  it('el botón Cerrar Sesión ejecuta onCerrarSesion', () => {
    const onCerrarSesion = jasmine.createSpy('onCerrarSesion')
    render(<Perfil usuario={usuarioAna} sesionIniciada onCerrarSesion={onCerrarSesion} onCanjear={() => {}} />)
    fireEvent.click(screen.getByText('Cerrar Sesión'))
    expect(onCerrarSesion).toHaveBeenCalled()
  })
})

describe('Comunidad (foro)', () => {
  function publicar(contenedor, autor, texto) {
    escribir(/Tu Nombre/, autor)
    escribir(/Consejo o Tip/, texto)
    enviarFormulario(contenedor)
  }

  it('publica un consejo nuevo y lo guarda en localStorage', () => {
    const { container } = render(<Comunidad nombreUsuario="" />)
    publicar(container, 'Ana', 'Usa cable de red')
    expect(screen.getByText('Usa cable de red')).toBeTruthy()
    const guardados = JSON.parse(localStorage.getItem('consejosComunidad'))
    expect(guardados[0].texto).toBe('Usa cable de red')
  })

  it('no publica si el texto son solo espacios', () => {
    const { container } = render(<Comunidad nombreUsuario="Ana" />)
    const antes = container.querySelectorAll('.comentario').length
    publicar(container, 'Ana', '    ')
    expect(container.querySelectorAll('.comentario').length).toBe(antes)
  })

  it('muestra como texto (no como HTML) un intento de inyección XSS', () => {
    const ataque = '<img src=x onerror="window.__xss=true">'
    const { container } = render(<Comunidad nombreUsuario="Ana" />)
    publicar(container, 'Ana', ataque)
    expect(container.querySelector('.comentario img')).toBeNull()
    expect(screen.getByText(ataque)).toBeTruthy()
    expect(window.__xss).toBeUndefined()
  })

  it('permite eliminar un consejo', () => {
    const { container } = render(<Comunidad nombreUsuario="Ana" />)
    publicar(container, 'Ana', 'Consejo temporal')
    fireEvent.click(screen.getByLabelText('Eliminar el consejo de Ana'))
    expect(screen.queryByText('Consejo temporal')).toBeNull()
  })
})

describe('TarjetaEvento', () => {
  const evento = { id: 1, etiqueta: 'TORNEO', lugar: 'Melipilla', descripcion: 'Torneo local', puntos: 100 }

  it('el check-in avisa con el lugar y los puntos', () => {
    const onCheckIn = jasmine.createSpy('onCheckIn')
    render(<TarjetaEvento evento={{ ...evento, fechaFin: '2999-01-01' }} onCheckIn={onCheckIn} />)
    fireEvent.click(screen.getByRole('button', { name: /Check-In/ }))
    expect(onCheckIn).toHaveBeenCalledOnceWith('Melipilla', 100)
  })

  it('un evento finalizado bloquea el check-in', () => {
    render(<TarjetaEvento evento={{ ...evento, fechaFin: '2000-01-01' }} onCheckIn={() => {}} />)
    const boton = screen.getByRole('button', { name: 'Evento finalizado' })
    expect(boton.disabled).toBeTrue()
  })
})
