// Prueba de integración: la aplicación completa (estado compartido en App).
import { render, screen, fireEvent } from '@testing-library/react'
import App from '../App.jsx'

describe('App (integración)', () => {
  beforeEach(() => {
    localStorage.clear()
  })

  it('arranca en Inicio con la portada y las recomendaciones', () => {
    window.location.hash = '#inicio'
    render(<App />)
    expect(screen.getByRole('heading', { name: 'Desafía tus límites con Level-Up Gamer' })).toBeTruthy()
    expect(screen.getByText('Recomendado para ti')).toBeTruthy()
  })

  it('lee la página activa desde el # de la dirección', () => {
    window.location.hash = '#catalogo'
    render(<App />)
    expect(screen.getByText('Inventario Disponible')).toBeTruthy()
  })

  it('agregar un producto actualiza el contador, el título y muestra un aviso', () => {
    window.location.hash = '#catalogo'
    render(<App />)
    fireEvent.click(screen.getAllByRole('button', { name: 'Añadir al Carrito' })[0])
    expect(document.title).toBe('(1) Level-Up Gamer')
    expect(screen.getByText(/se agregó al carrito/)).toBeTruthy()
  })

  it('el carrito guarda sus items en localStorage', () => {
    window.location.hash = '#catalogo'
    render(<App />)
    fireEvent.click(screen.getAllByRole('button', { name: 'Añadir al Carrito' })[0])
    const guardado = JSON.parse(localStorage.getItem('carrito-levelup'))
    expect(guardado).toEqual([{ id: 1, cantidad: 1 }])
  })

  it('pagar sin sesión redirige a #login', () => {
    window.location.hash = '#catalogo'
    render(<App />)
    fireEvent.click(screen.getAllByRole('button', { name: 'Añadir al Carrito' })[0])
    fireEvent.click(screen.getByRole('button', { name: /^🛒 Carrito/ }))
    fireEvent.click(screen.getByText('Proceder al Pago'))
    expect(window.location.hash).toBe('#login')
  })

  it('un producto agotado aparece como "Sin stock" y deshabilitado', () => {
    window.location.hash = '#catalogo'
    render(<App />)
    expect(screen.getByRole('button', { name: 'Sin stock' }).disabled).toBeTrue()
  })

  it('no deja agregar más unidades que el stock (PS5 tiene 3)', () => {
    window.location.hash = '#catalogo'
    render(<App />)
    // Botones "Añadir": Catan, Carcassonne, Xbox, PS5 (los agotados no tienen ese botón) → PS5 es el 4.º
    const botonPS5 = () => screen.getAllByRole('button', { name: 'Añadir al Carrito' })[3]
    for (let i = 0; i < 4; i++) fireEvent.click(botonPS5())
    expect(JSON.parse(localStorage.getItem('carrito-levelup'))).toEqual([{ id: 5, cantidad: 3 }])
    expect(screen.getByText(/Solo hay 3 unidades/)).toBeTruthy()
  })

  it('la lupa del encabezado filtra el catálogo y se puede limpiar', () => {
    window.location.hash = '#catalogo'
    render(<App />)
    fireEvent.click(screen.getByLabelText('Buscar productos'))
    fireEvent.change(screen.getByLabelText('Buscar producto por nombre'), { target: { value: 'catan' } })
    expect(screen.getAllByRole('button', { name: 'Añadir al Carrito' }).length).toBe(1)
    expect(screen.getByText(/Mostrando 1 de 10 productos/)).toBeTruthy()

    fireEvent.click(screen.getByText('Limpiar búsqueda'))
    expect(screen.getAllByRole('button', { name: 'Añadir al Carrito' }).length).toBe(9) // 10 − 1 agotado
  })
})
