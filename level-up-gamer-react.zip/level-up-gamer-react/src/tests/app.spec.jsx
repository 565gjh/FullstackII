// Prueba de integración: la aplicación completa, con el estado que vive en App.
import { render, screen, fireEvent } from '@testing-library/react'
import App from '../App.jsx'
import { usuarioAna } from './datos-prueba.js'

const escribir = (etiqueta, valor) =>
  fireEvent.change(screen.getByLabelText(etiqueta), { target: { value: valor } })

describe('App (integración)', () => {
  it('al agregar un producto actualiza el título y guarda el carrito', () => {
    window.location.hash = '#catalogo'
    render(<App />)
    fireEvent.click(screen.getAllByRole('button', { name: 'Añadir al Carrito' })[0])
    expect(document.title).toBe('(1) Level-Up Gamer')
    expect(screen.getByText(/se agregó al carrito/)).toBeTruthy()
    expect(JSON.parse(localStorage.getItem('carrito-levelup'))).toEqual([{ id: 1, cantidad: 1 }])
  })

  it('no deja agregar más unidades que el stock (la PS5 tiene 3)', () => {
    window.location.hash = '#catalogo'
    render(<App />)
    // el cuarto botón "Añadir" es el de la PS5 (el producto agotado no tiene ese botón)
    const botonPS5 = () => screen.getAllByRole('button', { name: 'Añadir al Carrito' })[3]
    for (let i = 0; i < 4; i++) fireEvent.click(botonPS5())
    expect(JSON.parse(localStorage.getItem('carrito-levelup'))).toEqual([{ id: 5, cantidad: 3 }])
    expect(screen.getByText(/Solo hay 3 unidades/)).toBeTruthy()
  })

  it('pagar sin sesión redirige al login', () => {
    window.location.hash = '#catalogo'
    render(<App />)
    fireEvent.click(screen.getAllByRole('button', { name: 'Añadir al Carrito' })[0])
    fireEvent.click(screen.getByRole('button', { name: /^🛒 Carrito/ }))
    fireEvent.click(screen.getByText('Proceder al Pago'))
    expect(window.location.hash).toBe('#login')
  })

  it('la lupa del header filtra el catálogo y se puede limpiar', () => {
    window.location.hash = '#catalogo'
    render(<App />)
    fireEvent.click(screen.getByLabelText('Buscar productos'))
    fireEvent.change(screen.getByLabelText('Buscar producto por nombre'), { target: { value: 'catan' } })
    expect(screen.getAllByRole('button', { name: 'Añadir al Carrito' }).length).toBe(1)

    fireEvent.click(screen.getByText('Limpiar búsqueda'))
    expect(screen.getAllByRole('button', { name: 'Añadir al Carrito' }).length).toBe(9)
  })

  it('en login y registro no se muestran el header ni el footer', () => {
    window.location.hash = '#login'
    const { container, unmount } = render(<App />)
    expect(container.querySelector('header')).toBeNull()
    expect(container.querySelector('footer')).toBeNull()
    unmount()

    window.location.hash = '#catalogo'
    const otra = render(<App />)
    expect(otra.container.querySelector('header')).not.toBeNull()
    expect(otra.container.querySelector('footer')).not.toBeNull()
  })

  it('el inicio muestra las recomendaciones', () => {
    window.location.hash = '#inicio'
    render(<App />)
    expect(screen.getByText('Recomendado para ti')).toBeTruthy()
  })

  it('flujo completo: registrarse, iniciar sesión y llegar al perfil', async () => {
    window.location.hash = '#registro'
    const { container } = render(<App />)
    escribir('Nombre de Usuario', 'Ana')
    escribir('Correo Electrónico', 'ana@duocuc.cl')
    escribir('Contraseña', 'clave123')
    escribir('Edad', '20')
    fireEvent.submit(container.querySelector('form'))

    // el cambio de # llega de forma asíncrona, por eso se espera con findBy
    await screen.findByRole('heading', { name: 'Iniciar Sesión' })
    escribir('Correo Electrónico', 'ana@duocuc.cl')
    escribir('Contraseña', 'clave123')
    fireEvent.submit(container.querySelector('form'))

    expect(await screen.findByText(/Bienvenido, Ana/)).toBeTruthy()
  })

  it('con sesión, el check-in en un evento suma puntos al usuario', () => {
    localStorage.setItem('usuarioPerfil', JSON.stringify(usuarioAna))
    localStorage.setItem('sesionIniciada', 'true')
    window.location.hash = '#eventos'
    render(<App />)
    // se toma un evento que siga vigente (no depende de la fecha en que se corran las pruebas)
    const boton = screen.getAllByRole('button', { name: /Check-In/ }).find((b) => !b.disabled)
    fireEvent.click(boton)
    expect(screen.getByText(/Check-in realizado/)).toBeTruthy()
    expect(JSON.parse(localStorage.getItem('usuarioPerfil')).puntos).toBeGreaterThan(usuarioAna.puntos)
  })
})
