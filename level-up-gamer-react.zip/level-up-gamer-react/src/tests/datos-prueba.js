// Datos de ejemplo compartidos por las pruebas (no se usan los datos reales para que
// las pruebas no se rompan si cambia el catálogo).
export const catan = {
  id: 1,
  codigo: 'JM001',
  categoria: 'Juegos de Mesa',
  nombre: 'Catan',
  precio: 29990,
  stock: 10,
  imagen: '',
  descripcion: 'Juego de estrategia.',
  fabricante: 'KOSMOS',
  distribuidor: 'Devir Chile',
}

export const mouse = {
  id: 8,
  codigo: 'MS001',
  categoria: 'Mouse',
  nombre: 'Mouse Logitech',
  precio: 49990,
  stock: 5,
  imagen: '',
  descripcion: 'Mouse gamer.',
  fabricante: 'Logitech',
  distribuidor: 'Logitech Chile',
}

export const carcassonne = { ...catan, id: 2, codigo: 'JM002', nombre: 'Carcassonne', precio: 24990 }

export const usuarioAna = {
  nombre: 'Ana',
  correo: 'ana@duocuc.cl',
  password: 'clave123',
  puntos: 130,
  nivel: 'Hierro 🛡️',
}

// Producto agotado (stock 0) para probar el estado "Sin stock".
export const agotado = { ...catan, id: 4, codigo: 'AC002', nombre: 'Auriculares', stock: 0 }
