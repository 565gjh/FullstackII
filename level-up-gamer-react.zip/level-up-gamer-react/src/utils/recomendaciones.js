// Recomendaciones personalizadas (propuesta personalizada del ERS).
// Función pura: según lo que hay en el carrito, sugiere productos que el cliente aún no lleva
// (y que tengan stock: no tiene sentido recomendar algo agotado).
//  - Con carrito: primero productos de las MISMAS categorías ("afines"), luego el resto.
//  - Sin carrito: un producto por categoría ("destacados") para mostrar variedad.
export function recomendarProductos(catalogo, itemsCarrito, maximo = 3) {
  const idsEnCarrito = new Set(itemsCarrito.map((item) => item.id))
  const disponibles = catalogo.filter(
    (producto) => producto.stock > 0 && !idsEnCarrito.has(producto.id),
  )

  if (itemsCarrito.length === 0) {
    const vistas = new Set()
    const destacados = disponibles.filter((producto) => {
      if (vistas.has(producto.categoria)) return false
      vistas.add(producto.categoria)
      return true
    })
    return { motivo: 'destacados', productos: destacados.slice(0, maximo) }
  }

  const categorias = new Set(itemsCarrito.map((item) => item.categoria))
  const afines = disponibles.filter((producto) => categorias.has(producto.categoria))
  const otros = disponibles.filter((producto) => !categorias.has(producto.categoria))
  return {
    motivo: afines.length > 0 ? 'afines' : 'destacados',
    productos: [...afines, ...otros].slice(0, maximo),
  }
}
