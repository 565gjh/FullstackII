// Pequeñas ayudas para leer y escribir en localStorage.
// Todo se guarda como JSON, y si el navegador no deja usar localStorage
// (o el dato está dañado) la aplicación sigue funcionando con el valor por defecto.

export function leerGuardado(clave, valorPorDefecto) {
  try {
    const guardado = localStorage.getItem(clave)
    return guardado ? JSON.parse(guardado) : valorPorDefecto
  } catch {
    return valorPorDefecto
  }
}

export function guardar(clave, valor) {
  try {
    localStorage.setItem(clave, JSON.stringify(valor))
  } catch {
    // Sin espacio o modo privado: no pasa nada, solo no se conserva el dato.
  }
}
