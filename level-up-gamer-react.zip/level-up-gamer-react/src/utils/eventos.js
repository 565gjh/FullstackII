// Función pura: un evento está finalizado cuando tiene fechaFin y ya pasó (hasta las 23:59 de ese día).
// "hoy" se recibe por parámetro para poder probarla con cualquier fecha.
export function eventoFinalizado(evento, hoy = new Date()) {
  if (!evento.fechaFin) return false
  const fin = new Date(`${evento.fechaFin}T23:59:59`)
  return hoy > fin
}
