// Rangos del programa de puntos LevelUp.
// Es una función pura: recibe puntos y devuelve el rango que corresponde.
export function calcularNivel(puntos) {
  if (puntos >= 1200) return 'Challenger 👑'
  if (puntos >= 600) return 'Platino 💎'
  if (puntos >= 200) return 'Oro 🪙'
  return 'Hierro 🛡️'
}
