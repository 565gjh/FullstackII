import { useState, useEffect } from 'react'

import Encabezado from './components/Encabezado.jsx'
import Carrito from './components/Carrito.jsx'
import PiePagina from './components/PiePagina.jsx'
import BotonSoporte from './components/BotonSoporte.jsx'
import Aviso from './components/Aviso.jsx'

import Inicio from './paginas/Inicio.jsx'
import Productos from './paginas/Productos.jsx'
import Comunidad from './paginas/Comunidad.jsx'
import Eventos from './paginas/Eventos.jsx'
import Login from './paginas/Login.jsx'
import Registro from './paginas/Registro.jsx'
import Perfil from './paginas/Perfil.jsx'

import productos from './data/productos.js'
import { leerGuardado, guardar } from './utils/almacenamiento.js'
import { calcularNivel } from './utils/niveles.js'

// Claves con las que se guardan los datos en el navegador (localStorage).
const CLAVE_CARRITO = 'carrito-levelup'
const CLAVE_USUARIO = 'usuarioPerfil'
const CLAVE_SESION = 'sesionIniciada'

// Categorías únicas del catálogo (para el selector del buscador). Se calcula una sola vez.
const CATEGORIAS = [...new Set(productos.map((p) => p.categoria))]

const PAGINAS = ['inicio', 'catalogo', 'comunidad', 'eventos', 'perfil', 'login', 'registro']

// La página activa se toma de la dirección: tienda.cl/#catalogo → "catalogo".
function paginaDesdeHash() {
  const destino = window.location.hash.slice(1)
  return PAGINAS.includes(destino) ? destino : 'inicio'
}

// Lee el carrito guardado en el navegador (si existe).
// Solo se guardan { id, cantidad }: el nombre, precio e imagen se toman siempre del catálogo.
function cargarCarritoGuardado() {
  const guardado = leerGuardado(CLAVE_CARRITO, [])
  return Array.isArray(guardado) ? guardado : []
}

// Componente raíz de la aplicación. Aquí vive el ESTADO COMPARTIDO (carrito, sesión, usuario,
// avisos, búsqueda) y se decide qué página mostrar según el # de la dirección.
// Los datos bajan a los hijos por props y los hijos avisan con funciones (estado levantado).
function App() {
  // ---------- ESTADO ----------
  // Pasamos una FUNCIÓN a useState: así localStorage se lee solo la primera vez.
  const [pagina, setPagina] = useState(paginaDesdeHash)
  const [carrito, setCarrito] = useState(cargarCarritoGuardado)
  const [mostrarCarrito, setMostrarCarrito] = useState(false)
  const [usuario, setUsuario] = useState(() => leerGuardado(CLAVE_USUARIO, null))
  const [sesionIniciada, setSesionIniciada] = useState(() => leerGuardado(CLAVE_SESION, false))
  const [aviso, setAviso] = useState(null)
  // Buscador de productos: se escribe en la lupa del encabezado y se aplica en el catálogo.
  const [textoBusqueda, setTextoBusqueda] = useState('')
  const [categoriaBusqueda, setCategoriaBusqueda] = useState('Todas')

  // ---------- EFECTOS ----------
  // Se ejecutan después de cada render en que el valor de la lista [..] haya cambiado.
  useEffect(() => {
    guardar(CLAVE_CARRITO, carrito)
  }, [carrito])

  useEffect(() => {
    // Mientras no exista un usuario registrado no hay nada que guardar.
    if (usuario !== null) guardar(CLAVE_USUARIO, usuario)
  }, [usuario])

  useEffect(() => {
    guardar(CLAVE_SESION, sesionIniciada)
  }, [sesionIniciada])

  // Escucha los cambios de "#pagina" en la dirección. La función que devuelve el
  // efecto se ejecuta al desmontar: deja de escuchar para no dejar basura.
  useEffect(() => {
    const alCambiarDireccion = () => setPagina(paginaDesdeHash())
    window.addEventListener('hashchange', alCambiarDireccion)
    return () => window.removeEventListener('hashchange', alCambiarDireccion)
  }, [])

  // Al cambiar de página, volver al inicio de la pantalla.
  useEffect(() => {
    window.scrollTo(0, 0)
  }, [pagina])

  // ---------- DATOS DERIVADOS (se calculan, no se guardan) ----------
  // Une cada { id, cantidad } del carrito con los datos completos del producto.
  // Protección: si el stock bajó desde la última visita, la cantidad se limita al stock
  // actual y los productos agotados salen del carrito.
  const itemsCarrito = carrito
    .map(({ id, cantidad }) => {
      const producto = productos.find((p) => p.id === id)
      if (!producto || producto.stock <= 0) return null
      return { ...producto, cantidad: Math.min(cantidad, producto.stock) }
    })
    .filter(Boolean)
  const cantidadTotal = itemsCarrito.reduce((suma, item) => suma + item.cantidad, 0)
  // Hay sesión solo si el usuario existe Y marcó "iniciada".
  const haySesion = sesionIniciada === true && usuario !== null

  // Actualiza el título de la pestaña del navegador (otro efecto).
  useEffect(() => {
    document.title = `(${cantidadTotal}) Level-Up Gamer`
  }, [cantidadTotal])

  // ---------- FUNCIONES QUE CAMBIAN EL ESTADO ----------
  function irA(destino) {
    window.location.hash = destino
  }

  // Quita el filtro del catálogo (vuelve a mostrar todos los productos).
  function limpiarBusqueda() {
    setTextoBusqueda('')
    setCategoriaBusqueda('Todas')
  }

  function mostrarAviso(texto, variante = 'success') {
    setAviso({ id: Date.now(), texto, variante })
  }

  function agregarAlCarrito(producto) {
    // Validación de stock: no se pueden llevar más unidades de las que hay.
    const unidadesEnCarrito = carrito.find((item) => item.id === producto.id)?.cantidad ?? 0
    if (unidadesEnCarrito >= producto.stock) {
      mostrarAviso(`Solo hay ${producto.stock} unidades de "${producto.nombre}" disponibles.`, 'warning')
      return
    }

    setCarrito((carritoActual) => {
      const existe = carritoActual.find((item) => item.id === producto.id)
      if (existe) {
        // Nunca modificamos el arreglo original: creamos uno nuevo con map
        return carritoActual.map((item) =>
          item.id === producto.id ? { ...item, cantidad: item.cantidad + 1 } : item,
        )
      }
      return [...carritoActual, { id: producto.id, cantidad: 1 }]
    })
    mostrarAviso(`"${producto.nombre}" se agregó al carrito.`)
  }

  // Suma o resta unidades; si la cantidad llega a 0 el producto sale del carrito.
  function cambiarCantidad(id, cambio) {
    // Al sumar, se respeta el stock del producto.
    if (cambio > 0) {
      const producto = productos.find((p) => p.id === id)
      const unidadesEnCarrito = carrito.find((item) => item.id === id)?.cantidad ?? 0
      if (!producto || unidadesEnCarrito + cambio > producto.stock) {
        mostrarAviso('Ya tienes todas las unidades disponibles de este producto.', 'warning')
        return
      }
    }

    setCarrito((carritoActual) =>
      carritoActual
        .map((item) => (item.id === id ? { ...item, cantidad: item.cantidad + cambio } : item))
        .filter((item) => item.cantidad > 0),
    )
  }

  function quitarDelCarrito(id) {
    setCarrito((carritoActual) => carritoActual.filter((item) => item.id !== id))
  }

  // Simula el pago: exige sesión iniciada; si la hay, "procesa" la compra y vacía el carrito.
  function procederPago() {
    setMostrarCarrito(false)
    if (!haySesion) {
      mostrarAviso('Debes iniciar sesión para procesar tu compra.', 'warning')
      irA('login')
      return
    }
    mostrarAviso(`¡Compra procesada con éxito, ${usuario.nombre}! Revisa los detalles en tu perfil.`)
    setCarrito([])
    irA('perfil')
  }

  function registrarUsuario(nuevoUsuario) {
    setUsuario(nuevoUsuario)
    setSesionIniciada(false)
    mostrarAviso('¡Cuenta creada con éxito! Ahora inicia sesión.')
    irA('login')
  }

  function iniciarSesion() {
    setSesionIniciada(true)
    mostrarAviso(`¡Inicio de sesión exitoso! Bienvenido, ${usuario.nombre}.`)
    irA('perfil')
  }

  function cerrarSesion() {
    setSesionIniciada(false)
    mostrarAviso('Cerraste sesión.', 'info')
  }

  function realizarCheckIn(lugar, puntos) {
    if (!haySesion) {
      mostrarAviso('Debes iniciar sesión para acumular puntos por tus check-ins.', 'warning')
      irA('login')
      return
    }
    setUsuario((actual) => {
      const total = actual.puntos + puntos
      return { ...actual, puntos: total, nivel: calcularNivel(total) }
    })
    mostrarAviso(`¡Check-in realizado con éxito en "${lugar}"! Ganaste +${puntos} Puntos LevelUp.`)
  }

  function canjearPremio(costo, nombrePremio) {
    if (!haySesion) return
    if (usuario.puntos < costo) {
      mostrarAviso(`Te faltan ${costo - usuario.puntos} puntos para canjear "${nombrePremio}".`, 'danger')
      return
    }
    setUsuario((actual) => {
      const total = actual.puntos - costo
      return { ...actual, puntos: total, nivel: calcularNivel(total) }
    })
    mostrarAviso(`¡Canje exitoso! Obtuviste: ${nombrePremio}.`)
  }

  // ---------- QUÉ PÁGINA SE DIBUJA ----------
  let contenido
  switch (pagina) {
    case 'catalogo':
      contenido = (
        <Productos
          onAgregar={agregarAlCarrito}
          texto={textoBusqueda}
          categoria={categoriaBusqueda}
          onLimpiarBusqueda={limpiarBusqueda}
        />
      )
      break
    case 'comunidad':
      contenido = <Comunidad nombreUsuario={haySesion ? usuario.nombre : ''} />
      break
    case 'eventos':
      contenido = <Eventos onCheckIn={realizarCheckIn} />
      break
    case 'login':
      contenido = <Login usuarioGuardado={usuario} onIniciarSesion={iniciarSesion} />
      break
    case 'registro':
      contenido = <Registro onRegistrar={registrarUsuario} />
      break
    case 'perfil':
      contenido = (
        <Perfil
          usuario={usuario}
          sesionIniciada={haySesion}
          onCerrarSesion={cerrarSesion}
          onCanjear={canjearPremio}
        />
      )
      break
    default:
      contenido = <Inicio itemsCarrito={itemsCarrito} onAgregar={agregarAlCarrito} />
  }

  return (
    <div className="d-flex flex-column min-vh-100">
      {/* Datos bajan por props; los eventos suben mediante funciones */}
      <Encabezado
        pagina={pagina}
        sesionIniciada={haySesion}
        cantidad={cantidadTotal}
        onVerCarrito={() => setMostrarCarrito(true)}
        buscador={{
          texto: textoBusqueda,
          onCambiarTexto: setTextoBusqueda,
          categoria: categoriaBusqueda,
          onCambiarCategoria: setCategoriaBusqueda,
          categorias: CATEGORIAS,
        }}
      />

      <main className="flex-grow-1">{contenido}</main>

      <Carrito
        mostrar={mostrarCarrito}
        onCerrar={() => setMostrarCarrito(false)}
        items={itemsCarrito}
        onCambiarCantidad={cambiarCantidad}
        onQuitar={quitarDelCarrito}
        onVaciar={() => setCarrito([])}
        onPagar={procederPago}
      />

      <Aviso aviso={aviso} onCerrar={() => setAviso(null)} />
      <BotonSoporte nombreUsuario={usuario ? usuario.nombre : 'Cliente'} />
      <PiePagina />
    </div>
  )
}

export default App
