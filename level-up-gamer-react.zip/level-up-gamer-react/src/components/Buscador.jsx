import { Form, Row, Col } from 'react-bootstrap'

// Formulario CONTROLADO: el valor de cada campo vive en el estado del padre (App).
// El input muestra lo que dice el estado (value) y avisa cada cambio (onChange).
// Props opcionales: "className" (márgenes) y "autoFocus" (enfocar el campo al abrirse).
function Buscador({
  texto,
  onCambiarTexto,
  categoria,
  onCambiarCategoria,
  categorias,
  className = 'mb-4',
  autoFocus = false,
}) {
  return (
    <Form className={className} onSubmit={(evento) => evento.preventDefault()}>
      <Row className="g-2">
        <Col md={8}>
          <Form.Control
            type="search"
            placeholder="Buscar producto por nombre…"
            aria-label="Buscar producto por nombre"
            value={texto}
            autoFocus={autoFocus}
            onChange={(evento) => onCambiarTexto(evento.target.value)}
          />
        </Col>
        <Col md={4}>
          <Form.Select
            aria-label="Filtrar por categoría"
            value={categoria}
            onChange={(evento) => onCambiarCategoria(evento.target.value)}
          >
            <option value="Todas">Todas las categorías</option>
            {categorias.map((cat) => (
              <option key={cat} value={cat}>
                {cat}
              </option>
            ))}
          </Form.Select>
        </Col>
      </Row>
    </Form>
  )
}

export default Buscador
