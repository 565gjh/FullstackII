import { Card, Button, Badge } from 'react-bootstrap'
import { formatearPrecio } from '../utils/formato.js'

// con este stock o menos se avisa "últimas unidades"
const STOCK_BAJO = 5

// Componente de presentación: muestra lo que recibe por props y avisa con onAgregar.
// No sabe nada del carrito ni modifica las props.
function TarjetaProducto({ producto, onAgregar }) {
  const { codigo, categoria, nombre, descripcion, precio, imagen, fabricante, distribuidor, stock } =
    producto

  // datos que salen del stock
  const sinStock = stock <= 0
  const stockBajo = !sinStock && stock <= STOCK_BAJO

  return (
    <Card className={`tarjeta-producto h-100 ${sinStock ? 'tarjeta-sin-stock' : ''}`}>
      <Card.Img
        variant="top"
        src={imagen}
        alt={`Imagen de ${nombre}`}
        className="imagen-producto"
        loading="lazy"
      />
      <Card.Body className="d-flex flex-column">
        <Badge className="etiqueta-producto align-self-start mb-2">
          [{codigo}] {categoria}
        </Badge>
        <Card.Title as="h3">{nombre}</Card.Title>
        <Card.Text className="descripcion">{descripcion}</Card.Text>

        <div className="origen-producto mb-3">
          <div>
            <strong>Fabricante:</strong> {fabricante}
          </div>
          <div>
            <strong>Distribuidor:</strong> {distribuidor}
          </div>
        </div>

        {/* estado del stock */}
        <p className={`estado-stock ${sinStock ? 'agotado' : stockBajo ? 'bajo' : 'disponible'}`}>
          {sinStock
            ? 'No hay stock disponible'
            : stockBajo
              ? `¡Últimas ${stock} unidades!`
              : `${stock} unidades disponibles`}
        </p>

        <Card.Text className="precio mt-auto">{formatearPrecio(precio)}</Card.Text>
        {/* arrow function para que no se ejecute al renderizar */}
        <Button variant="primary" disabled={sinStock} onClick={() => onAgregar(producto)}>
          {sinStock ? 'Sin stock' : 'Añadir al Carrito'}
        </Button>
      </Card.Body>
    </Card>
  )
}

export default TarjetaProducto
