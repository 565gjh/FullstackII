import { useState } from 'react'
import { Navbar, Nav, Container, Button, Badge } from 'react-bootstrap'
import Buscador from './Buscador.jsx'

// Enlaces fijos del menú. Cada uno apunta a "#pagina": App escucha el cambio
// de la dirección y muestra la página correspondiente (así funcionan también
// los botones Atrás/Adelante del navegador).
const ENLACES = [
  { destino: 'inicio', texto: 'Inicio' },
  { destino: 'catalogo', texto: 'Catálogo' },
  { destino: 'comunidad', texto: 'Comunidad & Blog' },
  { destino: 'eventos', texto: 'Eventos & Mapa' },
]

// Ícono de lupa en SVG (no necesita librerías). "currentColor" toma el color del botón.
function IconoLupa() {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor"
      strokeWidth="2.2" strokeLinecap="round" aria-hidden="true">
      <circle cx="11" cy="11" r="7" />
      <line x1="16.5" y1="16.5" x2="21" y2="21" />
    </svg>
  )
}

// Recibe por props:
//  - pagina: cuál está abierta (para marcar el enlace activo y mostrar la lupa)
//  - sesionIniciada: decide si se muestra "Mi Perfil" o "Iniciar Sesión"
//  - cantidad: cuántos productos hay en el carrito (un dato)
//  - onVerCarrito: qué hacer al presionar el botón del carrito (una función)
//  - buscador: datos y funciones del buscador de productos (viven en App); null = sin buscador
function Encabezado({ pagina, sesionIniciada, cantidad, onVerCarrito, buscador = null }) {
  // Estado LOCAL: solo este componente necesita saber si la barra de búsqueda está abierta.
  const [busquedaAbierta, setBusquedaAbierta] = useState(false)

  // La lupa solo existe en el catálogo. La barra se ve si el usuario la abrió
  // o si hay un filtro activo (así nunca queda un filtro "invisible").
  const hayLupa = pagina === 'catalogo' && buscador !== null
  const hayFiltro = hayLupa && (buscador.texto.trim() !== '' || buscador.categoria !== 'Todas')
  const barraVisible = hayLupa && (busquedaAbierta || hayFiltro)

  return (
    // El <header> pegajoso agrupa la barra de navegación y la barra de búsqueda,
    // así las dos se quedan arriba juntas al hacer scroll.
    <header className="encabezado-fijo sticky-top">
      <Navbar className="encabezado" data-bs-theme="dark" expand="lg" collapseOnSelect>
        <Container className="contenedor">
          <Navbar.Brand href="#inicio">
            LEVEL-UP <span>GAMER</span>
          </Navbar.Brand>

          {/* Lupa y carrito quedan fuera del menú colapsable para verlos siempre, también en el celular */}
          <div className="acciones-encabezado d-flex gap-2 ms-auto me-2 ms-lg-0 order-lg-last">
            {hayLupa && (
              <Button
                variant="outline-primary"
                size="sm"
                className="boton-lupa"
                aria-label="Buscar productos"
                aria-expanded={barraVisible}
                onClick={() => setBusquedaAbierta((abierta) => !abierta)}
              >
                <IconoLupa />
              </Button>
            )}
            <Button variant="outline-primary" size="sm" onClick={onVerCarrito}>
              🛒 Carrito <Badge bg="primary">{cantidad}</Badge>
            </Button>
          </div>

          <Navbar.Toggle aria-controls="menu-principal" />
          <Navbar.Collapse id="menu-principal">
            {/* En Bootstrap 5 es "me-auto" (margin-end), ya no "mr-auto" */}
            <Nav className="me-auto">
              {ENLACES.map(({ destino, texto }) => (
                <Nav.Link key={destino} href={`#${destino}`} active={pagina === destino}>
                  {texto}
                </Nav.Link>
              ))}
            </Nav>
            <Nav>
              {/* Renderizado condicional: un enlace u otro según la sesión */}
              {sesionIniciada ? (
                <Nav.Link href="#perfil" active={pagina === 'perfil'}>
                  Mi Perfil
                </Nav.Link>
              ) : (
                <Nav.Link href="#login" active={pagina === 'login' || pagina === 'registro'}>
                  Iniciar Sesión
                </Nav.Link>
              )}
            </Nav>
          </Navbar.Collapse>
        </Container>
      </Navbar>

      {/* Barra de búsqueda: reutiliza el mismo componente Buscador de siempre */}
      {barraVisible && (
        <div className="barra-busqueda">
          <Container className="contenedor py-3">
            <Buscador
              texto={buscador.texto}
              onCambiarTexto={buscador.onCambiarTexto}
              categoria={buscador.categoria}
              onCambiarCategoria={buscador.onCambiarCategoria}
              categorias={buscador.categorias}
              className="mb-0"
              autoFocus
            />
          </Container>
        </div>
      )}
    </header>
  )
}

export default Encabezado
