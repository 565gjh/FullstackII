import { Toast, ToastContainer, CloseButton } from 'react-bootstrap'

// Mensaje emergente (reemplaza a alert()): no bloquea la página y se cierra solo.
// "aviso" es null cuando no hay nada que mostrar, o un objeto { id, texto, variante }.
function Aviso({ aviso, onCerrar }) {
  return (
    <ToastContainer position="bottom-start" containerPosition="fixed" className="p-3">
      {aviso && (
        // key: cuando llega un aviso nuevo, React reinicia el temporizador del anterior
        <Toast
          key={aviso.id}
          show
          autohide
          delay={3500}
          onClose={onCerrar}
          className={`aviso aviso-${aviso.variante}`}
        >
          <Toast.Body className="d-flex justify-content-between align-items-start gap-3">
            <span>{aviso.texto}</span>
            <CloseButton variant="white" onClick={onCerrar} aria-label="Cerrar aviso" />
          </Toast.Body>
        </Toast>
      )}
    </ToastContainer>
  )
}

export default Aviso
