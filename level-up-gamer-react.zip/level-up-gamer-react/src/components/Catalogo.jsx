import { Row, Col, Alert } from 'react-bootstrap'
import TarjetaProducto from './TarjetaProducto.jsx'

// Recibe la lista de productos y la dibuja con .map().
function Catalogo({ productos, onAgregar }) {
  if (productos.length === 0) {
    return <Alert variant="warning">No hay productos que coincidan con tu búsqueda.</Alert>
  }

  return (
    <Row xs={1} sm={2} lg={3} className="g-4">
      {productos.map((producto) => (
        // key: identificador único y estable para que React sepa qué tarjeta es cuál
        <Col key={producto.id}>
          <TarjetaProducto producto={producto} onAgregar={onAgregar} />
        </Col>
      ))}
    </Row>
  )
}

export default Catalogo
