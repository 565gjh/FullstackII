import { Card, Button } from 'react-bootstrap'
import { eventoFinalizado } from '../utils/eventos.js'

// Una tarjeta del radar de eventos. Al hacer check-in avisa al padre
// con el lugar y los puntos que otorga el evento. Si el evento ya terminó, el botón se bloquea.
function TarjetaEvento({ evento, onCheckIn }) {
  const { etiqueta, lugar, descripcion, puntos } = evento
  const finalizado = eventoFinalizado(evento)

  return (
    <Card className="tarjeta-evento h-100">
      <Card.Body className="d-flex flex-column">
        <span className="etiqueta-evento">{etiqueta}</span>
        <Card.Title as="h3">{lugar}</Card.Title>
        <Card.Text>{descripcion}</Card.Text>
        <Button
          variant="primary"
          className="mt-auto"
          disabled={finalizado}
          onClick={() => onCheckIn(lugar, puntos)}
        >
          {finalizado ? 'Evento finalizado' : `Hacer Check-In (+${puntos} PTS)`}
        </Button>
      </Card.Body>
    </Card>
  )
}

export default TarjetaEvento
