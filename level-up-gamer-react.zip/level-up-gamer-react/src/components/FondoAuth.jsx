// Fondo difuminado con pixel art que comparten Login y Registro.
// "children" es el contenido que se escribe entre las etiquetas del componente.
function FondoAuth({ imagen, children }) {
  return (
    <div className="fondo-auth">
      <div className="envoltorio-auth">
        {imagen && <img src={imagen} alt="Logo Level-Up Gamer" className="imagen-auth" />}
        <div className="caja-auth">{children}</div>
      </div>
    </div>
  )
}

export default FondoAuth
