import { Container, Row, Col } from 'react-bootstrap'
import contacto from '../data/contacto.js'

// Pie de página: descripción de la tienda, enlaces rápidos, datos de contacto y redes sociales.
// Los datos salen de data/contacto.js, así este componente solo se preocupa de mostrarlos.
function PiePagina() {
  return (
    <footer className="pie-pagina">
      <Container className="contenedor">
        {/* xs={1}: una columna en celular · md: tres columnas en pantallas medianas y grandes */}
        <Row className="g-4">
          <Col md={4}>
            <h2 className="pie-titulo">
              LEVEL-UP <span>GAMER</span>
            </h2>
            <p className="pie-texto">
              Hardware, consolas, juegos de mesa y servicio técnico para la comunidad gamer de Chile.
            </p>
            <ul className="pie-lista">
              <li><a href="#catalogo">Catálogo</a></li>
              <li><a href="#comunidad">Comunidad &amp; Blog</a></li>
              <li><a href="#eventos">Eventos &amp; Mapa</a></li>
            </ul>
          </Col>

          <Col md={4}>
            <h3 className="pie-subtitulo">Contacto</h3>
            <ul className="pie-lista">
              <li>
                📧 <a href={`mailto:${contacto.email}`}>{contacto.email}</a>
              </li>
              <li>
                📞 <a href={`tel:+${contacto.whatsapp}`}>{contacto.telefono}</a>
              </li>
              <li>
                💬{' '}
                <a
                  href={`https://api.whatsapp.com/send?phone=${contacto.whatsapp}`}
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  WhatsApp
                </a>
              </li>
              <li>📍 {contacto.ubicacion}</li>
              <li>🕒 {contacto.horario}</li>
            </ul>
          </Col>

          <Col md={4}>
            <h3 className="pie-subtitulo">Síguenos</h3>
            <ul className="pie-redes">
              {contacto.redes.map((red) => (
                <li key={red.id}>
                  {/* target="_blank" + rel="noopener noreferrer": abre en otra pestaña de forma segura */}
                  <a
                    href={red.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="enlace-red"
                    aria-label={`${red.nombre} de Level-Up Gamer`}
                  >
                    <strong>{red.nombre}</strong>
                    <small>{red.usuario}</small>
                  </a>
                </li>
              ))}
            </ul>
          </Col>
        </Row>

        <hr className="pie-separador" />
        <p className="pie-copyright">© 2026 Level-Up Gamer · Todos los derechos reservados</p>
      </Container>
    </footer>
  )
}

export default PiePagina
