// Datos de contacto de la tienda: los usan el pie de página y el botón de WhatsApp.
// Tenerlos en un solo archivo evita repetirlos: si cambia un dato, se cambia aquí.
// IMPORTANTE: los enlaces de redes y el correo son de EJEMPLO; reemplázalos por los reales.

const contacto = {
  email: 'contacto@levelupgamer.cl',
  telefono: '+56 9 1234 5678',
  whatsapp: '56912345678', // formato internacional sin "+" ni espacios (lo exige api.whatsapp.com)
  ubicacion: 'Melipilla, Región Metropolitana · Despachos a todo Chile',
  horario: 'Lunes a viernes, 10:00 a 19:00 hrs',
  redes: [
    { id: 'instagram', nombre: 'Instagram', usuario: '@levelupgamer.cl', url: 'https://www.instagram.com/levelupgamer.cl' },
    { id: 'facebook', nombre: 'Facebook', usuario: 'Level-Up Gamer', url: 'https://www.facebook.com/levelupgamer.cl' },
    { id: 'tiktok', nombre: 'TikTok', usuario: '@levelupgamer.cl', url: 'https://www.tiktok.com/@levelupgamer.cl' },
    { id: 'youtube', nombre: 'YouTube', usuario: 'Level-Up Gamer', url: 'https://www.youtube.com/@levelupgamer' },
  ],
}

export default contacto
