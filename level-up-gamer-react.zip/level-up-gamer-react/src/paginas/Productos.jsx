import { Container, Button } from 'react-bootstrap'

import Portada from '../components/Portada.jsx'
import Catalogo from '../components/Catalogo.jsx'
import productos from '../data/productos.js'

// Página del catálogo. El texto y la categoría de búsqueda se escriben en la lupa del
// encabezado, por eso viven en App y llegan aquí por props (esta página solo filtra y muestra).
function Productos({ onAgregar, texto, categoria, onLimpiarBusqueda }) {
  // ---------- DATOS DERIVADOS (se calculan, no se guardan) ----------
  const hayFiltro = texto.trim() !== '' || categoria !== 'Todas'
  const productosFiltrados = productos.filter((p) => {
    const coincideTexto = p.nombre.toLowerCase().includes(texto.trim().toLowerCase())
    const coincideCategoria = categoria === 'Todas' || p.categoria === categoria
    return coincideTexto && coincideCategoria
  })

  return (
    <>
      <Portada
        titulo="Catálogo de Productos Oficiales"
        texto="Explora nuestra selección completa de hardware, consolas, periféricos, juegos de mesa y textiles personalizados. Calidad garantizada para la comunidad gamer."
      />

      <Container className="contenedor">
        <section className="panel">
          <h2>Inventario Disponible</h2>

          {/* Indicador del filtro activo, con un botón para quitarlo */}
          {hayFiltro ? (
            <p className="resumen-busqueda">
              Mostrando {productosFiltrados.length} de {productos.length} productos.{' '}
              <Button variant="link" className="p-0 align-baseline" onClick={onLimpiarBusqueda}>
                Limpiar búsqueda
              </Button>
            </p>
          ) : (
            <p className="resumen-busqueda">
              Usa la lupa 🔍 del menú superior para buscar por nombre o categoría.
            </p>
          )}

          {/* Los datos bajan del padre al hijo por props */}
          <Catalogo productos={productosFiltrados} onAgregar={onAgregar} />
        </section>
      </Container>
    </>
  )
}

export default Productos
