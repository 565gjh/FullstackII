import { Container, Button } from 'react-bootstrap'

import Portada from '../components/Portada.jsx'
import Catalogo from '../components/Catalogo.jsx'
import productos from '../data/productos.js'

// Catálogo. La búsqueda se escribe en la lupa del header y llega por props desde App.
function Productos({ onAgregar, texto, categoria, onLimpiarBusqueda }) {
  // datos calculados
  const hayFiltro = texto.trim() !== '' || categoria !== 'Todas'
  const productosFiltrados = productos.filter((p) => {
    const coincideTexto = p.nombre.toLowerCase().includes(texto.trim().toLowerCase())
    const coincideCategoria = categoria === 'Todas' || p.categoria === categoria
    return coincideTexto && coincideCategoria
  })

  return (
    <>
      <Portada
        titulo="Catálogo de Productos Oficiales"
        texto="Explora nuestra selección completa de hardware, consolas, periféricos, juegos de mesa y textiles personalizados. Calidad garantizada para la comunidad gamer."
      />

      <Container className="contenedor">
        <section className="panel">
          <h2>Inventario Disponible</h2>

          {/* filtro activo y botón para limpiarlo */}
          {hayFiltro ? (
            <p className="resumen-busqueda">
              Mostrando {productosFiltrados.length} de {productos.length} productos.{' '}
              <Button variant="link" className="p-0 align-baseline" onClick={onLimpiarBusqueda}>
                Limpiar búsqueda
              </Button>
            </p>
          ) : (
            <p className="resumen-busqueda">
              Usa la lupa 🔍 del menú superior para buscar por nombre o categoría.
            </p>
          )}

          <Catalogo productos={productosFiltrados} onAgregar={onAgregar} />
        </section>
      </Container>
    </>
  )
}

export default Productos
