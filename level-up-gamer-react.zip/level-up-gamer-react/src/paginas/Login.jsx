import { useState } from 'react'
import { Form, Button } from 'react-bootstrap'
import FondoAuth from '../components/FondoAuth.jsx'
import logo from '../assets/level-up-gamer-logo.png'

// "usuarioGuardado" es el usuario que se creó en el registro (o null si no existe).
function Login({ usuarioGuardado, onIniciarSesion }) {
  const [correo, setCorreo] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')

  function enviar(evento) {
    evento.preventDefault()

    const datosCorrectos =
      usuarioGuardado !== null &&
      usuarioGuardado.correo.toLowerCase() === correo.trim().toLowerCase() &&
      usuarioGuardado.password === password

    if (datosCorrectos) {
      onIniciarSesion()
    } else {
      setError('Correo o contraseña incorrectos. Intenta de nuevo.')
    }
  }

  return (
    <FondoAuth imagen={logo}>
      <h1 className="h2">Iniciar Sesión</h1>
      <Form onSubmit={enviar}>
        <Form.Group className="mb-3" controlId="correoLogin">
          <Form.Label>Correo Electrónico</Form.Label>
          <Form.Control
            type="email"
            placeholder="usuario@duocuc.cl"
            value={correo}
            onChange={(e) => {
              setCorreo(e.target.value)
              setError('')
            }}
            required
          />
        </Form.Group>

        <Form.Group className="mb-3" controlId="passwordLogin">
          <Form.Label>Contraseña</Form.Label>
          <Form.Control
            type="password"
            placeholder="******"
            value={password}
            onChange={(e) => {
              setPassword(e.target.value)
              setError('')
            }}
            autoComplete="current-password"
            required
          />
        </Form.Group>

        {error && (
          <p className="mensaje-error" role="alert">
            {error}
          </p>
        )}

        <Button type="submit" className="btn-gamer w-100">
          Entrar
        </Button>
      </Form>

      <p className="enlace-auth">
        ¿No tienes cuenta? <a href="#registro">Regístrate aquí</a>
      </p>
    </FondoAuth>
  )
}

export default Login
