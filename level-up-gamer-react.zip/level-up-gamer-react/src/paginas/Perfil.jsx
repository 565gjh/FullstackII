import { Container, Button } from 'react-bootstrap'

// Premios que se pueden canjear con puntos LevelUp.
const PREMIOS = [
  { id: 1, costo: 375, nombre: 'Descuento de $5.000 CLP', boton: 'Canjear $5.000 dcto' },
  { id: 2, costo: 125, nombre: 'Envío Gratis Nacional', boton: 'Canjear Envío Gratis' },
]

// Página de perfil: datos del usuario, rango, puntos y canje de premios.
// No guarda nada por sí misma: App le entrega el usuario y las funciones (cerrar sesión, canjear).
function Perfil({ usuario, sesionIniciada, onCerrarSesion, onCanjear }) {
  // Renderizado condicional con return temprano: sin sesión se muestra otra vista.
  if (!sesionIniciada || !usuario) {
    return (
      <Container className="contenedor contenedor-estrecho py-4">
        <section className="panel text-center">
          <h1 className="h4">Aún no has iniciado sesión</h1>
          <p>Inicia sesión o regístrate para acumular puntos, subir de rango y canjear premios.</p>
          <div className="d-flex gap-2 justify-content-center flex-wrap">
            <Button variant="primary" href="#login">
              Ir a Iniciar Sesión
            </Button>
            <Button variant="outline-primary" href="#registro">
              Crear Cuenta
            </Button>
          </div>
        </section>
      </Container>
    )
  }

  return (
    <Container className="contenedor contenedor-estrecho py-4">
      <section className="panel">
        <h1 className="h4">Panel de Perfil y Gamificación</h1>
        <h2>Bienvenido, {usuario.nombre}</h2>
        <p>
          <strong>Correo:</strong> {usuario.correo}
        </p>
        <p>
          <strong>Rango Actual:</strong> <span className="dato-nivel">{usuario.nivel}</span>
        </p>
        <p>
          <strong>Tus Puntos:</strong>{' '}
          <span className="dato-puntos">{usuario.puntos} Puntos LevelUp</span>
        </p>
        <Button variant="outline-danger" onClick={onCerrarSesion}>
          Cerrar Sesión
        </Button>
      </section>

      <section className="panel">
        <h2>Canjear Puntos LevelUp</h2>
        <p>Intercambia tus puntos por beneficios exclusivos:</p>
        <div className="d-flex gap-2 flex-wrap">
          {PREMIOS.map((premio) => (
            <Button
              key={premio.id}
              variant="primary"
              disabled={usuario.puntos < premio.costo}
              onClick={() => onCanjear(premio.costo, premio.nombre)}
            >
              {premio.boton} ({premio.costo} pts)
            </Button>
          ))}
        </div>
      </section>
    </Container>
  )
}

export default Perfil
