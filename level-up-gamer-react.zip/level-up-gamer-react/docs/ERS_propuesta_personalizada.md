# ERS · Level-Up Gamer — Propuesta personalizada (versión React)

> Sección para **añadir a tu ERS vigente** (la pauta pide "entregar documento añadiendo la propuesta
> personalizada, última versión"). Reemplaza los datos entre [corchetes] por los de tu equipo.

**Equipo:** [integrantes] · **Asignatura:** DSY1104 Desarrollo Full Stack II · **Versión:** 1.1

## 1. Propósito del cambio
Migrar el frontend de la tienda (HTML + CSS + JS) a **React + Vite + React Bootstrap**, con
navegación y formularios propios del framework y un proceso de pruebas unitarias con **Jasmine + Karma**.

## 2. Propuesta personalizada: Recomendaciones personalizadas
La V1 tenía una sección «Recomendaciones personalizadas» oculta y sin lógica. Se integra formalmente.

| ID | Requisito | Criterio de aceptación |
| --- | --- | --- |
| RF-P1 | Mostrar en Inicio la sección «Recomendado para ti». | Aparece con hasta 3 productos. |
| RF-P2 | Con productos en el carrito, recomendar primero los de la misma categoría. | Nunca se recomienda algo que ya está en el carrito. |
| RF-P3 | Con carrito vacío, mostrar un producto por categoría. | Variedad de categorías. |
| RF-P4 | Permitir añadir al carrito desde la recomendación. | Se reutiliza `TarjetaProducto` y la misma función `agregarAlCarrito`. |
| RF-P5 | Bloquear el check-in en eventos cuyo `fechaFin` ya pasó. | Botón deshabilitado con el texto «Evento finalizado». |
| RF-P6 | Controlar el stock de cada producto. | Con stock 0 se muestra «Sin stock» y no se puede agregar; el carrito no supera el stock. |
| RF-P7 | Buscar productos desde una lupa en el encabezado, visible solo en el catálogo. | La lupa abre la barra de búsqueda (nombre y categoría) y filtra el catálogo; permite limpiar el filtro. |
| RF-P8 | Mostrar contacto y redes sociales en el pie de página. | Correo, teléfono, WhatsApp, ubicación, horario y enlaces a redes (abren en pestaña nueva). |

## 3. Requisitos funcionales del frontend (resumen)
RF-01 Navegación SPA por `#` con soporte Atrás/Adelante · RF-02 Catálogo con búsqueda y filtro por categoría ·
RF-03 Carrito en panel lateral (sumar, restar, quitar, vaciar, total) · RF-04 Registro con validación de edad (+18) y puntos de bienvenida ·
RF-05 Login y sesión · RF-06 Perfil con rango y canje de puntos · RF-07 Check-in en eventos (exige sesión) ·
RF-08 Foro con texto escapado (sin inyección HTML) · RF-09 Avisos no bloqueantes (sin `alert()`).

## 4. Requisitos no funcionales
RNF-01 Diseño responsivo con Bootstrap (grilla `Row/Col`, `Navbar expand="lg"`, `Offcanvas`, `Ratio`) ·
RNF-02 Estética gamer (negro, azul, verde neón; Orbitron/Roboto) · RNF-03 Accesibilidad básica (`aria-label`, foco visible, `prefers-reduced-motion`) ·
RNF-04 Pruebas unitarias automatizadas con cobertura medida (ver documento de cobertura).

## 5. Restricciones y riesgos
- Sin backend: usuarios, carrito y foro se guardan en `localStorage`.
- **La contraseña se guarda en texto plano** solo por ser una simulación; con backend debe autenticarse en el servidor (hash + HTTPS).
