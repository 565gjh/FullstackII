# Guía para la presentación individual (60 % de la nota)

Cada integrante debe poder explicar los 4 puntos. Practica con el código abierto.

**1. Diseño con framework (IE2.1.3).** React + Vite: `index.html` solo tiene `<div id="root">`; `main.jsx` monta `<App/>`.
Carpetas: `components/` (piezas reutilizables), `paginas/` (pantallas), `data/` (catálogo), `utils/` (funciones puras).
Navegación SPA con `hashchange` en `App.jsx` (por eso funcionan Atrás/Adelante).

**2. Props, estados y Bootstrap (IE2.1.4).** Estado compartido en `App` (`carrito`, `usuario`, `sesionIniciada`, `aviso`) y
**estado levantado**: los datos bajan por props y los eventos suben con funciones (`onAgregar`, `onCambiarCantidad`).
Datos derivados (total, `itemsCarrito`) se calculan, no se guardan. `useEffect` persiste en `localStorage`.
Responsivo: `Row xs={1} sm={2} lg={3}`, `Navbar expand="lg"`, `Offcanvas`, `Ratio 16x9`. Muestra el sitio a 360 px, 768 px y 1200 px.

**3. Pruebas con Jasmine y Karma (IE2.2.2).** Demuestra en vivo `npm test` y explica 10 pruebas: por ejemplo
`calcularNivel` (límites), `TarjetaProducto` (spy en `onAgregar`), `Carrito` (total 109.970), `Registro` (menor de 18),
`Comunidad` (XSS como texto), `Perfil` (botón deshabilitado), `App` (pago sin sesión → login).

**4. Proceso de testeo (IE2.3.2).** Configuración (`karma.conf.cjs`), escritura (patrón AAA), mocks (`createSpy`, `spyOn`),
análisis de resultados y cobertura (`npm run test:coverage`). Sé honesto/a sobre lo no cubierto.

**Preguntas probables:** ¿por qué `key` en `map`? ¿diferencia props/estado? ¿qué es un formulario controlado?
¿qué es un mock y para qué sirve? ¿por qué la contraseña en texto plano es un riesgo? ¿qué mide la cobertura de ramas?
