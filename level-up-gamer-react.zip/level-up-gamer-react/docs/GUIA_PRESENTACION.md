# Apuntes para la presentación individual

Cada integrante tiene que poder explicar estos cuatro puntos con el código abierto.

## 1. Cómo se diseñó con React (IE2.1.3)
- `index.html` solo tiene un `<div id="root">`; `main.jsx` monta `<App />` ahí.
- `components/` son piezas reutilizables, `paginas/` son las pantallas, `data/` tiene los datos y `utils/` las funciones sueltas.
- La navegación usa el `#` de la dirección y un `hashchange` en `App.jsx` (por eso funcionan Atrás y Adelante).

## 2. Props, estados y Bootstrap (IE2.1.4)
- El estado que usan varias páginas (carrito, sesión, usuario, búsqueda) está en `App`.
  Los componentes reciben datos por props y avisan con funciones (`onAgregar`, `onCambiarCantidad`).
- Lo que se puede calcular (total del carrito, productos filtrados) se calcula en cada render y no se guarda en el estado.
- `useEffect` guarda el carrito y el usuario en `localStorage`.
- Responsivo: `Row xs={1} sm={2} lg={3}`, `Navbar expand="lg"`, `Offcanvas` para el carrito y `Ratio` para el video.
  Mostrar el sitio a 360 px, 768 px y 1200 px.

## 3. Pruebas con Jasmine y Karma (IE2.2.2)
Correr `npm test` en vivo y explicar 10 de las 34 pruebas. Algunas que sirven de ejemplo:
- `calcularNivel`: cambia de rango justo en 200, 600 y 1200 puntos.
- `TarjetaProducto`: al presionar el botón llama a `onAgregar` (spy).
- `Carrito`: el total de 2 × 29.990 + 49.990 da 109.970.
- `Registro`: rechaza a un menor de 18 años.
- `Comunidad`: un mensaje con HTML se muestra como texto.
- `App`: pagar sin sesión lleva al login; login y registro no muestran header ni footer.

## 4. Proceso de testeo (IE2.3.2)
- **Entorno:** `karma.conf.cjs` (Karma abre Chrome sin ventana, webpack + Babel compilan el JSX).
- **Escritura:** cada prueba prepara datos, ejecuta una acción y comprueba el resultado.
- **Mocks:** `createSpy` para funciones, `spyOn(window, 'open')` para WhatsApp y `spyOn(Storage.prototype, …)` para un `localStorage` lleno.
- **Resultados y cobertura:** `npm run test:coverage` (≈ 84 % de statements). Se explican también las partes que no se cubren.

## Preguntas que pueden hacer
- ¿Para qué sirve `key` en un `map`?
- ¿Cuál es la diferencia entre props y estado?
- ¿Qué es un formulario controlado?
- ¿Qué es un mock y para qué se usa?
- ¿Por qué es un riesgo guardar la contraseña en texto plano?
- ¿Qué mide la cobertura de ramas (branches)?
