# Documento de cobertura de testing · Level-Up Gamer (React)

## 1. Herramientas

| Herramienta | Para qué se usa |
| --- | --- |
| Jasmine | escribir las pruebas (`describe`, `it`, `expect`) y los mocks (`spyOn`, `createSpy`) |
| Karma | abrir Chrome sin ventana y ejecutar las pruebas |
| webpack + Babel | compilar el JSX de los componentes dentro de las pruebas |
| React Testing Library | dibujar los componentes y consultar el DOM (`render`, `screen`, `fireEvent`) |
| karma-coverage (Istanbul) | medir la cobertura de código |

La configuración está en `karma.conf.cjs`.

## 2. Cómo ejecutar

```bash
npm install
npm test                 # corre las pruebas una vez
npm run test:coverage    # además genera coverage/html/index.html
```

Necesita Google Chrome instalado. Si Karma no lo encuentra: `CHROME_BIN=/ruta/a/chrome npm test`.

## 3. Qué se prueba

| Archivo | Qué cubre | Pruebas |
| --- | --- | --- |
| `utilidades.spec.js` | `formato`, `niveles`, `almacenamiento`, `eventos`, `recomendaciones` | 8 |
| `componentes.spec.jsx` | `TarjetaProducto`, `Catalogo`, `Carrito`, `Encabezado` (con la lupa), `PiePagina`, `BotonSoporte` | 10 |
| `paginas.spec.jsx` | `Login`, `Registro`, `Perfil`, `Comunidad` (incluye XSS), `TarjetaEvento` | 8 |
| `app.spec.jsx` | la app completa: carrito, stock, pago sin sesión, búsqueda, login/registro sin header ni footer, flujo registro → login → perfil, check-in | 8 |

Total: **34 pruebas**. Cada una revisa un comportamiento concreto (no solo que el componente
«se dibuje»): límites de rangos, validaciones de formularios, tope de stock, bloqueo de eventos
finalizados, texto con HTML mostrado como texto, etc.

## 4. Conceptos de testeo aplicados

- **Entorno de pruebas:** Karma + Jasmine en Chrome sin ventana; las pruebas se ejecutan en orden aleatorio.
- **Aislamiento:** `00-configuracion.spec.js` limpia el DOM, el `localStorage` y el `#` después de cada prueba.
- **Mocks:**
  - `jasmine.createSpy` para comprobar que un componente llama a la función que recibe por props.
  - `spyOn(window, 'open')` para no abrir WhatsApp de verdad.
  - `spyOn(Storage.prototype, 'setItem')` para simular un `localStorage` lleno.
- **Estructura:** preparar los datos, ejecutar la acción y comprobar el resultado.
- **Casos límite:** 199 y 200 puntos, edad de 17 años, producto sin stock, evento que termina hoy, JSON dañado.
- **Datos de prueba propios** (`datos-prueba.js`), para no depender del catálogo real.

## 5. Resultados

Ejecución con Chrome Headless 131:

| Métrica | Resultado |
| --- | --- |
| Pruebas ejecutadas / exitosas | 34 / 34 |
| Statements | 84,26 % (257 de 305) |
| Branches | 79,26 % (130 de 164) |
| Functions | 82,25 % (102 de 124) |
| Lines | 86,08 % (235 de 273) |

Se corrió varias veces seguidas con resultado estable. Al ejecutar `npm run test:coverage` en tu
equipo debería salir lo mismo; pega aquí una captura de la consola de Karma y del informe
`coverage/html/index.html`.

## 6. Análisis de la cobertura

- **Cubiertos al 100 % de líneas:** `utils/`, `data/`, `Login`, `Registro`, `Encabezado`, `TarjetaProducto`, `PiePagina`, `Aviso`, `BotonSoporte`, `Catalogo`, `FondoAuth` y `Productos`.
- **Cubiertos parcialmente:**
  - `App.jsx` (72 % de líneas): faltan las funciones de cambiar cantidades, quitar productos, vaciar el carrito, cerrar sesión y canjear premios (los botones del carrito sí se prueban en `componentes.spec.jsx`, pero ahí `App` no participa).
  - `Buscador.jsx` (60 %): se prueba escribir en el texto, pero no el cambio de categoría.
  - `Carrito`, `Perfil` y `Comunidad` (83–91 %): faltan detalles menores, como eliminar un consejo del foro.
- **No se prueba:** `main.jsx` (solo monta la app), los estilos CSS (el aspecto se revisó a mano
  en el navegador) y el video de YouTube de Eventos.
- **Siguiente paso:** agregar pruebas para los puntos parcialmente cubiertos y, más adelante,
  pruebas de integración contra el backend.
