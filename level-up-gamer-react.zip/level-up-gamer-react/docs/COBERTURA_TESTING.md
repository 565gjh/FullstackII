# Documento de cobertura de testing · Level-Up Gamer (React)

**Herramientas:** Jasmine 5 (pruebas y *spies*), Karma 6 (ejecutor en Chrome sin ventana), webpack + Babel (compila JSX),
React Testing Library (dibuja componentes y consulta el DOM), karma-coverage / Istanbul (cobertura).

## 1. Cómo ejecutar
```bash
npm install
npm test                 # una ejecución
npm run test:coverage    # ejecución + informe en coverage/html/index.html
```
Requiere Google Chrome instalado (si no lo detecta: `CHROME_BIN=/ruta/a/chrome npm test`).

## 2. Elementos cubiertos
| Archivo de pruebas | Elementos | Qué se verifica |
| --- | --- | --- |
| `utilidades.spec.js` | `formato`, `niveles`, `almacenamiento`, `eventos`, `recomendaciones` | Entradas/salidas, límites de rango, JSON dañado, fallos de `localStorage` (mock), exclusión de productos agotados. |
| `productos.spec.jsx` | `TarjetaProducto`, `Catalogo`, `Buscador`, `Recomendaciones` | Props, eventos (`onAgregar`, `onCambiar…`), renderizado condicional, formulario controlado, estados de stock (normal / últimas unidades / sin stock). |
| `carrito-encabezado.spec.jsx` | `Carrito`, `Encabezado` (menú y lupa), `PiePagina`, `Portada`, `Aviso`, `BotonSoporte` | Total, +/− con tope de stock, quitar/vaciar/pagar, sesión en menú, lupa solo en catálogo, enlaces de contacto y redes, `window.open` simulado. |
| `paginas.spec.jsx` | `Login`, `Registro`, `Perfil`, `Comunidad`, `TarjetaEvento` | Validaciones, puntos, canje, XSS, eliminar consejo, evento finalizado. |
| `app.spec.jsx` | `App` (integración) | Navegación por `#`, contador, título, `localStorage`, pago sin sesión → login, límite de stock, producto agotado, búsqueda desde la lupa. |

Total: **74 pruebas** (conteo de `it(...)` en `src/tests`). Confirma el número real con `npm test`.

## 3. Conceptos de testeo aplicados
- **Entorno:** `karma.conf.cjs` (frameworks `jasmine` + `webpack`, `ChromeHeadless`, orden aleatorio de pruebas).
- **Aislamiento:** hook global (`00-configuracion.spec.js`) limpia DOM, `localStorage` y `#` tras cada prueba.
- **Mocks / spies:** `jasmine.createSpy` (callbacks de props), `spyOn(window,'open')`, `spyOn(Storage.prototype,…)`.
- **Patrón AAA** (preparar, actuar, afirmar) en cada `it`.
- **Casos límite:** 199/200 puntos, edad 17/18+, texto solo con espacios, carrito vacío, evento finalizado.

## 4. Resultados y cobertura (completar con tu ejecución)
| Métrica | Resultado |
| --- | --- |
| Pruebas ejecutadas / exitosas | [__ / __] |
| Statements | [__ %] |
| Branches | [__ %] |
| Functions | [__ %] |
| Lines | [__ %] |

Pega aquí una captura de la consola de Karma y del informe `coverage/html/index.html`.

## 5. Alcance no cubierto
`main.jsx` (punto de entrada), estilos CSS, imágenes e `iframe` de YouTube. No se prueban visualmente los estilos de Bootstrap.
