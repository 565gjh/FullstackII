// Configuración de Karma + Jasmine para los componentes React.
// Karma lanza Chrome sin ventana; webpack + Babel compilan el JSX de cada prueba.
// Ejecutar:  npm test            (una vez)
//            npm run test:watch  (se repite al guardar)
//            npm run test:coverage (agrega informe de cobertura en /coverage)

const conCobertura = process.env.COVERAGE === 'true'

module.exports = function (config) {
  config.set({
    basePath: '',
    frameworks: ['jasmine', 'webpack'],

    // Todas las pruebas viven en src/tests y terminan en .spec.js o .spec.jsx
    files: [{ pattern: 'src/tests/**/*.spec.{js,jsx}', watched: false }],
    preprocessors: {
      'src/tests/**/*.spec.{js,jsx}': ['webpack', 'sourcemap'],
    },

    webpack: {
      mode: 'development',
      devtool: 'inline-source-map',
      resolve: { extensions: ['.js', '.jsx'] },
      module: {
        rules: [
          {
            test: /\.jsx?$/,
            exclude: /node_modules/,
            use: {
              loader: 'babel-loader',
              options: {
                presets: [
                  ['@babel/preset-env', { targets: { chrome: '120' } }],
                  ['@babel/preset-react', { runtime: 'automatic' }],
                ],
                // Instrumenta el código SOLO si se pide cobertura (excluye las pruebas).
                plugins: conCobertura
                  ? [['istanbul', { exclude: ['src/tests/**', '**/*.spec.*'] }]]
                  : [],
              },
            },
          },
          // Las imágenes del catálogo se incrustan como data-URI (no hay servidor de archivos).
          { test: /\.(png|jpe?g|webp|avif|gif|svg)$/i, type: 'asset/inline' },
        ],
      },
    },

    reporters: conCobertura ? ['spec', 'coverage'] : ['spec'],
    coverageReporter: {
      dir: 'coverage',
      reporters: [{ type: 'html', subdir: 'html' }, { type: 'text-summary' }, { type: 'lcovonly', subdir: '.' }],
    },

    browsers: ['ChromeHeadlessSinSandbox'],
    customLaunchers: {
      ChromeHeadlessSinSandbox: { base: 'ChromeHeadless', flags: ['--no-sandbox'] },
    },
    client: { jasmine: { random: true } },
    singleRun: false,
  })
}
