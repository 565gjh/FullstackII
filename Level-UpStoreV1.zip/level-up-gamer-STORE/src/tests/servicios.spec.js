// Pruebas de la capa de servicios (V1): mensajes de error de axios y las funciones
// de productos.js con la instancia de axios simulada (no se necesita Spring Boot).
import { mensajeDeError } from '../servicios/errores.js'
import { resolverImagen } from '../servicios/imagenes.js'

// configuracion.js simula productos.js para las páginas; aquí se prueba el real.
vi.unmock('../servicios/productos.js')
vi.mock('../servicios/api.js', () => ({
  default: { get: vi.fn(), post: vi.fn(), put: vi.fn(), delete: vi.fn() },
}))

const { default: api } = await import('../servicios/api.js')
const servicio = await import('../servicios/productos.js')

describe('mensajeDeError', () => {
  it('con respuesta del servidor usa el mensaje de la API', () => {
    const error = { response: { status: 404, data: { status: 404, mensaje: 'No existe el producto 9', campos: {} } } }
    expect(mensajeDeError(error)).toBe('No existe el producto 9')
  })

  it('con respuesta sin cuerpo informa el código', () => {
    expect(mensajeDeError({ response: { status: 500 } })).toBe('El servidor respondió con el error 500.')
  })

  it('sin respuesta (API apagada o CORS) avisa que no hay conexión', () => {
    expect(mensajeDeError({ request: {} })).toMatch(/No hay conexión con el servidor/)
  })

  it('un error antes de enviar devuelve su propio mensaje', () => {
    expect(mensajeDeError(new Error('falló la configuración'))).toBe('falló la configuración')
  })
})

describe('resolverImagen', () => {
  it('traduce el nombre de un archivo de src/assets a su URL', () => {
    expect(resolverImagen('catannew.png')).toMatch(/catannew/)
  })

  it('respeta las URL completas y usa el logo como respaldo', () => {
    expect(resolverImagen('https://ejemplo.cl/foto.png')).toBe('https://ejemplo.cl/foto.png')
    expect(resolverImagen('')).toBe('/logo.png')
    expect(resolverImagen('no-existe.png')).toBe('/logo.png')
  })
})

describe('servicios/productos.js', () => {
  beforeEach(() => vi.clearAllMocks())

  it('listarProductos pide GET /productos con la categoría como params', async () => {
    api.get.mockResolvedValue({ data: [{ id: 1, nombre: 'Catan', imagen: 'catannew.png' }] })
    const datos = await servicio.listarProductos('Juegos de Mesa')
    expect(api.get).toHaveBeenCalledWith('/productos', { params: { categoria: 'Juegos de Mesa' } })
    expect(datos[0].imagen).toMatch(/catannew/)
  })

  it('sin categoría no envía el parámetro', async () => {
    api.get.mockResolvedValue({ data: [] })
    await servicio.listarProductos()
    expect(api.get).toHaveBeenCalledWith('/productos', { params: { categoria: undefined } })
  })

  it('obtenerProducto, crear, actualizar y eliminar usan la ruta y el verbo correctos', async () => {
    const producto = { nombre: 'Dixit', imagen: '' }
    api.get.mockResolvedValue({ data: { id: 3, ...producto } })
    api.post.mockResolvedValue({ data: { id: 11, ...producto } })
    api.put.mockResolvedValue({ data: { id: 11, ...producto } })
    api.delete.mockResolvedValue({ status: 204 })

    expect((await servicio.obtenerProducto(3)).id).toBe(3)
    expect(api.get).toHaveBeenCalledWith('/productos/3')
    expect((await servicio.crearProducto(producto)).id).toBe(11)
    expect(api.post).toHaveBeenCalledWith('/productos', producto)
    await servicio.actualizarProducto(11, producto)
    expect(api.put).toHaveBeenCalledWith('/productos/11', producto)
    await servicio.eliminarProducto(11)
    expect(api.delete).toHaveBeenCalledWith('/productos/11')
  })
})
