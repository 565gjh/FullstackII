// Configuración global de las pruebas (Vitest). Se carga ANTES de cada archivo de pruebas
// porque vite.config.js la declara en test.setupFiles.
import '@testing-library/jest-dom/vitest' // matchers extra: toBeInTheDocument, toBeDisabled, toHaveTextContent…
import { cleanup } from '@testing-library/react'
import { afterEach, vi } from 'vitest'

// V1: el catálogo y el detalle piden los productos a la API con axios. En las pruebas no hay
// servidor, así que se reemplaza la capa de servicios por una versión que responde con el
// catálogo local, igual que lo haría Spring Boot (filtro por categoría, 404 y 400).
vi.mock('../servicios/productos.js', async () => {
  const { default: productos } = await import('../data/productos.js')
  const fallo = (status, mensaje) => Object.assign(new Error(mensaje), { response: { status, data: { status, mensaje, campos: {} } } })
  return {
    listarProductos: vi.fn(async (categoria) =>
      categoria ? productos.filter((p) => p.categoria === categoria) : productos,
    ),
    obtenerProducto: vi.fn(async (id) => {
      if (!/^\d+$/.test(String(id))) throw fallo(400, `El valor «${id}» no es válido`)
      const producto = productos.find((p) => p.id === Number(id))
      if (!producto) throw fallo(404, `No existe el producto ${id}`)
      return producto
    }),
    crearProducto: vi.fn(),
    actualizarProducto: vi.fn(),
    eliminarProducto: vi.fn(),
  }
})

// jsdom no implementa window.scrollTo (el Layout lo llama al cambiar de página)
window.scrollTo = vi.fn()

// jsdom tampoco implementa window.matchMedia, y el Offcanvas de React Bootstrap (el carrito)
// lo usa al dibujarse. Esta versión mínima responde "no coincide" y acepta los listeners.
// Es una función normal (no vi.fn) para que vi.restoreAllMocks no la deshaga.
window.matchMedia = (query) => ({
  matches: false,
  media: query,
  onchange: null,
  addListener() {},
  removeListener() {},
  addEventListener() {},
  removeEventListener() {},
  dispatchEvent: () => false,
})

// Después de CADA prueba: limpia el DOM, el localStorage y los mocks (vi.spyOn),
// para que una prueba no afecte a la siguiente. La dirección no hay que limpiarla:
// cada prueba crea su propio MemoryRouter.
afterEach(() => {
  cleanup()
  localStorage.clear()
  vi.restoreAllMocks()
})
