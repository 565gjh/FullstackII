import { useEffect, useState } from 'react'
import { Container, Button, Alert, Spinner } from 'react-bootstrap'
import { useFiltroCatalogo } from '../hooks/useFiltroCatalogo.js'
import { listarProductos } from '../servicios/productos.js'
import { mensajeDeError } from '../servicios/errores.js'

import Portada from '../componentes/Portada.jsx'
import Catalogo from '../componentes/Catalogo.jsx'

// Catálogo. La búsqueda se escribe en la lupa del header y vive en la URL (?buscar=…&categoria=…).
// V1: los productos llegan desde la API (GET /api/productos) con axios. La categoría la filtra
// el servidor (viaja como params); el texto del buscador se sigue filtrando en el navegador.
// "catalogo" (props) trae el stock ya descontado con lo del carrito (lo calcula App).
function Productos({ catalogo, onAgregar, onSincronizar = () => {} }) {
  const { texto, categoria, limpiar } = useFiltroCatalogo()

  // Toda página que pide datos a una API tiene estos tres estados.
  const [productos, setProductos] = useState([])
  const [cargando, setCargando] = useState(true)
  const [error, setError] = useState(null)
  const [intento, setIntento] = useState(0) // sube en 1 para "Reintentar"

  // Pedir datos a un servidor es hablarle a algo que no es React: va en un efecto.
  // Se repite cada vez que cambia la categoría o se pulsa Reintentar.
  useEffect(() => {
    // Si el usuario cambia de categoría antes de que llegue la respuesta anterior,
    // "ignorar" evita que esa respuesta vieja pise a la nueva.
    let ignorar = false

    async function cargar() {
      setCargando(true)
      setError(null)
      try {
        const datos = await listarProductos(categoria === 'Todas' ? undefined : categoria)
        if (!ignorar) {
          setProductos(datos)
          onSincronizar(datos, categoria === 'Todas') // App los usa para el carrito y el stock
        }
      } catch (e) {
        if (!ignorar) setError(mensajeDeError(e))
      } finally {
        if (!ignorar) setCargando(false)
      }
    }

    cargar()
    return () => {
      ignorar = true
    }
  }, [categoria, intento, onSincronizar])

  // datos calculados: a cada producto de la API se le aplica el stock descontado por App
  const hayFiltro = texto.trim() !== '' || categoria !== 'Todas'
  const productosFiltrados = productos
    .map((p) => catalogo.find((c) => c.id === p.id) ?? p)
    .filter((p) => p.nombre.toLowerCase().includes(texto.trim().toLowerCase()))

  return (
    <>
      <Portada
        titulo="Catálogo de Productos Oficiales"
        texto="Explora nuestra selección completa de hardware, consolas, periféricos, juegos de mesa y textiles personalizados. Calidad garantizada para la comunidad gamer."
      />

      <Container className="contenedor">
        <section className="panel">
          <h2>Inventario Disponible</h2>

          {cargando ? (
            <div className="text-center py-5">
              <Spinner animation="border" role="status" />
              <p className="resumen-busqueda mt-2">Cargando productos…</p>
            </div>
          ) : error ? (
            <Alert variant="danger">
              <Alert.Heading as="h3" className="h5">
                No pudimos cargar el catálogo
              </Alert.Heading>
              <p>{error}</p>
              <Button variant="outline-danger" onClick={() => setIntento((n) => n + 1)}>
                Reintentar
              </Button>
            </Alert>
          ) : (
            <>
              {/* filtro activo y botón para limpiarlo */}
              {hayFiltro ? (
                <p className="resumen-busqueda">
                  Mostrando {productosFiltrados.length} de {catalogo.length} productos.{' '}
                  <Button variant="link" className="p-0 align-baseline" onClick={limpiar}>
                    Limpiar búsqueda
                  </Button>
                </p>
              ) : (
                <p className="resumen-busqueda">
                  Usa la lupa 🔍 del menú superior para buscar por nombre o categoría.
                </p>
              )}

              <Catalogo productos={productosFiltrados} onAgregar={onAgregar} />
            </>
          )}
        </section>
      </Container>
    </>
  )
}

export default Productos
