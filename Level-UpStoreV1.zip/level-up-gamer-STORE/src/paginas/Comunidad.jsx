import { useState, useEffect } from 'react'
import { Container, Row, Col, Card, Form, Button } from 'react-bootstrap'

import Portada from '../componentes/Portada.jsx'
import { noticias, guias, consejoPorDefecto } from '../data/comunidad.js'
import { leerGuardado, guardar } from '../utils/almacenamiento.js'

const CLAVE_CONSEJOS = 'consejosComunidad'

// carga los consejos guardados o parte con el de ejemplo
function cargarConsejosGuardados() {
  const guardados = leerGuardado(CLAVE_CONSEJOS, null)
  return Array.isArray(guardados) ? guardados : [consejoPorDefecto]
}

// Comunidad: noticias, guías y foro de consejos (se guardan en localStorage).
// React escapa el texto, así un mensaje con HTML se ve como texto y no se ejecuta (evita XSS).
function Comunidad({ nombreUsuario }) {
  // estado (useState con función para leer localStorage una sola vez)
  const [consejos, setConsejos] = useState(cargarConsejosGuardados)
  // campos del formulario; el nick parte con el nombre del usuario si hay sesión
  const [autor, setAutor] = useState(nombreUsuario)
  const [texto, setTexto] = useState('')

  // se guarda cada vez que cambia la lista
  useEffect(() => {
    guardar(CLAVE_CONSEJOS, consejos)
  }, [consejos])

  // funciones
  function publicarConsejo(evento) {
    evento.preventDefault()
    const autorLimpio = autor.trim()
    const textoLimpio = texto.trim()
    if (!autorLimpio || !textoLimpio) return

    // arreglo nuevo con el consejo al principio
    setConsejos((actuales) => [{ id: Date.now(), autor: autorLimpio, texto: textoLimpio }, ...actuales])
    setTexto('')
  }

  function eliminarConsejo(id) {
    setConsejos((actuales) => actuales.filter((consejo) => consejo.id !== id))
  }

  return (
    <>
      <Portada
        titulo="Centro de Comunidad y Guías"
        texto="Mantente al día con las últimas novedades de la industria y descubre consejos profesionales para elevar tu nivel de juego."
      />

      <Container className="contenedor">
        <section className="panel">
          <h2>Noticias y Novedades Gamer</h2>
          <Row xs={1} className="g-3">
            {noticias.map((noticia) => (
              <Col key={noticia.id}>
                <Card as="article" className="tarjeta-info">
                  <Card.Body>
                    <span className="etiqueta-noticia">{noticia.etiqueta}</span>
                    <Card.Title as="h3">{noticia.titulo}</Card.Title>
                    <Card.Text>{noticia.texto}</Card.Text>
                  </Card.Body>
                </Card>
              </Col>
            ))}
          </Row>
        </section>

        <section className="panel">
          <h2>Guías Prácticas y Consejos</h2>
          <Row xs={1} className="g-3">
            {guias.map((guia) => (
              <Col key={guia.id}>
                <Card as="article" className="tarjeta-info">
                  <Card.Body>
                    <Card.Title as="h3">{guia.titulo}</Card.Title>
                    <Card.Text>{guia.texto}</Card.Text>
                    {/* la lista solo sale si la guía tiene pasos */}
                    {guia.pasos.length > 0 && (
                      <ol className="pasos-guia">
                        {guia.pasos.map((paso) => (
                          <li key={paso.titulo}>
                            <strong>{paso.titulo}.</strong> {paso.texto}
                          </li>
                        ))}
                      </ol>
                    )}
                  </Card.Body>
                </Card>
              </Col>
            ))}
          </Row>
        </section>

        <section className="panel">
          <h2>Comparte tu Consejo con la Comunidad</h2>
          <p>¿Tienes un truco o recomendación para otros jugadores? Compártelo aquí.</p>

          <Form onSubmit={publicarConsejo}>
            <Form.Group className="mb-3" controlId="autorConsejo">
              <Form.Label>Tu Nombre / Nick</Form.Label>
              <Form.Control
                type="text"
                placeholder="Ej: JefreyGamer"
                value={autor}
                onChange={(evento) => setAutor(evento.target.value)}
                required
              />
            </Form.Group>
            <Form.Group className="mb-3" controlId="textoConsejo">
              <Form.Label>Consejo o Tip</Form.Label>
              <Form.Control
                type="text"
                placeholder="Ej: Usa cable de red en vez de WiFi para bajar el ping."
                value={texto}
                onChange={(evento) => setTexto(evento.target.value)}
                required
              />
            </Form.Group>
            <Button type="submit" variant="outline-success" className="w-100">
              Publicar en el Foro
            </Button>
          </Form>

          <h3 className="fs-6 mt-4 mb-3">Consejos recientes de la comunidad:</h3>
          {consejos.length === 0 ? (
            <p className="mb-0">Todavía no hay consejos. ¡Publica el primero!</p>
          ) : (
            consejos.map((consejo) => (
              <div key={consejo.id} className="comentario">
                <div>
                  <strong>{consejo.autor}:</strong>
                  <p className="mb-0">{consejo.texto}</p>
                </div>
                <Button
                  variant="link"
                  size="sm"
                  className="text-danger"
                  aria-label={`Eliminar el consejo de ${consejo.autor}`}
                  onClick={() => eliminarConsejo(consejo.id)}
                >
                  ✕
                </Button>
              </div>
            ))
          )}
        </section>
      </Container>
    </>
  )
}

export default Comunidad
