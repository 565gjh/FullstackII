import { useEffect, useState } from 'react'
import { Link, useNavigate, useParams } from 'react-router'
import { Container, Row, Col, Button, Badge, Alert, Spinner } from 'react-bootstrap'
import { formatearPrecio } from '../utils/formato.js'
import { obtenerProducto } from '../servicios/productos.js'
import { mensajeDeError } from '../servicios/errores.js'

// Detalle de un producto: la ruta es /producto/:id y useParams entrega el id.
// V1: el producto se pide a la API (GET /api/productos/{id}) con axios.
// Ya no hace falta Number(id): el id viaja en la URL y lo convierte Spring Boot
// (@PathVariable Long id). El «no encontrado» lo decide el servidor con un 404.
// "catalogo" (props) trae el stock ya descontado con lo del carrito (lo calcula App).
function DetalleProducto({ catalogo, onAgregar, onSincronizar = () => {} }) {
  const { id } = useParams() // para /producto/3 → id vale "3" (texto)
  const navegar = useNavigate()

  const [datos, setDatos] = useState(null)
  const [cargando, setCargando] = useState(true)
  const [error, setError] = useState(null)
  const [noExiste, setNoExiste] = useState(false)
  const [intento, setIntento] = useState(0) // sube en 1 para "Reintentar"

  useEffect(() => {
    let ignorar = false

    async function cargar() {
      setCargando(true)
      setError(null)
      setNoExiste(false)
      try {
        const producto = await obtenerProducto(id)
        if (!ignorar) {
          setDatos(producto)
          onSincronizar([producto])
        }
      } catch (e) {
        if (ignorar) return
        // 404: no existe · 400: el id no es un número (/producto/abc).
        // Cualquier otro error es un problema de conexión o del servidor.
        const estado = e.response?.status
        if (estado === 404 || estado === 400) {
          setNoExiste(true)
        } else {
          setError(mensajeDeError(e))
        }
      } finally {
        if (!ignorar) setCargando(false)
      }
    }

    cargar()
    return () => {
      ignorar = true
    }
  }, [id, intento, onSincronizar])

  if (cargando) {
    return (
      <Container className="contenedor py-4">
        <div className="text-center py-5">
          <Spinner animation="border" role="status" />
          <p className="mt-2">Cargando producto…</p>
        </div>
      </Container>
    )
  }

  // id inventado (/producto/999): mensaje claro en vez de una pantalla rota
  if (noExiste) {
    return (
      <Container className="contenedor py-4">
        <Alert variant="warning">
          <h1 className="h4">Producto no encontrado</h1>
          <p className="mb-3">
            No existe ningún producto con el código <code>{id}</code>.
          </p>
          <Button as={Link} to="/catalogo" variant="primary">
            Ver el catálogo
          </Button>
        </Alert>
      </Container>
    )
  }

  if (error) {
    return (
      <Container className="contenedor py-4">
        <Alert variant="danger">
          <h1 className="h4">No pudimos cargar el producto</h1>
          <p className="mb-3">{error}</p>
          <Button variant="outline-danger" onClick={() => setIntento((n) => n + 1)}>
            Reintentar
          </Button>
        </Alert>
      </Container>
    )
  }

  // se muestra la versión de App (con el stock descontado); si aún no está, la de la API
  const producto = catalogo.find((p) => p.id === datos.id) ?? datos
  const { nombre, categoria, codigo, descripcion, precio, imagen, fabricante, distribuidor, stock } =
    producto
  const enCarrito = producto.enCarrito ?? 0
  const sinStock = stock <= 0

  return (
    <Container className="contenedor py-4">
      {/* navegar(-1) equivale al botón «atrás» del navegador */}
      <Button variant="link" className="p-0 mb-3" onClick={() => navegar(-1)}>
        ← Volver
      </Button>

      <section className="panel">
        <Row className="g-4">
          <Col md={5}>
            <img src={imagen} alt={`Imagen de ${nombre}`} className="img-fluid rounded" />
          </Col>
          <Col md={7} className="d-flex flex-column">
            <Badge className="etiqueta-producto align-self-start mb-2">
              [{codigo}] {categoria}
            </Badge>
            <h1 className="h3">{nombre}</h1>
            <p>{descripcion}</p>
            <p className="mb-1">
              <strong>Fabricante:</strong> {fabricante}
            </p>
            <p>
              <strong>Distribuidor:</strong> {distribuidor}
            </p>
            <p className="precio">{formatearPrecio(precio)}</p>
            <p className={`estado-stock ${sinStock ? 'agotado' : 'disponible'}`}>
              {sinStock
                ? enCarrito > 0
                  ? 'Ya tienes todas las unidades en tu carrito'
                  : 'No hay stock disponible'
                : `${stock} unidades disponibles`}
            </p>
            <div className="mt-auto">
              <Button variant="primary" disabled={sinStock} onClick={() => onAgregar(producto)}>
                {sinStock ? 'Sin stock' : 'Añadir al Carrito'}
              </Button>
            </div>
          </Col>
        </Row>
      </section>
    </Container>
  )
}

export default DetalleProducto
