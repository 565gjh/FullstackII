package com.example.levelup_api.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.levelup_api.model.Producto;

public interface ProductoRepository extends JpaRepository<Producto, Long> {

    // SELECT ... WHERE categoria = ? ORDER BY id
    List<Producto> findByCategoriaOrderById(String categoria);

    // Para no repetir códigos de producto
    boolean existsByCodigo(String codigo);

    boolean existsByCodigoAndIdNot(String codigo, Long id);
}
