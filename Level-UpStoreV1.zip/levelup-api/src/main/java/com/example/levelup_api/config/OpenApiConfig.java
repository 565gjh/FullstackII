package com.example.levelup_api.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;

// Datos que muestra Swagger UI
@Configuration
public class OpenApiConfig {

    @Bean
    public OpenAPI levelUpOpenApi() {
        return new OpenAPI().info(new Info()
                .title("Level-Up Gamer API")
                .version("v1")
                .description("API REST de la tienda Level-Up Gamer: CRUD de productos consumido por el frontend React con axios."));
    }
}
