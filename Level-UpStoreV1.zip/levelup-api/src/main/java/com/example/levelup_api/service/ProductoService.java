package com.example.levelup_api.service;

import java.util.List;

import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.levelup_api.exception.ResourceNotFoundException;
import com.example.levelup_api.exception.InsufficientStockException;
import com.example.levelup_api.model.Producto;
import com.example.levelup_api.repository.ProductoRepository;

@Service
public class ProductoService {

    private final ProductoRepository repositorio;

    public ProductoService(ProductoRepository repositorio) {
        this.repositorio = repositorio;
    }

    @Transactional(readOnly = true)
    public List<Producto> listar(String categoria) {
        if (categoria == null || categoria.isBlank()) {
            return repositorio.findAll(Sort.by("id"));
        }
        return repositorio.findByCategoriaOrderById(categoria);
    }

    // Lanza 404 si el id no existe
    @Transactional(readOnly = true)
    public Producto buscar(Long id) {
        return repositorio.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("No existe el producto " + id));
    }

    @Transactional
    public Producto crear(Producto producto) {
        // Un POST nunca sobrescribe un producto existente
        producto.setId(null);
        if (repositorio.existsByCodigo(producto.getCodigo())) {
            throw new InsufficientStockException("Ya existe un producto con el código " + producto.getCodigo());
        }
        return repositorio.save(producto);
    }

    @Transactional
    public Producto actualizar(Long id, Producto datos) {
        Producto actual = buscar(id);
        if (repositorio.existsByCodigoAndIdNot(datos.getCodigo(), id)) {
            throw new InsufficientStockException("Ya existe otro producto con el código " + datos.getCodigo());
        }
        actual.setCodigo(datos.getCodigo());
        actual.setCategoria(datos.getCategoria());
        actual.setNombre(datos.getNombre());
        actual.setPrecio(datos.getPrecio());
        actual.setStock(datos.getStock());
        actual.setImagen(datos.getImagen());
        actual.setDescripcion(datos.getDescripcion());
        actual.setFabricante(datos.getFabricante());
        actual.setDistribuidor(datos.getDistribuidor());
        return repositorio.save(actual);
    }

    @Transactional
    public void eliminar(Long id) {
        repositorio.delete(buscar(id));
    }
}
