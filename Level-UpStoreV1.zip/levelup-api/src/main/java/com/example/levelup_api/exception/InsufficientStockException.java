package com.example.levelup_api.exception;

// Se responde como 409 (sin stock o código repetido)
public class InsufficientStockException extends RuntimeException {

    public InsufficientStockException(String mensaje) {
        super(mensaje);
    }
}
