package com.example.levelup_api.exception;

import java.util.Map;

// Formato común de error: { status, mensaje, campos }
public record ErrorApi(int status, String mensaje, Map<String, String> campos) {
}
