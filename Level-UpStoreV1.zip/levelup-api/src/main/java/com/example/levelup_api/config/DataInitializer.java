package com.example.levelup_api.config;

import java.util.List;

import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.example.levelup_api.model.Producto;
import com.example.levelup_api.repository.ProductoRepository;

// Carga los 10 productos de la tienda al arrancar
@Component
public class DataInitializer implements CommandLineRunner {

    private final ProductoRepository repositorio;

    public DataInitializer(ProductoRepository repositorio) {
        this.repositorio = repositorio;
    }

    @Override
    public void run(String... args) {
        if (repositorio.count() > 0) {
            return;
        }
        repositorio.saveAll(List.of(
                new Producto("JM001", "Juegos de Mesa", "Catan", 29990, 12, "catannew.png",
                        "Un clásico juego de estrategia donde los jugadores compiten por colonizar y expandirse en la isla de Catan. Ideal para 3-4 jugadores y perfecto para noches de juego en familia o con amigos.",
                        "KOSMOS / Devir", "Devir Chile"),
                new Producto("JM002", "Juegos de Mesa", "Carcassonne", 24990, 8, "images.jpg",
                        "Un juego de colocación de fichas donde los jugadores construyen el paisaje alrededor de la fortaleza medieval de Carcassonne. Ideal para 2-5 jugadores y fácil de aprender.",
                        "Hans im Glück / Devir", "Devir Chile"),
                new Producto("AC001", "Accesorios", "Controlador Inalámbrico Xbox Series X", 59990, 5, "controlxboxsx.png",
                        "Ofrece una experiencia de juego cómoda con botones mapeables y una respuesta táctil mejorada. Compatible con consolas Xbox y PC.",
                        "Microsoft", "Distribuidores Oficiales Latam"),
                new Producto("AC002", "Accesorios", "Auriculares Gamer HyperX Cloud II", 79990, 0, "hyperxcloudii.avif",
                        "Proporcionan un sonido envolvente de calidad con un micrófono desmontable y almohadillas de espuma viscoelástica para mayor comodidad durante largas sesiones de juego.",
                        "HP / HyperX", "HyperX Chile"),
                new Producto("CO001", "Consolas", "PlayStation 5", 549900, 3, "ps5-product.webp",
                        "La consola de última generación de Sony, que ofrece gráficos impresionantes y tiempos de carga ultrarrápidos para una experiencia de juego inmersiva.",
                        "Sony Interactive Entertainment", "Sony Chile / Microplay"),
                new Producto("CG001", "Computadores Gamers", "PC Gamer ASUS ROG Strix", 1299900, 2, "h732.png",
                        "Un potente equipo diseñado para los gamers más exigentes, equipado con los últimos componentes para ofrecer un rendimiento excepcional en cualquier juego.",
                        "ASUS / Republic of Gamers", "ASUS Chile / Ingram Micro"),
                new Producto("SG001", "Sillas Gamers", "Silla Gamer Secretlab Titan", 349900, 4, "teamsecret-titanevo.webp",
                        "Diseñada para el máximo confort, esta silla ofrece un soporte ergonómico y personalización ajustable para sesiones de juego prolongadas.",
                        "Secretlab", "ErgoGamer Corp Latam"),
                new Producto("MS001", "Mouse", "Mouse Gamer Logitech G502 HERO", 49990, 15, "640.webp",
                        "Con sensor de alta precisión y botones personalizables, este mouse es ideal para gamers que buscan un control preciso y personalización.",
                        "Logitech G", "Logitech Chile"),
                new Producto("MP001", "Mousepad", "Mousepad Razer Goliathus Extended Chroma", 29990, 20, "razer67.png",
                        "Ofrece un área de juego amplia con iluminación RGB personalizable, asegurando una superficie suave y uniforme para el movimiento del mouse.",
                        "Razer", "Razer Official Distributor"),
                new Producto("PP001", "Poleras Personalizadas", "Polera Gamer Personalizada 'Level-Up'", 14990, 30, "3041941_01.webp",
                        "Una camiseta cómoda y estilizada, con la posibilidad de personalizarla con tu gamer tag o diseño favorito.",
                        "Level-Up Custom Textiles", "Taller Gráfico Propio (Melipilla)")));
    }
}
