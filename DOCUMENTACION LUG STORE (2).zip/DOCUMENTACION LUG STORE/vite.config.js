import react from '@vitejs/plugin-react'
import { defineConfig } from 'vitest/config'

// https://vite.dev/config/  ·  https://vitest.dev/config/
export default defineConfig({
  plugins: [react()],
  test: {
    environment: 'jsdom', // un navegador simulado: no necesita Chrome
    globals: true, // describe, it, expect y vi disponibles sin importarlos
    setupFiles: './src/tests/configuracion.js',
    include: ['src/tests/**/*.{test,spec}.{js,jsx}'],
    css: false, // los estilos no se prueban
    coverage: {
      provider: 'v8',
      include: ['src/**/*.{js,jsx}'],
      exclude: ['src/tests/**', 'src/main.jsx', 'src/assets/**'],
      reporter: ['text', 'html'], // 'text' imprime la tabla por archivo en la terminal
      thresholds: { statements: 80, branches: 80, functions: 80, lines: 80 },
    },
  },
})
