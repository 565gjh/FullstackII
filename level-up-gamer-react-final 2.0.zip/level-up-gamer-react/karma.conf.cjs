// Configuración de Karma + Jasmine.
// Karma abre Chrome sin ventana y webpack + Babel compilan el JSX de las pruebas.
//   npm test               corre las pruebas una vez
//   npm run test:watch     las repite al guardar
//   npm run test:coverage  agrega el informe de cobertura en /coverage

const conCobertura = process.env.COVERAGE === 'true'

module.exports = function (config) {
  config.set({
    basePath: '',
    frameworks: ['jasmine', 'webpack'],

    // las pruebas están en src/tests y terminan en .spec.js o .spec.jsx
    // (dos patrones separados porque las llaves {js,jsx} fallan en algunos equipos)
    files: [
      { pattern: 'src/tests/**/*.spec.js', watched: false },
      { pattern: 'src/tests/**/*.spec.jsx', watched: false },
    ],
    preprocessors: {
      'src/tests/**/*.spec.js': ['webpack', 'sourcemap'],
      'src/tests/**/*.spec.jsx': ['webpack', 'sourcemap'],
    },

    webpack: {
      mode: 'development',
      devtool: 'inline-source-map',
      resolve: { extensions: ['.js', '.jsx'] },
      module: {
        rules: [
          {
            test: /\.jsx?$/,
            exclude: /node_modules/,
            use: {
              loader: 'babel-loader',
              options: {
                presets: [
                  ['@babel/preset-env', { targets: { chrome: '120' } }],
                  ['@babel/preset-react', { runtime: 'automatic' }],
                ],
                // solo se instrumenta el código cuando se pide cobertura
                plugins: conCobertura
                  ? [['istanbul', { exclude: ['src/tests/**', '**/*.spec.*'] }]]
                  : [],
              },
            },
          },
          // las imágenes se incrustan en el bundle (Karma no sirve archivos aparte)
          { test: /\.(png|jpe?g|webp|avif|gif|svg)$/i, type: 'asset/inline' },
        ],
      },
    },

    reporters: conCobertura ? ['spec', 'coverage'] : ['spec'],
    coverageReporter: {
      dir: 'coverage',
      reporters: [{ type: 'html', subdir: 'html' }, { type: 'text-summary' }, { type: 'lcovonly', subdir: '.' }],
    },

    browsers: ['ChromeHeadlessSinSandbox'],
    customLaunchers: {
      ChromeHeadlessSinSandbox: { base: 'ChromeHeadless', flags: ['--no-sandbox'] },
    },
    client: { jasmine: { random: true } },
    singleRun: false,
  })
}
