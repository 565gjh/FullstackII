# Level-Up Gamer · versión React

Segunda versión de la tienda **Level-Up Gamer**, migrada de HTML + CSS + JavaScript a
**React + Vite + React Bootstrap**, siguiendo la guía «React desde cero» (DSY1104).

## Cómo ejecutarlo

Necesitas Node.js LTS (22 o superior; mínimo 20.19).

```bash
npm install        # una sola vez: descarga las dependencias en node_modules
npm run dev        # servidor de desarrollo en http://localhost:5173
npm run build      # versión de producción en dist/
npm run preview    # prueba la versión de producción
npm run lint       # revisa el código con Oxlint
npm test               # pruebas unitarias (Jasmine + Karma, necesita Google Chrome)
npm run test:coverage  # lo mismo + informe de cobertura en coverage/html/index.html
```

`node_modules` y `dist` no se entregan ni se suben a Git.

## Estructura

```
level-up-gamer-react/
├── public/logo.png            favicon
├── index.html                 la única página HTML (con <div id="root">)
└── src/
    ├── main.jsx               punto de entrada: monta <App /> y carga Bootstrap
    ├── App.jsx                estado compartido (carrito, sesión, usuario, avisos) y página activa
    ├── index.css              estilos propios (paleta y tipografías de la v1)
    ├── assets/                imágenes de productos, logo y fondo
    ├── data/                  productos.js · eventos.js · comunidad.js · contacto.js
    ├── utils/                 formato.js · niveles.js · almacenamiento.js · eventos.js · recomendaciones.js
    ├── components/            Encabezado · Portada · PiePagina · Buscador · Catalogo ·
    │                          TarjetaProducto · Carrito · TarjetaEvento · Aviso ·
    │                          BotonSoporte · FondoAuth · Recomendaciones
    ├── paginas/               Inicio · Productos · Comunidad · Eventos · Login · Registro · Perfil
    └── tests/                 pruebas Jasmine (*.spec.js / *.spec.jsx)

karma.conf.cjs                 configuración de Karma (Chrome sin ventana + webpack + Babel)
docs/                          ERS (propuesta personalizada) · cobertura de testing · guía de presentación
```

## Qué se usa de cada clase de la guía

| Clase | Contenido | Dónde está |
| --- | --- | --- |
| 1 | Proyecto con Vite, `main.jsx`, `App.jsx` | `src/main.jsx`, `src/App.jsx` |
| 2 | JSX, componentes, React Bootstrap | `components/Encabezado`, `Portada`, `PiePagina` |
| 3 | Props, `map` con `key`, renderizado condicional | `Catalogo`, `TarjetaProducto`, `data/productos.js` |
| 4 | `useState`, eventos, estado levantado a `App` | `App.jsx`, `Carrito` (panel lateral) |
| 5 | Formularios controlados, `useEffect`, `localStorage` | `Buscador`, `Login`, `Registro`, `Comunidad`, `App.jsx` |

## Login y registro

Estas dos páginas se muestran sin header ni footer (`esPaginaAuth` en `App.jsx`) y con el fondo a
pantalla completa. Como no hay menú, `FondoAuth` trae un enlace «Volver a la tienda».

## De la v1 a React

| Versión 1 (HTML + JS) | Versión React |
| --- | --- |
| `index.html` | `paginas/Inicio.jsx` |
| `productos.html` + `catalogo.js` | `paginas/Productos.jsx` + `Buscador`, `Catalogo`, `TarjetaProducto` |
| `carrito.html` + `carrito.js` | `components/Carrito.jsx` (panel lateral) + funciones en `App.jsx` |
| `comunidad.html` + `comunidad.js` | `paginas/Comunidad.jsx` |
| `eventos.html` + `eventos.js` | `paginas/Eventos.jsx` + `TarjetaEvento` |
| `login.html` + `login.js` | `paginas/Login.jsx` |
| `registro.html` + `registro.js` | `paginas/Registro.jsx` |
| `perfil.html` + `perfil.js` | `paginas/Perfil.jsx` |
| `main.js` (contador del carrito, sesión en el menú, WhatsApp) | `Encabezado`, `App.jsx`, `BotonSoporte` |
| `alert(...)` | mensajes emergentes (`components/Aviso.jsx`) |

La navegación usa la dirección con `#` (`#catalogo`, `#perfil`…), así que los botones Atrás y
Adelante del navegador funcionan sin instalar nada más. El siguiente paso natural es React Router.

## Datos guardados en el navegador (localStorage)

| Clave | Contenido |
| --- | --- |
| `carrito-levelup` | `[{ id, cantidad }]`; nombre, precio e imagen se toman del catálogo |
| `usuarioPerfil` | usuario registrado (nombre, correo, contraseña, puntos y rango) |
| `sesionIniciada` | `true` o `false` |
| `consejosComunidad` | consejos publicados en el foro |
| `stock-vendido` | `{ id: unidades }` ya vendidas; se restan del stock de `data/productos.js` |

El descuento canjeado con puntos se guarda dentro de `usuarioPerfil` (campo `descuento`).
Para reiniciar el stock de la demo basta borrar la clave `stock-vendido` en el navegador.

> La contraseña se guarda en texto plano solo porque todavía no hay backend. Cuando exista el
> servidor (Spring Boot), la autenticación debe hacerse allí y nunca guardarse así.
