import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'

// 1) Primero el CSS de Bootstrap, 2) después nuestros estilos propios,
// para que los nuestros puedan sobrescribir a Bootstrap.
import 'bootstrap/dist/css/bootstrap.min.css'
import './index.css'

import App from './App.jsx'

// React toma el <div id="root"> de index.html y dibuja ahí toda la aplicación.
createRoot(document.getElementById('root')).render(
  <StrictMode>
    <App />
  </StrictMode>,
)
