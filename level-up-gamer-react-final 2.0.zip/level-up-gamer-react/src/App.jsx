import { useState, useEffect } from 'react'

import Encabezado from './components/Encabezado.jsx'
import Carrito from './components/Carrito.jsx'
import PiePagina from './components/PiePagina.jsx'
import BotonSoporte from './components/BotonSoporte.jsx'
import Aviso from './components/Aviso.jsx'

import Inicio from './paginas/Inicio.jsx'
import Productos from './paginas/Productos.jsx'
import Comunidad from './paginas/Comunidad.jsx'
import Eventos from './paginas/Eventos.jsx'
import Login from './paginas/Login.jsx'
import Registro from './paginas/Registro.jsx'
import Perfil from './paginas/Perfil.jsx'

import productos from './data/productos.js'
import { leerGuardado, guardar } from './utils/almacenamiento.js'
import { calcularNivel } from './utils/niveles.js'
import { calcularTotales } from './utils/precios.js'
import { formatearPrecio } from './utils/formato.js'

// claves de localStorage
const CLAVE_CARRITO = 'carrito-levelup'
const CLAVE_USUARIO = 'usuarioPerfil'
const CLAVE_SESION = 'sesionIniciada'
const CLAVE_VENDIDOS = 'stock-vendido'

// categorías sin repetir, para el select del buscador
const CATEGORIAS = [...new Set(productos.map((p) => p.categoria))]

const PAGINAS = ['inicio', 'catalogo', 'comunidad', 'eventos', 'perfil', 'login', 'registro']

// la página sale del # de la url: /#catalogo → 'catalogo'
function paginaDesdeHash() {
  const destino = window.location.hash.slice(1)
  return PAGINAS.includes(destino) ? destino : 'inicio'
}

// Del carrito solo se guarda { id, cantidad }; nombre, precio e imagen salen del catálogo.
function cargarCarritoGuardado() {
  const guardado = leerGuardado(CLAVE_CARRITO, [])
  return Array.isArray(guardado) ? guardado : []
}

// Unidades vendidas por producto: { id: cantidad }. Se descuentan del stock del catálogo.
function cargarVendidos() {
  const guardado = leerGuardado(CLAVE_VENDIDOS, {})
  return guardado !== null && typeof guardado === 'object' && !Array.isArray(guardado) ? guardado : {}
}

// Componente principal. Acá vive el estado que comparten varias páginas (carrito, sesión,
// usuario, búsqueda). Los hijos reciben datos por props y avisan con funciones.
function App() {
  // estado
  // useState con función: localStorage se lee solo en el primer render
  const [pagina, setPagina] = useState(paginaDesdeHash)
  const [carrito, setCarrito] = useState(cargarCarritoGuardado)
  const [mostrarCarrito, setMostrarCarrito] = useState(false)
  const [usuario, setUsuario] = useState(() => leerGuardado(CLAVE_USUARIO, null))
  const [sesionIniciada, setSesionIniciada] = useState(() => leerGuardado(CLAVE_SESION, false))
  const [aviso, setAviso] = useState(null)
  const [vendidos, setVendidos] = useState(cargarVendidos)
  // Buscador de productos: se escribe en la lupa del encabezado y se aplica en el catálogo.
  const [textoBusqueda, setTextoBusqueda] = useState('')
  const [categoriaBusqueda, setCategoriaBusqueda] = useState('Todas')

  // efectos: se guarda en localStorage cuando cambia el dato
  useEffect(() => {
    guardar(CLAVE_CARRITO, carrito)
  }, [carrito])

  useEffect(() => {
    // sin usuario registrado no hay nada que guardar
    if (usuario !== null) guardar(CLAVE_USUARIO, usuario)
  }, [usuario])

  useEffect(() => {
    guardar(CLAVE_SESION, sesionIniciada)
  }, [sesionIniciada])

  useEffect(() => {
    guardar(CLAVE_VENDIDOS, vendidos)
  }, [vendidos])

  // cambia la página cuando cambia el # (así funcionan atrás y adelante)
  useEffect(() => {
    const alCambiarDireccion = () => setPagina(paginaDesdeHash())
    window.addEventListener('hashchange', alCambiarDireccion)
    return () => window.removeEventListener('hashchange', alCambiarDireccion)
  }, [])

  // al cambiar de página se vuelve arriba
  useEffect(() => {
    window.scrollTo(0, 0)
  }, [pagina])

  // datos calculados (no se guardan)
  // Stock real = stock del producto menos lo ya vendido en compras anteriores.
  const stockReal = (producto) => Math.max(0, producto.stock - (vendidos[producto.id] ?? 0))

  // Junta { id, cantidad } con los datos del producto. Si el stock bajó desde la última
  // visita se ajusta la cantidad, y los agotados salen del carrito.
  const itemsCarrito = carrito
    .map(({ id, cantidad }) => {
      const producto = productos.find((p) => p.id === id)
      if (!producto || stockReal(producto) <= 0) return null
      return { ...producto, stock: stockReal(producto), cantidad: Math.min(cantidad, stockReal(producto)) }
    })
    .filter(Boolean)
  const cantidadTotal = itemsCarrito.reduce((suma, item) => suma + item.cantidad, 0)

  // Catálogo que ven las páginas: a cada stock se le restan las unidades que ya están en el carrito.
  const catalogo = productos.map((producto) => {
    const enCarrito = itemsCarrito.find((item) => item.id === producto.id)?.cantidad ?? 0
    return { ...producto, stock: stockReal(producto) - enCarrito, enCarrito }
  })

  // hay sesión si el usuario existe y quedó marcado como iniciado
  const haySesion = sesionIniciada === true && usuario !== null
  // descuento canjeado con puntos (solo se usa con sesión iniciada)
  const descuentoDisponible = haySesion ? (usuario.descuento ?? 0) : 0
  const totales = calcularTotales(itemsCarrito, descuentoDisponible)

  // el título de la pestaña muestra cuántos productos hay en el carrito
  useEffect(() => {
    document.title = `(${cantidadTotal}) Level-Up Gamer`
  }, [cantidadTotal])

  // funciones que modifican el estado
  function irA(destino) {
    window.location.hash = destino
  }

  // vuelve a mostrar todo el catálogo
  function limpiarBusqueda() {
    setTextoBusqueda('')
    setCategoriaBusqueda('Todas')
  }

  function mostrarAviso(texto, variante = 'success') {
    setAviso({ id: Date.now(), texto, variante })
  }

  function agregarAlCarrito(producto) {
    // no se puede pasar del stock
    // (el producto de la tarjeta ya trae el stock descontado, por eso se busca el original)
    const original = productos.find((p) => p.id === producto.id)
    const unidadesEnCarrito = itemsCarrito.find((item) => item.id === producto.id)?.cantidad ?? 0
    const disponibles = stockReal(original)
    if (unidadesEnCarrito >= disponibles) {
      mostrarAviso(`Solo hay ${disponibles} unidades de "${producto.nombre}" disponibles.`, 'warning')
      return
    }

    setCarrito((carritoActual) => {
      const existe = carritoActual.find((item) => item.id === producto.id)
      if (existe) {
        // no se modifica el arreglo, se crea uno nuevo
        return carritoActual.map((item) =>
          item.id === producto.id ? { ...item, cantidad: item.cantidad + 1 } : item,
        )
      }
      return [...carritoActual, { id: producto.id, cantidad: 1 }]
    })
    mostrarAviso(`"${producto.nombre}" se agregó al carrito.`)
  }

  // Suma o resta unidades; si la cantidad llega a 0 el producto sale del carrito.
  function cambiarCantidad(id, cambio) {
    // al sumar también se respeta el stock
    if (cambio > 0) {
      const producto = productos.find((p) => p.id === id)
      const unidadesEnCarrito = itemsCarrito.find((item) => item.id === id)?.cantidad ?? 0
      if (!producto || unidadesEnCarrito + cambio > stockReal(producto)) {
        mostrarAviso('Ya tienes todas las unidades disponibles de este producto.', 'warning')
        return
      }
    }

    setCarrito((carritoActual) =>
      carritoActual
        .map((item) => (item.id === id ? { ...item, cantidad: item.cantidad + cambio } : item))
        .filter((item) => item.cantidad > 0),
    )
  }

  function quitarDelCarrito(id) {
    setCarrito((carritoActual) => carritoActual.filter((item) => item.id !== id))
  }

  // Pago simulado: pide sesión. Al pagar se descuenta el stock de lo vendido,
  // se gasta el descuento que se haya aplicado y se vacía el carrito.
  function procederPago() {
    setMostrarCarrito(false)
    if (!haySesion) {
      mostrarAviso('Debes iniciar sesión para procesar tu compra.', 'warning')
      irA('login')
      return
    }
    setVendidos((actual) => {
      const nuevo = { ...actual }
      itemsCarrito.forEach((item) => {
        nuevo[item.id] = (nuevo[item.id] ?? 0) + item.cantidad
      })
      return nuevo
    })
    if (totales.descuentoAplicado > 0) {
      setUsuario((actual) => ({ ...actual, descuento: (actual.descuento ?? 0) - totales.descuentoAplicado }))
    }
    mostrarAviso(`¡Compra procesada con éxito, ${usuario.nombre}! Total pagado: ${formatearPrecio(totales.total)}.`)
    setCarrito([])
    irA('perfil')
  }

  function registrarUsuario(nuevoUsuario) {
    setUsuario(nuevoUsuario)
    setSesionIniciada(false)
    mostrarAviso('¡Cuenta creada con éxito! Ahora inicia sesión.')
    irA('login')
  }

  function iniciarSesion() {
    setSesionIniciada(true)
    mostrarAviso(`¡Inicio de sesión exitoso! Bienvenido, ${usuario.nombre}.`)
    irA('perfil')
  }

  function cerrarSesion() {
    setSesionIniciada(false)
    mostrarAviso('Cerraste sesión.', 'info')
  }

  function realizarCheckIn(lugar, puntos) {
    if (!haySesion) {
      mostrarAviso('Debes iniciar sesión para acumular puntos por tus check-ins.', 'warning')
      irA('login')
      return
    }
    setUsuario((actual) => {
      const total = actual.puntos + puntos
      return { ...actual, puntos: total, nivel: calcularNivel(total) }
    })
    mostrarAviso(`¡Check-in realizado con éxito en "${lugar}"! Ganaste +${puntos} Puntos LevelUp.`)
  }

  // Gasta puntos. Si el premio es un descuento, queda guardado en el usuario y se aplica en el carrito.
  function canjearPremio(costo, nombrePremio, descuento = 0) {
    if (!haySesion) return
    if (usuario.puntos < costo) {
      mostrarAviso(`Te faltan ${costo - usuario.puntos} puntos para canjear "${nombrePremio}".`, 'danger')
      return
    }
    setUsuario((actual) => {
      const total = actual.puntos - costo
      return {
        ...actual,
        puntos: total,
        nivel: calcularNivel(total),
        descuento: (actual.descuento ?? 0) + descuento,
      }
    })
    if (descuento > 0) {
      const acumulado = (usuario.descuento ?? 0) + descuento
      mostrarAviso(`¡Canje exitoso! Tienes ${formatearPrecio(acumulado)} de descuento para tu próxima compra.`)
    } else {
      mostrarAviso(`¡Canje exitoso! Obtuviste: ${nombrePremio}.`)
    }
  }

  // qué página se muestra
  let contenido
  switch (pagina) {
    case 'catalogo':
      contenido = (
        <Productos
          catalogo={catalogo}
          onAgregar={agregarAlCarrito}
          texto={textoBusqueda}
          categoria={categoriaBusqueda}
          onLimpiarBusqueda={limpiarBusqueda}
        />
      )
      break
    case 'comunidad':
      contenido = <Comunidad nombreUsuario={haySesion ? usuario.nombre : ''} />
      break
    case 'eventos':
      contenido = <Eventos onCheckIn={realizarCheckIn} />
      break
    case 'login':
      contenido = <Login usuarioGuardado={usuario} onIniciarSesion={iniciarSesion} />
      break
    case 'registro':
      contenido = <Registro onRegistrar={registrarUsuario} />
      break
    case 'perfil':
      contenido = (
        <Perfil
          usuario={usuario}
          sesionIniciada={haySesion}
          onCerrarSesion={cerrarSesion}
          onCanjear={canjearPremio}
        />
      )
      break
    default:
      contenido = <Inicio catalogo={catalogo} itemsCarrito={itemsCarrito} onAgregar={agregarAlCarrito} />
  }

  // en login y registro no se muestran ni el header ni el footer
  const esPaginaAuth = pagina === 'login' || pagina === 'registro'

  return (
    <div className="d-flex flex-column min-vh-100">
      {!esPaginaAuth && (
        <Encabezado
          pagina={pagina}
          sesionIniciada={haySesion}
          cantidad={cantidadTotal}
          onVerCarrito={() => setMostrarCarrito(true)}
          buscador={{
            texto: textoBusqueda,
            onCambiarTexto: setTextoBusqueda,
            categoria: categoriaBusqueda,
            onCambiarCategoria: setCategoriaBusqueda,
            categorias: CATEGORIAS,
          }}
        />
      )}

      <main className="flex-grow-1">{contenido}</main>

      <Carrito
        mostrar={mostrarCarrito}
        onCerrar={() => setMostrarCarrito(false)}
        items={itemsCarrito}
        descuentoDisponible={descuentoDisponible}
        onCambiarCantidad={cambiarCantidad}
        onQuitar={quitarDelCarrito}
        onVaciar={() => setCarrito([])}
        onPagar={procederPago}
      />

      <Aviso aviso={aviso} onCerrar={() => setAviso(null)} />
      <BotonSoporte nombreUsuario={usuario ? usuario.nombre : 'Cliente'} />
      {!esPaginaAuth && <PiePagina />}
    </div>
  )
}

export default App
