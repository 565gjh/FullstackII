// Datos de contacto (los usan el footer y el botón de WhatsApp).
// OJO: el correo y las redes son de ejemplo, hay que cambiarlos por los reales.

const contacto = {
  email: 'levelupgamer@gmail.com',
  telefono: '+56 9 1234 5678',
  whatsapp: '56912345678', // formato internacional sin "+" ni espacios (lo exige api.whatsapp.com)
  ubicacion: 'Melipilla, Región Metropolitana · Despachos a todo Chile',
  horario: 'Lunes a viernes, 10:00 a 19:00 hrs',
  redes: [
    { id: 'instagram', nombre: 'Instagram', usuario: '@levelupgamer.cl', url: 'https://www.instagram.com/levelupgamer.cl' },
    { id: 'facebook', nombre: 'Facebook', usuario: 'Level-Up Gamer', url: 'https://www.facebook.com/levelupgamer.cl' },
    { id: 'tiktok', nombre: 'TikTok', usuario: '@levelupgamer.cl', url: 'https://www.tiktok.com/@levelupgamer.cl' },
    { id: 'youtube', nombre: 'YouTube', usuario: 'Level-Up Gamer', url: 'https://www.youtube.com/@levelupgamer' },
  ],
}

export default contacto
