// Contenido de la página Comunidad: noticias, guías y el consejo inicial del foro.

export const noticias = [
  {
    id: 1,
    etiqueta: 'Últimas novedades de Hardware',
    titulo:
      'Acer presenta Predator Atlas 7, su nueva consola portátil con pantalla de 120 Hz y batería de hasta 80 Wh',
    texto:
      'Acer amplía su familia de PC consolizados con Predator Atlas 7, un modelo con Windows 11, pantalla Full HD de 120 Hz, Intel Arc y hasta 24 GB de RAM LPDDR5x que llegará a Europa en noviembre.',
  },
  {
    id: 2,
    etiqueta: 'Últimas noticias de Videojuegos',
    titulo:
      "El mejor juego de Los Simpson ahora se puede jugar en VR: 'Este mod es increíble'",
    texto:
      'The Simpsons Hit & Run está de vuelta con un espectacular mod que nos permite redescubrir este aclamado juego en realidad virtual.',
  },
  {
    id: 3,
    etiqueta: 'Últimas noticias de PS5',
    titulo:
      'La animación más polémica de GTA 6 tiene explicación: podrás hacer acrobacias controladas al estilo Spider-Man 2',
    texto:
      'El extraño salto hacia atrás de Jason que apareció en el gameplay extendido de GTA 6 no sería una animación automática: el jugador podrá decidir cómo lanzarse al agua.',
  },
]

export const guias = [
  {
    id: 1,
    titulo: 'Cómo mejorar tu experiencia gaming',
    texto:
      'A continuación, te ofrecemos los mejores consejos para que puedas personalizar y mejorar tu experiencia gaming.',
    pasos: [
      {
        titulo: 'Optimiza tu configuración de hardware',
        texto:
          'Debes saber que el rendimiento de tu equipo es crucial. Por esto es importante que te asegures de tener una tarjeta gráfica potente, un procesador eficiente y suficiente memoria RAM. Además, debes ajustar la configuración gráfica de tus juegos para lograr un equilibrio entre rendimiento y calidad visual.',
      },
      {
        titulo: 'Personaliza tus periféricos',
        texto:
          'No subestimes el poder de un buen periférico. Un ratón preciso, un teclado mecánico, unos auriculares de calidad y un monitor con nitidez en la imagen pueden marcar la diferencia. Configura los botones de tu ratón y teclado de acuerdo a tus preferencias para una experiencia de juego más personalizada y eficiente.',
      },
      {
        titulo: 'Conoce tus juegos a fondo',
        texto:
          'Más allá de la simple diversión, investiga a fondo las mecánicas de tus juegos favoritos. Estudia mapas, aprende estrategias y descubre los detalles más sutiles que pueden marcar la diferencia entre la victoria y la derrota.',
      },
      {
        titulo: 'Mantén una postura ergonómica',
        texto:
          'La comodidad física es clave para las largas sesiones de juego. Asegúrate de tener una silla ergonómica y ajusta la altura de tu monitor para mantener una postura adecuada. Esto no solo mejorará tu rendimiento, sino que también cuidará de tu salud a largo plazo.',
      },
      {
        titulo: 'Optimiza tu conexión a internet',
        texto:
          'La latencia y la velocidad de la conexión pueden ser determinantes, especialmente en juegos online. Utiliza una conexión por cable en lugar de WiFi siempre que sea posible y considera la posibilidad de invertir en un router de alta calidad para una conexión más estable.',
      },
    ],
  },
  {
    id: 2,
    titulo: 'Ergonomía Gamer: Cuida tu postura en sesiones maratónicas',
    texto:
      'Consejos clave sobre la altura de la silla, la distancia focal al monitor y pausas activas para evitar fatiga muscular y visual.',
    pasos: [],
  },
]

// Consejo que aparece en el foro mientras nadie ha publicado nada.
export const consejoPorDefecto = {
  id: 0,
  autor: 'AlexPro',
  texto:
    'Para juegos de mundo abierto pesados, instala el juego en un SSD NVMe para evitar tirones de carga.',
}
