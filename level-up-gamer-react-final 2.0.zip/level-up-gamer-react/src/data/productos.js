// Catálogo oficial de Level-Up Gamer.
// Más adelante estos datos vendrán del backend; por ahora viven en un arreglo
// de objetos. Las imágenes se importan: Vite se encarga de entregarlas.
//
// "stock" = unidades disponibles. Con stock 0 el producto se muestra como "Sin stock"
// y no se puede agregar al carrito. (Valores de ejemplo: edítalos a tu inventario real.)

import catan from '../assets/catannew.png'
import carcassonne from '../assets/images.jpg'
import controlXbox from '../assets/controlxboxsx.png'
import hyperx from '../assets/hyperxcloudii.avif'
import ps5 from '../assets/ps5-product.webp'
import pcAsus from '../assets/h732.png'
import sillaSecretlab from '../assets/teamsecret-titanevo.webp'
import mouseLogitech from '../assets/640.webp'
import mousepadRazer from '../assets/razer67.png'
import polera from '../assets/3041941_01.webp'

const productos = [
  {
    id: 1,
    codigo: 'JM001',
    categoria: 'Juegos de Mesa',
    nombre: 'Catan',
    precio: 29990,
    stock: 12,
    imagen: catan,
    descripcion:
      'Un clásico juego de estrategia donde los jugadores compiten por colonizar y expandirse en la isla de Catan. Ideal para 3-4 jugadores y perfecto para noches de juego en familia o con amigos.',
    fabricante: 'KOSMOS / Devir',
    distribuidor: 'Devir Chile',
  },
  {
    id: 2,
    codigo: 'JM002',
    categoria: 'Juegos de Mesa',
    nombre: 'Carcassonne',
    precio: 24990,
    stock: 8,
    imagen: carcassonne,
    descripcion:
      'Un juego de colocación de fichas donde los jugadores construyen el paisaje alrededor de la fortaleza medieval de Carcassonne. Ideal para 2-5 jugadores y fácil de aprender.',
    fabricante: 'Hans im Glück / Devir',
    distribuidor: 'Devir Chile',
  },
  {
    id: 3,
    codigo: 'AC001',
    categoria: 'Accesorios',
    nombre: 'Controlador Inalámbrico Xbox Series X',
    precio: 59990,
    stock: 5,
    imagen: controlXbox,
    descripcion:
      'Ofrece una experiencia de juego cómoda con botones mapeables y una respuesta táctil mejorada. Compatible con consolas Xbox y PC.',
    fabricante: 'Microsoft',
    distribuidor: 'Distribuidores Oficiales Latam',
  },
  {
    id: 4,
    codigo: 'AC002',
    categoria: 'Accesorios',
    nombre: 'Auriculares Gamer HyperX Cloud II',
    precio: 79990,
    stock: 0,
    imagen: hyperx,
    descripcion:
      'Proporcionan un sonido envolvente de calidad con un micrófono desmontable y almohadillas de espuma viscoelástica para mayor comodidad durante largas sesiones de juego.',
    fabricante: 'HP / HyperX',
    distribuidor: 'HyperX Chile',
  },
  {
    id: 5,
    codigo: 'CO001',
    categoria: 'Consolas',
    nombre: 'PlayStation 5',
    precio: 549900,
    stock: 3,
    imagen: ps5,
    descripcion:
      'La consola de última generación de Sony, que ofrece gráficos impresionantes y tiempos de carga ultrarrápidos para una experiencia de juego inmersiva.',
    fabricante: 'Sony Interactive Entertainment',
    distribuidor: 'Sony Chile / Microplay',
  },
  {
    id: 6,
    codigo: 'CG001',
    categoria: 'Computadores Gamers',
    nombre: 'PC Gamer ASUS ROG Strix',
    precio: 1299900,
    stock: 2,
    imagen: pcAsus,
    descripcion:
      'Un potente equipo diseñado para los gamers más exigentes, equipado con los últimos componentes para ofrecer un rendimiento excepcional en cualquier juego.',
    fabricante: 'ASUS / Republic of Gamers',
    distribuidor: 'ASUS Chile / Ingram Micro',
  },
  {
    id: 7,
    codigo: 'SG001',
    categoria: 'Sillas Gamers',
    nombre: 'Silla Gamer Secretlab Titan',
    precio: 349900,
    stock: 4,
    imagen: sillaSecretlab,
    descripcion:
      'Diseñada para el máximo confort, esta silla ofrece un soporte ergonómico y personalización ajustable para sesiones de juego prolongadas.',
    fabricante: 'Secretlab',
    distribuidor: 'ErgoGamer Corp Latam',
  },
  {
    id: 8,
    codigo: 'MS001',
    categoria: 'Mouse',
    nombre: 'Mouse Gamer Logitech G502 HERO',
    precio: 49990,
    stock: 15,
    imagen: mouseLogitech,
    descripcion:
      'Con sensor de alta precisión y botones personalizables, este mouse es ideal para gamers que buscan un control preciso y personalización.',
    fabricante: 'Logitech G',
    distribuidor: 'Logitech Chile',
  },
  {
    id: 9,
    codigo: 'MP001',
    categoria: 'Mousepad',
    nombre: 'Mousepad Razer Goliathus Extended Chroma',
    precio: 29990,
    stock: 20,
    imagen: mousepadRazer,
    descripcion:
      'Ofrece un área de juego amplia con iluminación RGB personalizable, asegurando una superficie suave y uniforme para el movimiento del mouse.',
    fabricante: 'Razer',
    distribuidor: 'Razer Official Distributor',
  },
  {
    id: 10,
    codigo: 'PP001',
    categoria: 'Poleras Personalizadas',
    nombre: "Polera Gamer Personalizada 'Level-Up'",
    precio: 14990,
    stock: 30,
    imagen: polera,
    descripcion:
      'Una camiseta cómoda y estilizada, con la posibilidad de personalizarla con tu gamer tag o diseño favorito.',
    fabricante: 'Level-Up Custom Textiles',
    distribuidor: 'Taller Gráfico Propio (Melipilla)',
  },
]

export default productos
