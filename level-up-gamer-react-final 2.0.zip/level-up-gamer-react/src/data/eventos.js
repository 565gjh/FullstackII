// Eventos del radar. Cada check-in suma puntos al perfil.
// fechaFin (AAAA-MM-DD) es opcional: pasada esa fecha se bloquea el check-in.

const eventos = [
  {
    id: 1,
    etiqueta: 'THE GAME AWARDS 2026 / Transmisión en VIVO',
    lugar: 'Peacock Theater en Los Ángeles, California',
    descripcion:
      'Se celebrará oficialmente el jueves 10 de diciembre. Ceremonia de cierre de año para premiar a los mejores videojuegos.',
    fechaFin: '2026-12-10',
    puntos: 170,
  },
  {
    id: 2,
    etiqueta: 'EXPOGAME 2026 / PRESENCIAL',
    lugar: 'Centro Cultural Estación Mapocho, Santiago',
    descripcion:
      'Se realizó del 2 al 4 de octubre, con invitados como el streamer El Mariana y el rapero Kblade, además de competencias de esports. Las entradas se adquieren en Puntoticket.',
    fechaFin: '2026-10-04',
    puntos: 135,
  },
  {
    id: 3,
    etiqueta: 'FESTIGAME 2026 / PRESENCIAL',
    lugar: 'Movistar Arena, Santiago',
    descripcion:
      'Se celebrará el 25 de octubre, con horario extendido de 10:00 a 00:00 horas. Incluye experiencias de realidad virtual, torneos relámpago, competencias de cosplay y K-pop.',
    fechaFin: '2026-10-25',
    puntos: 115,
  },
  {
    id: 4,
    etiqueta: 'Zona Gamers Bienvenida / PRESENCIAL',
    lugar: 'Duoc UC Sede Melipilla - Local Party',
    descripcion:
      'Un punto de encuentro y comunidad diseñado especialmente para los entusiastas de los videojuegos, el hardware y la cultura geek.',
    puntos: 100,
  },
  {
    id: 5,
    etiqueta: 'CHARLA MAGISTRAL: LA IA COMO MOTOR PROFESIONAL - ONLINE',
    lugar: 'Duoc UC Sede Antonio Varas - CITT',
    descripcion:
      'Una conferencia magistral enfocada en cómo la Inteligencia Artificial está transformando el campo laboral y actúa como un motor de desarrollo profesional.',
    puntos: 80,
  },
  {
    id: 6,
    etiqueta: '3er Seminario de Competencias Ágiles - PRESENCIAL',
    lugar: 'Duoc UC Sede Plaza Norte - CITT',
    descripcion:
      'Un espacio enfocado en el desarrollo, profundización y aplicación de metodologías ágiles en el ámbito profesional y académico.',
    puntos: 75,
  },
]

export default eventos
