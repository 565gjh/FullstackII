// Leer y guardar en localStorage (todo como JSON).
// Si falla o el dato está dañado, se devuelve el valor por defecto.

export function leerGuardado(clave, valorPorDefecto) {
  try {
    const guardado = localStorage.getItem(clave)
    return guardado ? JSON.parse(guardado) : valorPorDefecto
  } catch {
    return valorPorDefecto
  }
}

export function guardar(clave, valor) {
  try {
    localStorage.setItem(clave, JSON.stringify(valor))
  } catch {
    // modo privado o sin espacio: simplemente no se guarda
  }
}
