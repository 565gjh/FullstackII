// Un evento termina al final del día de fechaFin.
// "hoy" es parámetro para poder probar la función con cualquier fecha.
export function eventoFinalizado(evento, hoy = new Date()) {
  if (!evento.fechaFin) return false
  const fin = new Date(`${evento.fechaFin}T23:59:59`)
  return hoy > fin
}
