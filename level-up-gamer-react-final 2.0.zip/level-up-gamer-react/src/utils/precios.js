// Calcula lo que se paga: subtotal, descuento LevelUp aplicado y total.
// El descuento canjeado se usa hasta el valor del subtotal; el resto queda para otra compra.
export function calcularTotales(items, descuentoDisponible = 0) {
  const subtotal = items.reduce((suma, item) => suma + item.precio * item.cantidad, 0)
  const descuentoAplicado = Math.min(Math.max(descuentoDisponible, 0), subtotal)
  return { subtotal, descuentoAplicado, total: subtotal - descuentoAplicado }
}
