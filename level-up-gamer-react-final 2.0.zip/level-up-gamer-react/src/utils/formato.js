// Convierte 29990 en "$29.990 CLP" usando el formato chileno.
export function formatearPrecio(valor) {
  const monto = valor.toLocaleString('es-CL', {
    style: 'currency',
    currency: 'CLP',
  })
  return `${monto} CLP`
}
