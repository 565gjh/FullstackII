// Rango que corresponde a los puntos LevelUp.
export function calcularNivel(puntos) {
  if (puntos >= 1200) return 'Challenger 👑'
  if (puntos >= 600) return 'Platino 💎'
  if (puntos >= 200) return 'Oro 🪙'
  return 'Hierro 🛡️'
}
