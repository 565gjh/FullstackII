import { Container, Button } from 'react-bootstrap'
import { formatearPrecio } from '../utils/formato.js'

// premios canjeables con puntos
const PREMIOS = [
  { id: 1, costo: 375, nombre: 'Descuento de $5.000 CLP', boton: 'Canjear $5.000 dcto', descuento: 5000 },
  { id: 2, costo: 125, nombre: 'Envío Gratis Nacional', boton: 'Canjear Envío Gratis' },
]

// Perfil: datos, rango, puntos y canje. App le entrega el usuario y las funciones.
function Perfil({ usuario, sesionIniciada, onCerrarSesion, onCanjear }) {
  // sin sesión se muestra otra vista
  if (!sesionIniciada || !usuario) {
    return (
      <Container className="contenedor contenedor-estrecho py-4">
        <section className="panel text-center">
          <h1 className="h4">Aún no has iniciado sesión</h1>
          <p>Inicia sesión o regístrate para acumular puntos, subir de rango y canjear premios.</p>
          <div className="d-flex gap-2 justify-content-center flex-wrap">
            <Button variant="primary" href="#login">
              Ir a Iniciar Sesión
            </Button>
            <Button variant="outline-primary" href="#registro">
              Crear Cuenta
            </Button>
          </div>
        </section>
      </Container>
    )
  }

  return (
    <Container className="contenedor contenedor-estrecho py-4">
      <section className="panel">
        <h1 className="h4">Panel de Perfil y Gamificación</h1>
        <h2>Bienvenido, {usuario.nombre}</h2>
        <p>
          <strong>Correo:</strong> {usuario.correo}
        </p>
        <p>
          <strong>Rango Actual:</strong> <span className="dato-nivel">{usuario.nivel}</span>
        </p>
        <p>
          <strong>Tus Puntos:</strong>{' '}
          <span className="dato-puntos">{usuario.puntos} Puntos LevelUp</span>
        </p>
        {/* descuento ya canjeado: se aplica solo en el carrito */}
        {usuario.descuento > 0 && (
          <p>
            <strong>Descuento disponible:</strong>{' '}
            <span className="dato-puntos">{formatearPrecio(usuario.descuento)}</span> (se aplica en tu próxima compra)
          </p>
        )}
        <Button variant="outline-danger" onClick={onCerrarSesion}>
          Cerrar Sesión
        </Button>
      </section>

      <section className="panel">
        <h2>Canjear Puntos LevelUp</h2>
        <p>Intercambia tus puntos por beneficios exclusivos:</p>
        <div className="d-flex gap-2 flex-wrap">
          {PREMIOS.map((premio) => (
            <Button
              key={premio.id}
              variant="primary"
              disabled={usuario.puntos < premio.costo}
              onClick={() => onCanjear(premio.costo, premio.nombre, premio.descuento ?? 0)}
            >
              {premio.boton} ({premio.costo} pts)
            </Button>
          ))}
        </div>
      </section>
    </Container>
  )
}

export default Perfil
