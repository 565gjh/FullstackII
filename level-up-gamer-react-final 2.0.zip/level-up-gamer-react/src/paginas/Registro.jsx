import { useState } from 'react'
import { Form, Button } from 'react-bootstrap'
import FondoAuth from '../components/FondoAuth.jsx'
import { calcularNivel } from '../utils/niveles.js'

const PUNTOS_BIENVENIDA = 100
const PUNTOS_POR_REFERIDO = 50
const EDAD_MINIMA = 18

// Formulario controlado: cada campo tiene su useState.
function Registro({ onRegistrar }) {
  const [nombre, setNombre] = useState('')
  const [correo, setCorreo] = useState('')
  const [password, setPassword] = useState('')
  const [edad, setEdad] = useState('')
  const [referido, setReferido] = useState('')
  const [error, setError] = useState('')

  function enviar(evento) {
    evento.preventDefault() // evita que la página se recargue

    if (parseInt(edad, 10) < EDAD_MINIMA) {
      setError('Debes ser mayor de 18 años para registrarte.')
      return
    }

    // 100 puntos de bienvenida y +50 si trae código de referido
    const puntos = PUNTOS_BIENVENIDA + (referido.trim() !== '' ? PUNTOS_POR_REFERIDO : 0)

    // Sin backend el usuario se guarda en el navegador.
    // Con servidor, la contraseña no se debe guardar así.
    onRegistrar({
      nombre: nombre.trim(),
      correo: correo.trim(),
      password,
      puntos,
      nivel: calcularNivel(puntos),
    })
  }

  return (
    <FondoAuth>
      <h1 className="h2">Crear Cuenta</h1>
      <Form onSubmit={enviar}>
        <Form.Group className="mb-3" controlId="nombre">
          <Form.Label>Nombre de Usuario</Form.Label>
          <Form.Control
            type="text"
            placeholder="Tu apodo gamer"
            value={nombre}
            onChange={(e) => setNombre(e.target.value)}
            required
          />
        </Form.Group>

        <Form.Group className="mb-3" controlId="correo">
          <Form.Label>Correo Electrónico</Form.Label>
          <Form.Control
            type="email"
            placeholder="usuario@duocuc.cl"
            value={correo}
            onChange={(e) => setCorreo(e.target.value)}
            required
          />
        </Form.Group>

        <Form.Group className="mb-3" controlId="password">
          <Form.Label>Contraseña</Form.Label>
          <Form.Control
            type="password"
            placeholder="Crea una contraseña"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            autoComplete="new-password"
            required
          />
        </Form.Group>

        <Form.Group className="mb-3" controlId="edad">
          <Form.Label>Edad</Form.Label>
          <Form.Control
            type="number"
            min="0"
            placeholder="Debes ser +18"
            value={edad}
            onChange={(e) => {
              setEdad(e.target.value)
              setError('')
            }}
            required
          />
        </Form.Group>

        <Form.Group className="mb-3" controlId="referido">
          <Form.Label>Código de Referido (Opcional)</Form.Label>
          <Form.Control
            type="text"
            placeholder="Ej: GAMER2026"
            value={referido}
            onChange={(e) => setReferido(e.target.value)}
          />
        </Form.Group>

        {/* el error solo se muestra si existe */}
        {error && (
          <p className="mensaje-error" role="alert">
            {error}
          </p>
        )}

        <Button type="submit" className="btn-gamer w-100">
          Registrarse
        </Button>
      </Form>

      <p className="enlace-auth">
        ¿Ya tienes cuenta? <a href="#login">Inicia sesión aquí</a>
      </p>
    </FondoAuth>
  )
}

export default Registro
