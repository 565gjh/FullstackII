import { Row, Col } from 'react-bootstrap'
import TarjetaProducto from './TarjetaProducto.jsx'
import { recomendarProductos } from '../utils/recomendaciones.js'

// Sección "Recomendado para ti": usa recomendarProductos() y reutiliza TarjetaProducto.
function Recomendaciones({ catalogo, itemsCarrito, onAgregar }) {
  const { motivo, productos } = recomendarProductos(catalogo, itemsCarrito)
  if (productos.length === 0) return null

  return (
    <section className="panel" aria-labelledby="titulo-recomendaciones">
      <h2 id="titulo-recomendaciones">Recomendado para ti</h2>
      <p>
        {motivo === 'afines'
          ? 'Basado en los productos de tu carrito, esto podría interesarte:'
          : 'Una selección para empezar a subir de nivel:'}
      </p>
      <Row xs={1} sm={2} lg={3} className="g-4">
        {productos.map((producto) => (
          <Col key={producto.id}>
            <TarjetaProducto producto={producto} onAgregar={onAgregar} />
          </Col>
        ))}
      </Row>
    </section>
  )
}

export default Recomendaciones
