import { Toast, ToastContainer, CloseButton } from 'react-bootstrap'

// Aviso emergente en vez de alert(): no bloquea y se cierra solo.
// Recibe null o un objeto { id, texto, variante }.
function Aviso({ aviso, onCerrar }) {
  return (
    <ToastContainer position="bottom-start" containerPosition="fixed" className="p-3">
      {aviso && (
        // con key nueva el toast se reinicia
        <Toast
          key={aviso.id}
          show
          autohide
          delay={3500}
          onClose={onCerrar}
          className={`aviso aviso-${aviso.variante}`}
        >
          <Toast.Body className="d-flex justify-content-between align-items-start gap-3">
            <span>{aviso.texto}</span>
            <CloseButton variant="white" onClick={onCerrar} aria-label="Cerrar aviso" />
          </Toast.Body>
        </Toast>
      )}
    </ToastContainer>
  )
}

export default Aviso
