import { Container, Row, Col } from 'react-bootstrap'

// Cabecera de cada página: título, texto, imagen opcional y children para contenido extra.
function Portada({ titulo, texto, imagen, altImagen = '', children }) {
  return (
    <Container className="contenedor pt-4">
      <header className="portada">
        <Row className="align-items-center g-4">
          <Col md>
            <h1>{titulo}</h1>
            <p className="lead mb-0">{texto}</p>
            {children}
          </Col>
          {imagen && (
            <Col md="auto" className="text-center">
              <img src={imagen} alt={altImagen} className="portada-imagen" />
            </Col>
          )}
        </Row>
      </header>
    </Container>
  )
}

export default Portada
