import { useState } from 'react'
import { Navbar, Nav, Container, Button, Badge } from 'react-bootstrap'
import Buscador from './Buscador.jsx'

// Enlaces del menú: apuntan a #pagina y App muestra la página según el #.
const ENLACES = [
  { destino: 'inicio', texto: 'Inicio' },
  { destino: 'catalogo', texto: 'Catálogo' },
  { destino: 'comunidad', texto: 'Comunidad & Blog' },
  { destino: 'eventos', texto: 'Eventos & Mapa' },
]

// ícono de lupa en SVG
function IconoLupa() {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor"
      strokeWidth="2.2" strokeLinecap="round" aria-hidden="true">
      <circle cx="11" cy="11" r="7" />
      <line x1="16.5" y1="16.5" x2="21" y2="21" />
    </svg>
  )
}

// Props: pagina (enlace activo), sesionIniciada, cantidad (del carrito), onVerCarrito
// y buscador (datos del buscador que vienen de App; null = sin lupa).
function Encabezado({ pagina, sesionIniciada, cantidad, onVerCarrito, buscador = null }) {
  // solo el encabezado necesita saber si la barra de búsqueda está abierta
  const [busquedaAbierta, setBusquedaAbierta] = useState(false)

  // la lupa solo sale en el catálogo; la barra queda abierta si hay un filtro activo
  const hayLupa = pagina === 'catalogo' && buscador !== null
  const hayFiltro = hayLupa && (buscador.texto.trim() !== '' || buscador.categoria !== 'Todas')
  const barraVisible = hayLupa && (busquedaAbierta || hayFiltro)

  return (
    // un solo header pegajoso para el menú y la barra de búsqueda
    <header className="encabezado-fijo sticky-top">
      <Navbar className="encabezado" data-bs-theme="dark" expand="lg" collapseOnSelect>
        <Container className="contenedor">
          <Navbar.Brand href="#inicio">
            LEVEL-UP <span>GAMER</span>
          </Navbar.Brand>

          {/* lupa y carrito fuera del menú colapsable para que se vean siempre */}
          <div className="acciones-encabezado d-flex gap-2 ms-auto me-2 ms-lg-0 order-lg-last">
            {hayLupa && (
              <Button
                variant="outline-primary"
                size="sm"
                className="boton-lupa"
                aria-label="Buscar productos"
                aria-expanded={barraVisible}
                onClick={() => setBusquedaAbierta((abierta) => !abierta)}
              >
                <IconoLupa />
              </Button>
            )}
            <Button variant="outline-primary" size="sm" onClick={onVerCarrito}>
              🛒 Carrito <Badge bg="primary">{cantidad}</Badge>
            </Button>
          </div>

          <Navbar.Toggle aria-controls="menu-principal" />
          <Navbar.Collapse id="menu-principal">
            <Nav className="me-auto">
              {ENLACES.map(({ destino, texto }) => (
                <Nav.Link key={destino} href={`#${destino}`} active={pagina === destino}>
                  {texto}
                </Nav.Link>
              ))}
            </Nav>
            <Nav>
              {/* según haya sesión o no */}
              {sesionIniciada ? (
                <Nav.Link href="#perfil" active={pagina === 'perfil'}>
                  Mi Perfil
                </Nav.Link>
              ) : (
                <Nav.Link href="#login" active={pagina === 'login' || pagina === 'registro'}>
                  Iniciar Sesión
                </Nav.Link>
              )}
            </Nav>
          </Navbar.Collapse>
        </Container>
      </Navbar>

      {/* barra de búsqueda */}
      {barraVisible && (
        <div className="barra-busqueda">
          <Container className="contenedor py-3">
            <Buscador
              texto={buscador.texto}
              onCambiarTexto={buscador.onCambiarTexto}
              categoria={buscador.categoria}
              onCambiarCategoria={buscador.onCambiarCategoria}
              categorias={buscador.categorias}
              className="mb-0"
              autoFocus
            />
          </Container>
        </div>
      )}
    </header>
  )
}

export default Encabezado
