import { Button } from 'react-bootstrap'
import contacto from '../data/contacto.js'

// el número está en data/contacto.js
const TELEFONO_SOPORTE = contacto.whatsapp

// Botón flotante que abre WhatsApp con el mensaje ya escrito
function BotonSoporte({ nombreUsuario }) {
  function abrirSoporteTecnico() {
    const mensaje = encodeURIComponent(
      `Hola, soy ${nombreUsuario}. Necesito ayuda con el servicio técnico de Level-Up Gamer.`,
    )
    window.open(
      `https://api.whatsapp.com/send?phone=${TELEFONO_SOPORTE}&text=${mensaje}`,
      '_blank',
      'noopener,noreferrer',
    )
  }

  return (
    <div className="boton-soporte">
      <Button
        className="btn-whatsapp rounded-pill"
        onClick={abrirSoporteTecnico}
        title="Soporte Técnico WhatsApp"
      >
        💬 Soporte Técnico
      </Button>
    </div>
  )
}

export default BotonSoporte
