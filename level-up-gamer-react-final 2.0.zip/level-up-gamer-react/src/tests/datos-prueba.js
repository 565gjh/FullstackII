// Datos de ejemplo para las pruebas. No usamos el catálogo real
// para que las pruebas no se rompan si cambian los productos.

// imagen mínima (gif de 1px) para no dejar el src vacío
const IMAGEN = 'data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7'

export const catan = {
  id: 1,
  codigo: 'JM001',
  categoria: 'Juegos de Mesa',
  nombre: 'Catan',
  precio: 29990,
  stock: 10,
  imagen: IMAGEN,
  descripcion: 'Juego de estrategia.',
  fabricante: 'KOSMOS',
  distribuidor: 'Devir Chile',
}

export const mouse = {
  ...catan,
  id: 8,
  codigo: 'MS001',
  categoria: 'Mouse',
  nombre: 'Mouse Logitech',
  precio: 49990,
  stock: 5,
}

export const carcassonne = { ...catan, id: 2, codigo: 'JM002', nombre: 'Carcassonne', precio: 24990 }

// producto sin stock
export const agotado = { ...catan, id: 4, codigo: 'AC002', nombre: 'Auriculares', stock: 0 }

export const usuarioAna = {
  nombre: 'Ana',
  correo: 'ana@duocuc.cl',
  password: 'clave123',
  puntos: 130,
  nivel: 'Hierro 🛡️',
}
