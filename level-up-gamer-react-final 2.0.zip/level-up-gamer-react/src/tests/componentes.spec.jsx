// Pruebas de componentes: se dibujan con React Testing Library y se revisa el DOM.
import { render, screen, fireEvent } from '@testing-library/react'
import TarjetaProducto from '../components/TarjetaProducto.jsx'
import Catalogo from '../components/Catalogo.jsx'
import Carrito from '../components/Carrito.jsx'
import Encabezado from '../components/Encabezado.jsx'
import PiePagina from '../components/PiePagina.jsx'
import BotonSoporte from '../components/BotonSoporte.jsx'
import contacto from '../data/contacto.js'
import { catan, agotado } from './datos-prueba.js'

describe('TarjetaProducto', () => {
  it('al presionar "Añadir al Carrito" llama a onAgregar con el producto', () => {
    const onAgregar = jasmine.createSpy('onAgregar') // función falsa para ver cómo la llaman
    render(<TarjetaProducto producto={catan} onAgregar={onAgregar} />)
    fireEvent.click(screen.getByRole('button', { name: 'Añadir al Carrito' }))
    expect(onAgregar).toHaveBeenCalledOnceWith(catan)
  })

  it('sin stock muestra el aviso y bloquea el botón', () => {
    const onAgregar = jasmine.createSpy('onAgregar')
    render(<TarjetaProducto producto={agotado} onAgregar={onAgregar} />)
    expect(screen.getByText('No hay stock disponible')).toBeTruthy()
    const boton = screen.getByRole('button', { name: 'Sin stock' })
    expect(boton.disabled).toBeTrue()
    fireEvent.click(boton)
    expect(onAgregar).not.toHaveBeenCalled()
  })
})

describe('TarjetaProducto · stock y carrito', () => {
  it('muestra el stock ya descontado y cuántas unidades lleva el cliente', () => {
    render(<TarjetaProducto producto={{ ...catan, stock: 9, enCarrito: 1 }} onAgregar={() => {}} />)
    expect(screen.getByText('9 unidades disponibles')).toBeTruthy()
    expect(screen.getByText(/Tienes 1 en tu carrito/)).toBeTruthy()
  })

  it('si ya lleva todo el stock lo indica y bloquea el botón', () => {
    render(<TarjetaProducto producto={{ ...catan, stock: 0, enCarrito: 10 }} onAgregar={() => {}} />)
    expect(screen.getByText('Ya tienes todas las unidades en tu carrito')).toBeTruthy()
    expect(screen.getByRole('button', { name: 'Máximo en tu carrito' }).disabled).toBeTrue()
  })
})

describe('Catalogo', () => {
  it('muestra un mensaje cuando no hay productos', () => {
    render(<Catalogo productos={[]} onAgregar={() => {}} />)
    expect(screen.getByText('No hay productos que coincidan con tu búsqueda.')).toBeTruthy()
  })
})

describe('Carrito', () => {
  function dibujar(items, descuentoDisponible = 0) {
    const props = {
      mostrar: true,
      onCerrar: () => {},
      items,
      descuentoDisponible,
      onCambiarCantidad: jasmine.createSpy('onCambiarCantidad'),
      onQuitar: () => {},
      onVaciar: () => {},
      onPagar: () => {},
    }
    render(<Carrito {...props} />)
    return props
  }

  it('calcula el total sumando precio × cantidad', () => {
    // 29.990 × 2 + 49.990 × 1 = 109.970
    dibujar([
      { ...catan, cantidad: 2 },
      { ...catan, id: 8, nombre: 'Mouse Logitech', precio: 49990, cantidad: 1 },
    ])
    expect(screen.getByText(/109\.970/)).toBeTruthy()
  })

  it('los botones + y − avisan con el id y el cambio', () => {
    const props = dibujar([{ ...catan, cantidad: 2 }])
    fireEvent.click(screen.getByLabelText('Sumar una unidad de Catan'))
    fireEvent.click(screen.getByLabelText('Restar una unidad de Catan'))
    expect(props.onCambiarCantidad.calls.allArgs()).toEqual([
      [1, 1],
      [1, -1],
    ])
  })

  it('aplica el descuento canjeado y muestra el total con descuento', () => {
    dibujar([{ ...catan, cantidad: 1 }], 5000)
    expect(screen.getByText(/Descuento LevelUp/).textContent).toContain('5.000')
    // 29.990 − 5.000 = 24.990
    expect(screen.getByText(/Total a pagar/).textContent).toContain('24.990')
  })

  it('bloquea el botón + cuando ya lleva todo el stock', () => {
    dibujar([{ ...catan, cantidad: 10 }]) // el stock de catan es 10
    expect(screen.getByLabelText('Sumar una unidad de Catan').disabled).toBeTrue()
    expect(screen.getByText('Máximo disponible')).toBeTruthy()
  })
})

describe('Encabezado', () => {
  const base = { pagina: 'inicio', sesionIniciada: false, cantidad: 0, onVerCarrito: () => {} }

  it('muestra "Iniciar Sesión" o "Mi Perfil" según la sesión', () => {
    const { unmount } = render(<Encabezado {...base} />)
    expect(screen.getByText('Iniciar Sesión')).toBeTruthy()
    unmount()

    render(<Encabezado {...base} sesionIniciada />)
    expect(screen.getByText('Mi Perfil')).toBeTruthy()
    expect(screen.queryByText('Iniciar Sesión')).toBeNull()
  })

  it('la lupa solo aparece en el catálogo y abre el buscador', () => {
    const buscador = {
      texto: '',
      onCambiarTexto: jasmine.createSpy('onCambiarTexto'),
      categoria: 'Todas',
      onCambiarCategoria: () => {},
      categorias: ['Mouse'],
    }
    const { unmount } = render(<Encabezado {...base} buscador={buscador} />)
    expect(screen.queryByLabelText('Buscar productos')).toBeNull()
    unmount()

    render(<Encabezado {...base} pagina="catalogo" buscador={buscador} />)
    fireEvent.click(screen.getByLabelText('Buscar productos'))
    fireEvent.change(screen.getByLabelText('Buscar producto por nombre'), { target: { value: 'ps5' } })
    expect(buscador.onCambiarTexto).toHaveBeenCalledWith('ps5')
  })
})

describe('PiePagina', () => {
  it('muestra el correo y un enlace por cada red social', () => {
    render(<PiePagina />)
    expect(screen.getByText(contacto.email).getAttribute('href')).toBe(`mailto:${contacto.email}`)
    contacto.redes.forEach((red) => {
      const enlace = screen.getByLabelText(`${red.nombre} de Level-Up Gamer`)
      expect(enlace.getAttribute('href')).toBe(red.url)
    })
  })
})

describe('BotonSoporte', () => {
  it('abre WhatsApp con el nombre del usuario', () => {
    const abrir = spyOn(window, 'open') // mock: así no se abre una pestaña de verdad
    render(<BotonSoporte nombreUsuario="Ana" />)
    fireEvent.click(screen.getByRole('button', { name: /Soporte Técnico/ }))
    const [url, destino] = abrir.calls.mostRecent().args
    expect(url).toContain('api.whatsapp.com')
    expect(url).toContain(encodeURIComponent('soy Ana'))
    expect(destino).toBe('_blank')
  })
})
