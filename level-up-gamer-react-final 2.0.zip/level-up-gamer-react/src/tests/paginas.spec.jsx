// Pruebas de las páginas con formularios (Login, Registro, Comunidad), Perfil y eventos.
import { render, screen, fireEvent } from '@testing-library/react'
import Login from '../paginas/Login.jsx'
import Registro from '../paginas/Registro.jsx'
import Perfil from '../paginas/Perfil.jsx'
import Comunidad from '../paginas/Comunidad.jsx'
import TarjetaEvento from '../components/TarjetaEvento.jsx'
import { usuarioAna } from './datos-prueba.js'

// fireEvent.submit evita la validación nativa del navegador,
// así probamos solo la validación que escribimos nosotros.
const enviar = (contenedor) => fireEvent.submit(contenedor.querySelector('form'))
const escribir = (etiqueta, valor) =>
  fireEvent.change(screen.getByLabelText(etiqueta), { target: { value: valor } })

describe('Login', () => {
  it('inicia sesión con los datos correctos', () => {
    const onIniciarSesion = jasmine.createSpy('onIniciarSesion')
    const { container } = render(<Login usuarioGuardado={usuarioAna} onIniciarSesion={onIniciarSesion} />)
    escribir('Correo Electrónico', 'ANA@duocuc.cl') // el correo no distingue mayúsculas
    escribir('Contraseña', 'clave123')
    enviar(container)
    expect(onIniciarSesion).toHaveBeenCalled()
  })

  it('con la contraseña incorrecta muestra un error y no inicia sesión', () => {
    const onIniciarSesion = jasmine.createSpy('onIniciarSesion')
    const { container } = render(<Login usuarioGuardado={usuarioAna} onIniciarSesion={onIniciarSesion} />)
    escribir('Correo Electrónico', 'ana@duocuc.cl')
    escribir('Contraseña', 'otra')
    enviar(container)
    expect(screen.getByRole('alert').textContent).toContain('incorrectos')
    expect(onIniciarSesion).not.toHaveBeenCalled()
  })
})

describe('Registro', () => {
  function llenar(edad, referido = '') {
    escribir('Nombre de Usuario', ' Ana ')
    escribir('Correo Electrónico', 'ana@duocuc.cl')
    escribir('Contraseña', 'clave123')
    escribir('Edad', edad)
    if (referido) escribir(/Código de Referido/, referido)
  }

  it('rechaza a los menores de 18 años', () => {
    const onRegistrar = jasmine.createSpy('onRegistrar')
    const { container } = render(<Registro onRegistrar={onRegistrar} />)
    llenar('17')
    enviar(container)
    expect(screen.getByRole('alert').textContent).toContain('mayor de 18')
    expect(onRegistrar).not.toHaveBeenCalled()
  })

  it('da 100 puntos de bienvenida y 50 más con código de referido', () => {
    const onRegistrar = jasmine.createSpy('onRegistrar')
    const { container, unmount } = render(<Registro onRegistrar={onRegistrar} />)
    llenar('20')
    enviar(container)
    expect(onRegistrar.calls.mostRecent().args[0]).toEqual(
      jasmine.objectContaining({ nombre: 'Ana', puntos: 100 }), // el nombre se guarda sin espacios
    )
    unmount()

    const otro = render(<Registro onRegistrar={onRegistrar} />)
    llenar('20', 'GAMER2026')
    enviar(otro.container)
    expect(onRegistrar.calls.mostRecent().args[0].puntos).toBe(150)
  })
})

describe('Perfil', () => {
  it('deshabilita los premios que no alcanzan y avisa al canjear uno que sí', () => {
    const onCanjear = jasmine.createSpy('onCanjear')
    render(<Perfil usuario={usuarioAna} sesionIniciada onCerrarSesion={() => {}} onCanjear={onCanjear} />)
    // con 130 puntos alcanza el envío gratis (125) pero no el descuento (375)
    expect(screen.getByRole('button', { name: /5\.000 dcto/ }).disabled).toBeTrue()
    fireEvent.click(screen.getByRole('button', { name: /Envío Gratis/ }))
    expect(onCanjear).toHaveBeenCalledOnceWith(125, 'Envío Gratis Nacional', 0)
  })

  it('el premio de $5.000 envía el descuento y el perfil muestra el que ya tiene', () => {
    const onCanjear = jasmine.createSpy('onCanjear')
    const usuario = { ...usuarioAna, puntos: 400, descuento: 5000 }
    render(<Perfil usuario={usuario} sesionIniciada onCerrarSesion={() => {}} onCanjear={onCanjear} />)
    expect(screen.getByText(/Descuento disponible/).parentElement.textContent).toContain('5.000')
    fireEvent.click(screen.getByRole('button', { name: /5\.000 dcto/ }))
    expect(onCanjear).toHaveBeenCalledOnceWith(375, 'Descuento de $5.000 CLP', 5000)
  })
})

describe('Comunidad (foro)', () => {
  function publicar(contenedor, autor, texto) {
    escribir(/Tu Nombre/, autor)
    escribir(/Consejo o Tip/, texto)
    enviar(contenedor)
  }

  it('publica un consejo y lo guarda en localStorage', () => {
    const { container } = render(<Comunidad nombreUsuario="" />)
    publicar(container, 'Ana', 'Usa cable de red')
    expect(screen.getByText('Usa cable de red')).toBeTruthy()
    expect(JSON.parse(localStorage.getItem('consejosComunidad'))[0].texto).toBe('Usa cable de red')
  })

  it('muestra como texto un intento de inyección HTML (XSS)', () => {
    const ataque = '<img src=x onerror="window.__xss=true">'
    const { container } = render(<Comunidad nombreUsuario="Ana" />)
    publicar(container, 'Ana', ataque)
    expect(container.querySelector('.comentario img')).toBeNull()
    expect(screen.getByText(ataque)).toBeTruthy()
    expect(window.__xss).toBeUndefined()
  })
})

describe('TarjetaEvento', () => {
  it('bloquea el check-in cuando el evento ya terminó', () => {
    const evento = { id: 1, etiqueta: 'TORNEO', lugar: 'Melipilla', descripcion: 'Torneo', puntos: 100 }
    render(<TarjetaEvento evento={{ ...evento, fechaFin: '2000-01-01' }} onCheckIn={() => {}} />)
    expect(screen.getByRole('button', { name: 'Evento finalizado' }).disabled).toBeTrue()
  })
})
