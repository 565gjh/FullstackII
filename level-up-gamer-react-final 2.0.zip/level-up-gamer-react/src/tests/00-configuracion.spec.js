// Este hook corre después de TODAS las pruebas: limpia el DOM, el localStorage y el #
// para que una prueba no afecte a la siguiente (Jasmine las ejecuta en orden aleatorio).
import { cleanup } from '@testing-library/react'

afterEach(() => {
  cleanup()
  localStorage.clear()
  window.location.hash = ''
})
