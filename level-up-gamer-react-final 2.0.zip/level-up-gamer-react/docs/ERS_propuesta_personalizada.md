# ERS · Level-Up Gamer — Propuesta personalizada (versión React)

> Esta sección se agrega al ERS que ya tienen. Completar los datos entre [corchetes].

**Equipo:** [integrantes] · **Asignatura:** DSY1104 Desarrollo Full Stack II · **Versión:** 1.1

## 1. Objetivo del cambio

Pasar el frontend de la tienda (HTML + CSS + JavaScript) a **React + Vite + React Bootstrap**,
con componentes reutilizables, navegación y formularios hechos con el framework, y pruebas
unitarias con **Jasmine + Karma**.

## 2. Propuesta personalizada

En la versión 1 había una sección «Recomendaciones personalizadas» oculta y sin lógica. Además de
integrarla, el equipo agregó mejoras pensadas para una tienda real:

| ID | Requisito | Criterio de aceptación |
| --- | --- | --- |
| RF-P1 | Mostrar «Recomendado para ti» en el inicio. | Aparecen hasta 3 productos. |
| RF-P2 | Si hay productos en el carrito, recomendar primero los de la misma categoría. | Nunca se recomienda algo que ya está en el carrito ni algo sin stock. |
| RF-P3 | Con el carrito vacío, mostrar un producto por categoría. | Se ve variedad de categorías. |
| RF-P4 | Poder agregar al carrito desde la recomendación. | Usa la misma `TarjetaProducto` y la misma función de `App`. |
| RF-P5 | Bloquear el check-in de eventos que ya terminaron. | El botón queda deshabilitado con el texto «Evento finalizado». |
| RF-P6 | Controlar el stock de cada producto. | Con stock 0 aparece «Sin stock» y no se puede agregar; el carrito no supera el stock. |
| RF-P7 | Buscar productos con una lupa en el header, solo en el catálogo. | La lupa abre la barra de búsqueda (nombre y categoría) y se puede limpiar el filtro. |
| RF-P8 | Mostrar contacto y redes sociales en el footer. | Correo, teléfono, WhatsApp, ubicación, horario y enlaces a redes. |
| RF-P9 | Login y registro sin header ni footer. | Las dos páginas ocupan toda la pantalla y tienen un enlace «Volver a la tienda». |
| RF-P10 | El stock del catálogo baja al agregar al carrito y queda descontado al pagar. | La tarjeta muestra las unidades que quedan y cuántas lleva el cliente; con todo el stock en el carrito el botón se bloquea. Al pagar, las unidades vendidas se descuentan del stock. |
| RF-P11 | Canjear puntos LevelUp por un descuento que se aplica en el carrito. | Con 375 puntos se canjean $5.000. El carrito muestra subtotal, descuento y total. Al pagar se gasta el descuento usado; si sobra, queda para otra compra. |

## 3. Requisitos funcionales del frontend

- RF-01 Navegación entre páginas con `#`, con botones Atrás y Adelante.
- RF-02 Catálogo con búsqueda por nombre y filtro por categoría.
- RF-03 Carrito en panel lateral: sumar, restar, quitar, vaciar y ver el total.
- RF-04 Registro con validación de edad (+18) y puntos de bienvenida.
- RF-05 Login y sesión de usuario.
- RF-06 Perfil con rango y canje de puntos.
- RF-07 Check-in en eventos (exige sesión iniciada).
- RF-08 Foro de consejos con el texto escapado (sin inyección de HTML).
- RF-09 Avisos que no bloquean la página (se reemplazó `alert()`).

## 4. Requisitos no funcionales

- RNF-01 Diseño responsivo con Bootstrap (`Row` y `Col`, `Navbar`, `Offcanvas`, `Ratio`).
- RNF-02 Estética gamer: negro, azul y verde neón; tipografías Orbitron y Roboto.
- RNF-03 Accesibilidad básica: `aria-label` en los botones, foco visible y respeto a «reducir animaciones».
- RNF-04 Pruebas unitarias automatizadas con la cobertura medida (ver documento de cobertura).

## 5. Restricciones y riesgos

- No hay backend: usuarios, carrito y foro se guardan en `localStorage`.
- La contraseña se guarda en texto plano porque es una simulación. Con un backend debe autenticarse en el servidor (hash y HTTPS).
- El stock, los eventos y los datos de contacto son de ejemplo y se editan en `src/data/`.
