import { useState } from 'react'
import { Container } from 'react-bootstrap'

import Portada from '../components/Portada.jsx'
import Buscador from '../components/Buscador.jsx'
import Catalogo from '../components/Catalogo.jsx'
import productos from '../data/productos.js'

function Productos({ onAgregar }) {
  // ---------- ESTADO ----------
  // El filtro solo lo usa esta página, por eso vive aquí y no en App.
  const [texto, setTexto] = useState('')
  const [categoria, setCategoria] = useState('Todas')

  // ---------- DATOS DERIVADOS (se calculan, no se guardan) ----------
  const categorias = [...new Set(productos.map((p) => p.categoria))]
  const productosFiltrados = productos.filter((p) => {
    const coincideTexto = p.nombre.toLowerCase().includes(texto.trim().toLowerCase())
    const coincideCategoria = categoria === 'Todas' || p.categoria === categoria
    return coincideTexto && coincideCategoria
  })

  return (
    <>
      <Portada
        titulo="Catálogo de Productos Oficiales"
        texto="Explora nuestra selección completa de hardware, consolas, periféricos, juegos de mesa y textiles personalizados. Calidad garantizada para la comunidad gamer."
      />

      <Container className="contenedor">
        <section className="panel">
          <h2>Inventario Disponible</h2>
          <Buscador
            texto={texto}
            onCambiarTexto={setTexto}
            categoria={categoria}
            onCambiarCategoria={setCategoria}
            categorias={categorias}
          />
          {/* Los datos bajan del padre al hijo por props */}
          <Catalogo productos={productosFiltrados} onAgregar={onAgregar} />
        </section>
      </Container>
    </>
  )
}

export default Productos
