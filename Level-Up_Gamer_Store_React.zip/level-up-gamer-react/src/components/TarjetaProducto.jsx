import { Card, Button, Badge } from 'react-bootstrap'
import { formatearPrecio } from '../utils/formato.js'

// Componente "tonto" (de presentación): solo muestra lo que recibe por props.
// No sabe nada del carrito; cuando se presiona el botón, avisa al padre
// llamando a la función onAgregar que el padre le entregó.
// Las props son de SOLO LECTURA: el componente nunca las modifica.
function TarjetaProducto({ producto, onAgregar }) {
  const { codigo, categoria, nombre, descripcion, precio, imagen, fabricante, distribuidor } =
    producto

  return (
    <Card className="tarjeta-producto h-100">
      <Card.Img
        variant="top"
        src={imagen}
        alt={`Imagen de ${nombre}`}
        className="imagen-producto"
        loading="lazy"
      />
      <Card.Body className="d-flex flex-column">
        <Badge className="etiqueta-producto align-self-start mb-2">
          [{codigo}] {categoria}
        </Badge>
        <Card.Title as="h3">{nombre}</Card.Title>
        <Card.Text className="descripcion">{descripcion}</Card.Text>

        <div className="origen-producto mb-3">
          <div>
            <strong>Fabricante:</strong> {fabricante}
          </div>
          <div>
            <strong>Distribuidor:</strong> {distribuidor}
          </div>
        </div>

        <Card.Text className="precio mt-auto">{formatearPrecio(precio)}</Card.Text>
        {/* Se pasa una FUNCIÓN: onClick={() => onAgregar(producto)}, no onAgregar(producto) */}
        <Button variant="primary" onClick={() => onAgregar(producto)}>
          Añadir al Carrito
        </Button>
      </Card.Body>
    </Card>
  )
}

export default TarjetaProducto
