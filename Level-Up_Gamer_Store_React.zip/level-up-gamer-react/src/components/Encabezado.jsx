import { Navbar, Nav, Container, Button, Badge } from 'react-bootstrap'

// Enlaces fijos del menú. Cada uno apunta a "#pagina": App escucha el cambio
// de la dirección y muestra la página correspondiente (así funcionan también
// los botones Atrás/Adelante del navegador).
const ENLACES = [
  { destino: 'inicio', texto: 'Inicio' },
  { destino: 'catalogo', texto: 'Catálogo' },
  { destino: 'comunidad', texto: 'Comunidad & Blog' },
  { destino: 'eventos', texto: 'Eventos & Mapa' },
]

// Recibe por props:
//  - pagina: cuál está abierta (para marcar el enlace activo)
//  - sesionIniciada: decide si se muestra "Mi Perfil" o "Iniciar Sesión"
//  - cantidad: cuántos productos hay en el carrito (un dato)
//  - onVerCarrito: qué hacer al presionar el botón del carrito (una función)
function Encabezado({ pagina, sesionIniciada, cantidad, onVerCarrito }) {
  return (
    <Navbar
      className="encabezado"
      data-bs-theme="dark"
      expand="lg"
      sticky="top"
      collapseOnSelect
    >
      <Container className="contenedor">
        <Navbar.Brand href="#inicio">
          LEVEL-UP <span>GAMER</span>
        </Navbar.Brand>

        {/* El carrito queda fuera del menú colapsable para verlo siempre, también en el celular */}
        <Button
          variant="outline-primary"
          size="sm"
          className="ms-auto me-2 ms-lg-0 order-lg-last"
          onClick={onVerCarrito}
        >
          🛒 Carrito <Badge bg="primary">{cantidad}</Badge>
        </Button>

        <Navbar.Toggle aria-controls="menu-principal" />
        <Navbar.Collapse id="menu-principal">
          {/* En Bootstrap 5 es "me-auto" (margin-end), ya no "mr-auto" */}
          <Nav className="me-auto">
            {ENLACES.map(({ destino, texto }) => (
              <Nav.Link key={destino} href={`#${destino}`} active={pagina === destino}>
                {texto}
              </Nav.Link>
            ))}
          </Nav>
          <Nav>
            {/* Renderizado condicional: un enlace u otro según la sesión */}
            {sesionIniciada ? (
              <Nav.Link href="#perfil" active={pagina === 'perfil'}>
                Mi Perfil
              </Nav.Link>
            ) : (
              <Nav.Link
                href="#login"
                active={pagina === 'login' || pagina === 'registro'}
              >
                Iniciar Sesión
              </Nav.Link>
            )}
          </Nav>
        </Navbar.Collapse>
      </Container>
    </Navbar>
  )
}

export default Encabezado
