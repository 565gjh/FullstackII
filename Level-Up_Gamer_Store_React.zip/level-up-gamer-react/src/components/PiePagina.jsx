import { Container } from 'react-bootstrap'

function PiePagina() {
  return (
    <footer className="pie-pagina">
      <Container className="text-center">
        <small>© 2026 Level-Up Gamer</small>
      </Container>
    </footer>
  )
}

export default PiePagina
