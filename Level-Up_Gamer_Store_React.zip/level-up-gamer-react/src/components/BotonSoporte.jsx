import { Button } from 'react-bootstrap'

const TELEFONO_SOPORTE = '56912345678' // número de contacto del soporte técnico

// Botón flotante que abre WhatsApp con un mensaje ya armado.
function BotonSoporte({ nombreUsuario }) {
  function abrirSoporteTecnico() {
    const mensaje = encodeURIComponent(
      `Hola, soy ${nombreUsuario}. Necesito ayuda con el servicio técnico de Level-Up Gamer.`,
    )
    window.open(
      `https://api.whatsapp.com/send?phone=${TELEFONO_SOPORTE}&text=${mensaje}`,
      '_blank',
      'noopener,noreferrer',
    )
  }

  return (
    <div className="boton-soporte">
      <Button
        className="btn-whatsapp rounded-pill"
        onClick={abrirSoporteTecnico}
        title="Soporte Técnico WhatsApp"
      >
        💬 Soporte Técnico
      </Button>
    </div>
  )
}

export default BotonSoporte
