import { Card, Button } from 'react-bootstrap'

// Una tarjeta del radar de eventos. Al hacer check-in avisa al padre
// con el lugar y los puntos que otorga el evento.
function TarjetaEvento({ evento, onCheckIn }) {
  const { etiqueta, lugar, descripcion, puntos } = evento

  return (
    <Card className="tarjeta-evento h-100">
      <Card.Body className="d-flex flex-column">
        <span className="etiqueta-evento">{etiqueta}</span>
        <Card.Title as="h3">{lugar}</Card.Title>
        <Card.Text>{descripcion}</Card.Text>
        <Button variant="primary" className="mt-auto" onClick={() => onCheckIn(lugar, puntos)}>
          Hacer Check-In (+{puntos} PTS)
        </Button>
      </Card.Body>
    </Card>
  )
}

export default TarjetaEvento
