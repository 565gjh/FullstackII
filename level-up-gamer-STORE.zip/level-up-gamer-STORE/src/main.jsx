import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import { BrowserRouter } from 'react-router'

// 1) Primero el CSS de Bootstrap, 2) después nuestros estilos propios,
// para que los nuestros puedan sobrescribir a Bootstrap.
import 'bootstrap/dist/css/bootstrap.min.css'
import './index.css'

import App from './App.jsx'

// BrowserRouter va UNA sola vez, envolviendo toda la aplicación: conecta React con la barra
// de direcciones. Todo lo que quede dentro puede usar rutas, enlaces y los hooks del router.
createRoot(document.getElementById('root')).render(
  <StrictMode>
    <BrowserRouter>
      <App />
    </BrowserRouter>
  </StrictMode>,
)
