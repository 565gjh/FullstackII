import { Link } from 'react-router'
import { Container, Row, Col, Button } from 'react-bootstrap'
import Portada from '../componentes/Portada.jsx'
import Recomendaciones from '../componentes/Recomendaciones.jsx'
import logo from '../assets/level-up-gamer-logo.png'

const impactos = [
  {
    id: 1,
    icono: '🏆',
    titulo: 'Apoyo a Ligas y Torneos Locales',
    texto:
      'Financiamos premios y streaming para competencias presenciales en Melipilla y regiones.',
  },
  {
    id: 2,
    icono: '🤝',
    titulo: 'Fomento a Talentos Nacionales',
    texto: 'Colaboramos con desarrolladores indie chilenos y comunidades de hardware.',
  },
]

// Inicio: portada, recomendaciones según el carrito, quiénes somos e impacto.
function Inicio({ catalogo, itemsCarrito = [], onAgregar }) {
  return (
    <>
      <Portada
        titulo="Desafía tus límites con Level-Up Gamer"
        texto="Plataforma especializada en hardware, consolas, títulos digitales y servicios técnicos en Chile."
        imagen={logo}
        altImagen="Logo Level-Up Gamer"
      >
        <Button as={Link} variant="primary" to="/catalogo" className="mt-4">
          Ver catálogo
        </Button>
      </Portada>

      <Container className="contenedor">
        <Recomendaciones catalogo={catalogo} itemsCarrito={itemsCarrito} onAgregar={onAgregar} />

        <section className="panel">
          <h2>¿Quiénes Somos?</h2>
          <p>
            Level-Up Gamer es una tienda online dedicada a satisfacer las necesidades de los
            entusiastas de los videojuegos en Chile. Lanzada hace dos años como respuesta a la
            creciente demanda durante la pandemia, Level-Up Gamer ofrece una amplia gama de
            productos para gamers, desde consolas y accesorios hasta computadores y sillas
            especializadas. Aunque no cuenta con una ubicación física, realiza despachos a todo
            el país.
          </p>
        </section>

        <section className="panel">
          <h2>Nuestro Impacto Comunitario</h2>
          <p>
            En Level-Up Gamer creemos que cada compra impulsa directamente el ecosistema local
            de videojuegos y eSports en Chile.
          </p>
          <Row xs={1} md={2} className="g-3">
            {impactos.map((impacto) => (
              <Col key={impacto.id}>
                <div className="tarjeta-info h-100">
                  <span className="icono-impacto" aria-hidden="true">
                    {impacto.icono}
                  </span>
                  <h3>{impacto.titulo}</h3>
                  <p className="mb-0">{impacto.texto}</p>
                </div>
              </Col>
            ))}
          </Row>
        </section>
      </Container>
    </>
  )
}

export default Inicio
