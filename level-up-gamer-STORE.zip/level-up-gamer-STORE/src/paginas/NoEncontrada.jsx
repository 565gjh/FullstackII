import { Link, useLocation } from 'react-router'
import { Container, Button } from 'react-bootstrap'

// Página 404: la ruta comodín path="*" la muestra cuando ninguna otra ruta coincide.
// Va dentro del Layout, así conserva la barra de navegación y el usuario puede volver.
function NoEncontrada() {
  const ubicacion = useLocation()

  return (
    <Container className="contenedor contenedor-estrecho py-5">
      <section className="panel text-center">
        <h1 className="h3">404 · Página no encontrada</h1>
        {/* mostrar la dirección que se intentó abrir ayuda a depurar */}
        <p>
          No encontramos nada en <code>{ubicacion.pathname}</code>
        </p>
        <Button as={Link} to="/" variant="primary">
          Volver al inicio
        </Button>
      </section>
    </Container>
  )
}

export default NoEncontrada
