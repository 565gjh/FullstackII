import { Link, useNavigate, useParams } from 'react-router'
import { Container, Row, Col, Button, Badge, Alert } from 'react-bootstrap'
import { formatearPrecio } from '../utils/formato.js'

// Detalle de un producto: la ruta es /producto/:id y useParams entrega el id.
// El catálogo llega por props con el stock ya descontado (lo calcula App).
function DetalleProducto({ catalogo, onAgregar }) {
  const { id } = useParams() // para /producto/3 → id vale "3" (texto)
  const navegar = useNavigate()

  // useParams siempre devuelve texto: "3" === 3 es false, por eso se convierte con Number
  const producto = catalogo.find((p) => p.id === Number(id))

  // id inventado (/producto/999): mensaje claro en vez de una pantalla rota
  if (!producto) {
    return (
      <Container className="contenedor py-4">
        <Alert variant="warning">
          <h1 className="h4">Producto no encontrado</h1>
          <p className="mb-3">
            No existe ningún producto con el código <code>{id}</code>.
          </p>
          <Button as={Link} to="/catalogo" variant="primary">
            Ver el catálogo
          </Button>
        </Alert>
      </Container>
    )
  }

  const { nombre, categoria, codigo, descripcion, precio, imagen, fabricante, distribuidor, stock } =
    producto
  const enCarrito = producto.enCarrito ?? 0
  const sinStock = stock <= 0

  return (
    <Container className="contenedor py-4">
      {/* navegar(-1) equivale al botón «atrás» del navegador */}
      <Button variant="link" className="p-0 mb-3" onClick={() => navegar(-1)}>
        ← Volver
      </Button>

      <section className="panel">
        <Row className="g-4">
          <Col md={5}>
            <img src={imagen} alt={`Imagen de ${nombre}`} className="img-fluid rounded" />
          </Col>
          <Col md={7} className="d-flex flex-column">
            <Badge className="etiqueta-producto align-self-start mb-2">
              [{codigo}] {categoria}
            </Badge>
            <h1 className="h3">{nombre}</h1>
            <p>{descripcion}</p>
            <p className="mb-1">
              <strong>Fabricante:</strong> {fabricante}
            </p>
            <p>
              <strong>Distribuidor:</strong> {distribuidor}
            </p>
            <p className="precio">{formatearPrecio(precio)}</p>
            <p className={`estado-stock ${sinStock ? 'agotado' : 'disponible'}`}>
              {sinStock
                ? enCarrito > 0
                  ? 'Ya tienes todas las unidades en tu carrito'
                  : 'No hay stock disponible'
                : `${stock} unidades disponibles`}
            </p>
            <div className="mt-auto">
              <Button variant="primary" disabled={sinStock} onClick={() => onAgregar(producto)}>
                {sinStock ? 'Sin stock' : 'Añadir al Carrito'}
              </Button>
            </div>
          </Col>
        </Row>
      </section>
    </Container>
  )
}

export default DetalleProducto
