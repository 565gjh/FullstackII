// Pruebas del enrutamiento (React Router): el mapa de rutas, la ruta 404, la ruta con parámetro
// (useParams), el filtro guardado en la URL (useSearchParams) y la navegación con useNavigate.
import { render, screen, fireEvent, within } from '@testing-library/react'
import { MemoryRouter, Routes, Route } from 'react-router'
import { renderApp, UbicacionActual } from './ayudas-router.jsx'
import DetalleProducto from '../paginas/DetalleProducto.jsx'
import NoEncontrada from '../paginas/NoEncontrada.jsx'
import { catan, mouse, agotado } from './datos-prueba.js'

const ubicacion = () => screen.getByTestId('ubicacion').textContent
const botonesAnadir = () => screen.queryAllByRole('button', { name: 'Añadir al Carrito' })

describe('Ruta 404 (path="*")', () => {
  it('una dirección inventada muestra la página 404 con la dirección que se intentó abrir', () => {
    renderApp('/catalgo')
    expect(screen.getByRole('heading', { name: /404/ })).toBeTruthy()
    expect(screen.getByText('/catalgo')).toBeTruthy()
  })

  it('la página 404 conserva el header y el footer del Layout', () => {
    const { container } = renderApp('/no-existe')
    expect(container.querySelector('header')).not.toBeNull()
    expect(container.querySelector('footer')).not.toBeNull()
  })

  it('el enlace «Volver al inicio» lleva a "/"', () => {
    renderApp('/no-existe')
    fireEvent.click(screen.getByRole('button', { name: 'Volver al inicio' }))
    expect(ubicacion()).toBe('/')
    expect(screen.getByText('Recomendado para ti')).toBeTruthy()
  })

  it('NoEncontrada, aislada, muestra la ruta de useLocation', () => {
    render(
      <MemoryRouter initialEntries={['/x/y']}>
        <NoEncontrada />
      </MemoryRouter>,
    )
    expect(screen.getByText('/x/y')).toBeTruthy()
  })
})

describe('Layout y NavLink', () => {
  it('el menú navega sin recargar y marca la ruta activa', () => {
    const { container } = renderApp('/')
    const header = within(container.querySelector('header'))
    expect(header.getByRole('link', { name: 'Inicio' }).classList.contains('active')).toBe(true)

    fireEvent.click(header.getByRole('link', { name: 'Eventos & Mapa' }))
    expect(ubicacion()).toBe('/eventos')
    expect(header.getByRole('link', { name: 'Eventos & Mapa' }).classList.contains('active')).toBe(true)
    expect(header.getByRole('link', { name: 'Inicio' }).classList.contains('active')).toBe(false)
  })



  it('ninguna página interna usa <a href="#…"> (la navegación es con Link)', () => {
    const { container } = renderApp('/')
    const conHash = [...container.querySelectorAll('a[href^="#"]')]
    expect(conHash.length).toBe(0)
  })
})

describe('Ruta con parámetro: /producto/:id', () => {
  it('desde el catálogo, «Ver detalle» abre la ruta del producto', () => {
    renderApp('/catalogo')
    fireEvent.click(screen.getAllByRole('button', { name: 'Ver detalle' })[0])
    expect(ubicacion()).toBe('/producto/1')
    expect(screen.getByRole('heading', { name: 'Catan' })).toBeTruthy()
  })

  it('al abrir la dirección directamente (otra pestaña) se ve ese mismo producto', () => {
    renderApp('/producto/8')
    expect(screen.getByRole('heading', { name: /Logitech G502/ })).toBeTruthy()
  })

  it('un id inventado muestra un mensaje claro, no una pantalla rota', () => {
    renderApp('/producto/999')
    expect(screen.getByText('Producto no encontrado')).toBeTruthy()
    expect(screen.getByRole('button', { name: 'Ver el catálogo' }).getAttribute('href')).toBe('/catalogo')
  })

  it('un id que no es número también se trata como inexistente', () => {
    renderApp('/producto/abc')
    expect(screen.getByText('Producto no encontrado')).toBeTruthy()
  })

  it('el id llega como texto: se compara con Number(id) (si no, nunca lo encontraría)', () => {
    render(
      <MemoryRouter initialEntries={['/producto/1']}>
        <Routes>
          <Route path="/producto/:id" element={<DetalleProducto catalogo={[catan, mouse]} onAgregar={() => {}} />} />
        </Routes>
      </MemoryRouter>,
    )
    expect(screen.getByRole('heading', { name: 'Catan' })).toBeTruthy()
    expect(screen.queryByText('Producto no encontrado')).toBeNull()
  })

  it('«Añadir al Carrito» del detalle llama a onAgregar con el producto', () => {
    const onAgregar = vi.fn()
    render(
      <MemoryRouter initialEntries={['/producto/1']}>
        <Routes>
          <Route path="/producto/:id" element={<DetalleProducto catalogo={[catan]} onAgregar={onAgregar} />} />
        </Routes>
      </MemoryRouter>,
    )
    fireEvent.click(screen.getByRole('button', { name: 'Añadir al Carrito' }))
    expect(onAgregar).toHaveBeenCalledTimes(1)
    expect(onAgregar).toHaveBeenCalledWith(catan)
  })

  it('un producto sin stock bloquea el botón del detalle', () => {
    render(
      <MemoryRouter initialEntries={['/producto/4']}>
        <Routes>
          <Route path="/producto/:id" element={<DetalleProducto catalogo={[agotado]} onAgregar={() => {}} />} />
        </Routes>
      </MemoryRouter>,
    )
    expect(screen.getByRole('button', { name: 'Sin stock' }).disabled).toBe(true)
    expect(screen.getByText('No hay stock disponible')).toBeTruthy()
  })

  it('agregar desde el detalle actualiza el carrito y el stock que muestra la página', () => {
    renderApp('/producto/1')
    expect(screen.getByText('12 unidades disponibles')).toBeTruthy()
    fireEvent.click(screen.getByRole('button', { name: 'Añadir al Carrito' }))
    expect(screen.getByText('11 unidades disponibles')).toBeTruthy()
    expect(document.title).toBe('(1) Level-Up Gamer')
  })

  it('«Volver» usa navigate(-1): regresa a la página anterior de la historia', () => {
    renderApp(['/catalogo', '/producto/1'])
    expect(ubicacion()).toBe('/producto/1')
    fireEvent.click(screen.getByRole('button', { name: /Volver/ }))
    expect(ubicacion()).toBe('/catalogo')
  })
})

describe('Filtro del catálogo en la URL (useSearchParams)', () => {
  it('escribir en el buscador cambia la URL', () => {
    renderApp('/catalogo')
    fireEvent.click(screen.getByLabelText('Buscar productos'))
    fireEvent.change(screen.getByLabelText('Buscar producto por nombre'), { target: { value: 'catan' } })
    expect(ubicacion()).toBe('/catalogo?buscar=catan')
    expect(botonesAnadir().length).toBe(1)
  })

  it('abrir una URL con filtro reproduce el filtro (enlace copiado a otra pestaña)', () => {
    renderApp('/catalogo?buscar=catan')
    expect(botonesAnadir().length).toBe(1)
    expect(screen.getByLabelText('Buscar producto por nombre').value).toBe('catan')
  })

  it('el filtro por categoría también vive en la URL', () => {
    renderApp('/catalogo?categoria=Juegos%20de%20Mesa')
    expect(botonesAnadir().length).toBe(2) // Catan y Carcassonne
    fireEvent.change(screen.getByLabelText('Filtrar por categoría'), { target: { value: 'Mouse' } })
    expect(ubicacion()).toBe('/catalogo?categoria=Mouse')
    expect(botonesAnadir().length).toBe(1)
  })

  it('texto y categoría se combinan sin pisarse', () => {
    renderApp('/catalogo?buscar=catan')
    fireEvent.change(screen.getByLabelText('Filtrar por categoría'), { target: { value: 'Juegos de Mesa' } })
    expect(ubicacion()).toBe('/catalogo?buscar=catan&categoria=Juegos+de+Mesa')
  })

  it('elegir «Todas las categorías» borra el parámetro de la URL', () => {
    renderApp('/catalogo?categoria=Mouse')
    fireEvent.change(screen.getByLabelText('Filtrar por categoría'), { target: { value: 'Todas' } })
    expect(ubicacion()).toBe('/catalogo')
  })

  it('«Limpiar búsqueda» deja la URL sin parámetros y muestra todo el catálogo', () => {
    renderApp('/catalogo?buscar=catan')
    fireEvent.click(screen.getByText('Limpiar búsqueda'))
    expect(ubicacion()).toBe('/catalogo')
    expect(botonesAnadir().length).toBe(9)
  })

  it('sin coincidencias se muestra un aviso', () => {
    renderApp('/catalogo?buscar=zzzz')
    expect(screen.getByText('No hay productos que coincidan con tu búsqueda.')).toBeTruthy()
  })

  it('la lupa no aparece fuera del catálogo', () => {
    renderApp('/')
    expect(screen.queryByLabelText('Buscar productos')).toBeNull()
  })
})

describe('UbicacionActual (ayuda de pruebas)', () => {
  it('refleja la ruta inicial del MemoryRouter', () => {
    render(
      <MemoryRouter initialEntries={['/catalogo?buscar=a']}>
        <UbicacionActual />
      </MemoryRouter>,
    )
    expect(ubicacion()).toBe('/catalogo?buscar=a')
  })
})
