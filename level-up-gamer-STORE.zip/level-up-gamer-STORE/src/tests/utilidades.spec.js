// Pruebas de las funciones de utils. Son funciones puras: entran datos y sale un resultado.
import { formatearPrecio } from '../utils/formato.js'
import { calcularNivel } from '../utils/niveles.js'
import { leerGuardado, guardar } from '../utils/almacenamiento.js'
import { eventoFinalizado } from '../utils/eventos.js'
import { recomendarProductos } from '../utils/recomendaciones.js'
import { calcularTotales } from '../utils/precios.js'
import { catan, carcassonne, mouse, agotado } from './datos-prueba.js'

describe('formatearPrecio', () => {
  it('usa punto como separador de miles y termina en CLP', () => {
    const texto = formatearPrecio(29990)
    expect(texto).toContain('29.990')
    expect(texto.endsWith('CLP')).toBe(true)
  })
})

describe('calcularNivel', () => {
  it('cambia de rango justo en 200, 600 y 1200 puntos', () => {
    expect(calcularNivel(199)).toContain('Hierro')
    expect(calcularNivel(200)).toContain('Oro')
    expect(calcularNivel(600)).toContain('Platino')
    expect(calcularNivel(1200)).toContain('Challenger')
  })
})

describe('calcularTotales', () => {
  const items = [
    { precio: 10000, cantidad: 2 },
    { precio: 5000, cantidad: 1 },
  ]

  it('sin descuento el total es el subtotal', () => {
    expect(calcularTotales(items)).toEqual({ subtotal: 25000, descuentoAplicado: 0, total: 25000 })
  })

  it('resta el descuento canjeado, pero nunca deja el total bajo cero', () => {
    expect(calcularTotales(items, 5000).total).toBe(20000)
    const grande = calcularTotales(items, 100000)
    expect(grande.descuentoAplicado).toBe(25000) // solo se usa hasta el subtotal
    expect(grande.total).toBe(0)
  })
})

describe('almacenamiento (localStorage)', () => {
  it('guarda y lee un objeto; si la clave no existe devuelve el valor por defecto', () => {
    guardar('prueba', { a: 1 })
    expect(leerGuardado('prueba', null)).toEqual({ a: 1 })
    expect(leerGuardado('no-existe', 'por-defecto')).toBe('por-defecto')
  })

  it('devuelve el valor por defecto si el JSON guardado está dañado', () => {
    localStorage.setItem('roto', '{esto no es json')
    expect(leerGuardado('roto', [])).toEqual([])
  })

  // Mock: vi.spyOn reemplaza el método real por uno que falla, como un navegador sin espacio
  it('no lanza error si localStorage falla al guardar', () => {
    vi.spyOn(Storage.prototype, 'setItem').mockImplementation(() => {
      throw new Error('almacenamiento lleno')
    })
    expect(() => guardar('x', 1)).not.toThrow()
  })
})

describe('eventoFinalizado', () => {
  const hoy = new Date('2026-10-21T10:00:00')

  it('solo es true cuando la fecha de término ya pasó', () => {
    expect(eventoFinalizado({ fechaFin: '2026-10-04' }, hoy)).toBe(true)
    expect(eventoFinalizado({ fechaFin: '2026-10-21' }, hoy)).toBe(false) // termina hoy
    expect(eventoFinalizado({}, hoy)).toBe(false) // sin fecha nunca termina
  })
})

describe('recomendarProductos', () => {
  const catalogo = [catan, carcassonne, mouse, agotado]

  it('con carrito recomienda primero la misma categoría y no repite ni sugiere agotados', () => {
    const { motivo, productos } = recomendarProductos(catalogo, [{ ...catan, cantidad: 1 }])
    expect(motivo).toBe('afines')
    expect(productos.map((p) => p.id)).toEqual([2, 8])
  })

  it('sin carrito entrega un producto por categoría', () => {
    const { motivo, productos } = recomendarProductos(catalogo, [])
    expect(motivo).toBe('destacados')
    expect(productos.map((p) => p.id)).toEqual([1, 8])
  })
})
