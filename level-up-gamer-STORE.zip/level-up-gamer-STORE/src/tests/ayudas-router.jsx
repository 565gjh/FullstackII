// Ayudas para probar componentes que usan React Router.
// En las pruebas no hay barra de direcciones real, así que se usa MemoryRouter:
// un router que guarda la historia en memoria y arranca en la ruta que se le indique.
import { render } from '@testing-library/react'
import { MemoryRouter, useLocation } from 'react-router'
import App from '../App.jsx'

// dibuja un componente dentro de un router, parado en la ruta indicada
export function renderConRuta(ui, ruta = '/') {
  return render(<MemoryRouter initialEntries={[ruta]}>{ui}</MemoryRouter>)
}

// Muestra la dirección actual en el DOM para poder comprobarla con expect.
export function UbicacionActual() {
  const { pathname, search } = useLocation()
  return <output data-testid="ubicacion">{pathname + search}</output>
}

// dibuja la aplicación completa; "entradas" es la historia inicial (la última es la actual)
export function renderApp(ruta = '/') {
  const entradas = Array.isArray(ruta) ? ruta : [ruta]
  return render(
    <MemoryRouter initialEntries={entradas} initialIndex={entradas.length - 1}>
      <App />
      <UbicacionActual />
    </MemoryRouter>,
  )
}
