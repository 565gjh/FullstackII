// Pruebas que simulan a una persona con userEvent: escribe letra por letra, hace clic y espera
// a que React termine. userEvent es más fiel que fireEvent porque dispara la misma cadena de
// eventos del navegador (foco, teclas, clic). Cada acción lleva await.
import { screen } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { renderApp } from './ayudas-router.jsx'

describe('Interacciones con userEvent', () => {
  it('al escribir en el buscador el catálogo se filtra y la URL guarda el texto', async () => {
    const usuario = userEvent.setup()
    renderApp('/catalogo')

    await usuario.click(screen.getByLabelText('Buscar productos'))
    await usuario.type(screen.getByLabelText('Buscar producto por nombre'), 'catan')

    expect(screen.getByTestId('ubicacion')).toHaveTextContent('/catalogo?buscar=catan')
    expect(screen.getAllByRole('button', { name: 'Añadir al Carrito' })).toHaveLength(1)
  })

  it('agrega un producto, abre el carrito y suma una unidad: el total se actualiza', async () => {
    const usuario = userEvent.setup()
    renderApp('/catalogo')

    await usuario.click(screen.getAllByRole('button', { name: 'Añadir al Carrito' })[0]) // Catan $29.990
    await usuario.click(screen.getByRole('button', { name: /^🛒 Carrito/ }))
    expect(screen.getByText(/Total a pagar/)).toHaveTextContent('29.990')

    await usuario.click(screen.getByLabelText('Sumar una unidad de Catan'))
    expect(screen.getByText(/Total a pagar/)).toHaveTextContent('59.980') // 29.990 × 2
  })

  it('el botón + del carrito se bloquea cuando se llega al stock', async () => {
    const usuario = userEvent.setup()
    renderApp('/producto/5') // PlayStation 5: stock 3
    for (let i = 0; i < 3; i++) {
      await usuario.click(screen.getByRole('button', { name: 'Añadir al Carrito' }))
    }
    expect(screen.getByRole('button', { name: 'Sin stock' })).toBeDisabled()
  })

  it('de la tarjeta al detalle y de vuelta con «Volver»', async () => {
    const usuario = userEvent.setup()
    renderApp('/catalogo')

    await usuario.click(screen.getAllByRole('button', { name: 'Ver detalle' })[0])
    expect(screen.getByTestId('ubicacion')).toHaveTextContent('/producto/1')
    expect(screen.getByRole('heading', { name: 'Catan' })).toBeInTheDocument()

    await usuario.click(screen.getByRole('button', { name: /Volver/ }))
    expect(screen.getByTestId('ubicacion')).toHaveTextContent('/catalogo')
  })

  it('el formulario de login muestra el error si los datos no coinciden', async () => {
    const usuario = userEvent.setup()
    localStorage.setItem(
      'usuarioPerfil',
      JSON.stringify({ nombre: 'Ana', correo: 'ana@duocuc.cl', password: 'clave123', puntos: 0, nivel: 'Hierro' }),
    )
    renderApp('/login')

    await usuario.type(screen.getByLabelText('Correo Electrónico'), 'ana@duocuc.cl')
    await usuario.type(screen.getByLabelText('Contraseña'), 'otra')
    await usuario.click(screen.getByRole('button', { name: 'Entrar' }))

    expect(await screen.findByRole('alert')).toHaveTextContent('incorrectos')
    expect(screen.getByTestId('ubicacion')).toHaveTextContent('/login') // no avanzó
  })
})
