// Prueba de integración: la aplicación completa con su mapa de rutas.
// renderApp la dibuja dentro de un MemoryRouter y deja visible la dirección actual
// (data-testid="ubicacion") para comprobar a dónde navegó la app.
import { screen, fireEvent, within } from '@testing-library/react'
import { renderApp } from './ayudas-router.jsx'
import { usuarioAna } from './datos-prueba.js'

const escribir = (etiqueta, valor) =>
  fireEvent.change(screen.getByLabelText(etiqueta), { target: { value: valor } })
const ubicacion = () => screen.getByTestId('ubicacion').textContent

describe('App (integración)', () => {
  it('al agregar un producto actualiza el título y guarda el carrito', () => {
    renderApp('/catalogo')
    fireEvent.click(screen.getAllByRole('button', { name: 'Añadir al Carrito' })[0])
    expect(document.title).toBe('(1) Level-Up Gamer')
    expect(screen.getByText(/se agregó al carrito/)).toBeTruthy()
    expect(JSON.parse(localStorage.getItem('carrito-levelup'))).toEqual([{ id: 1, cantidad: 1 }])
  })

  it('no deja agregar más unidades que el stock (la PS5 tiene 3)', () => {
    renderApp('/catalogo')
    // el cuarto botón "Añadir" es el de la PS5 (el producto agotado no tiene ese botón)
    const botonPS5 = () => screen.getAllByRole('button', { name: 'Añadir al Carrito' })[3]
    for (let i = 0; i < 3; i++) fireEvent.click(botonPS5())
    expect(JSON.parse(localStorage.getItem('carrito-levelup'))).toEqual([{ id: 5, cantidad: 3 }])
    // ya lleva las 3 unidades: el botón queda bloqueado
    expect(screen.getByRole('button', { name: 'Máximo en tu carrito' }).disabled).toBe(true)
    expect(screen.getByText('Ya tienes todas las unidades en tu carrito')).toBeTruthy()
  })

  it('al agregar un producto el catálogo muestra una unidad menos', () => {
    renderApp('/catalogo')
    expect(screen.getByText('12 unidades disponibles')).toBeTruthy() // Catan
    fireEvent.click(screen.getAllByRole('button', { name: 'Añadir al Carrito' })[0])
    expect(screen.getByText('11 unidades disponibles')).toBeTruthy()
    expect(screen.getByText(/Tienes 1 en tu carrito/)).toBeTruthy()
  })

  it('el carrito sobrevive a una recarga: se lee de localStorage al arrancar', () => {
    localStorage.setItem('carrito-levelup', JSON.stringify([{ id: 1, cantidad: 2 }]))
    renderApp('/catalogo')
    expect(document.title).toBe('(2) Level-Up Gamer')
    expect(screen.getByText('10 unidades disponibles')).toBeTruthy() // 12 − 2 en el carrito
  })

  it('canjear puntos da un descuento que se aplica en el carrito; al pagar se descuenta el stock', async () => {
    localStorage.setItem('usuarioPerfil', JSON.stringify({ ...usuarioAna, puntos: 400 }))
    localStorage.setItem('sesionIniciada', 'true')
    const { container } = renderApp('/perfil')
    fireEvent.click(screen.getByRole('button', { name: /5\.000 dcto/ }))
    expect(screen.getByText(/Descuento disponible/)).toBeTruthy()

    // el enlace del header lleva al catálogo (sin recargar la página)
    fireEvent.click(within(container.querySelector('header')).getByText('Catálogo'))
    await screen.findByText('Inventario Disponible')
    expect(ubicacion()).toBe('/catalogo')
    fireEvent.click(screen.getAllByRole('button', { name: 'Añadir al Carrito' })[0]) // Catan $29.990
    fireEvent.click(screen.getByRole('button', { name: /^🛒 Carrito/ }))
    expect(screen.getByText(/Descuento LevelUp/).textContent).toContain('5.000')
    expect(screen.getByText(/Total a pagar/).textContent).toContain('24.990') // 29.990 − 5.000

    fireEvent.click(screen.getByText('Proceder al Pago'))
    expect(JSON.parse(localStorage.getItem('stock-vendido'))).toEqual({ 1: 1 }) // se vendió 1 Catan
    expect(JSON.parse(localStorage.getItem('usuarioPerfil')).descuento).toBe(0) // el descuento se usó
    expect(ubicacion()).toBe('/perfil') // tras pagar, useNavigate lleva al perfil
  })

  it('pagar sin sesión redirige a /login', () => {
    renderApp('/catalogo')
    fireEvent.click(screen.getAllByRole('button', { name: 'Añadir al Carrito' })[0])
    fireEvent.click(screen.getByRole('button', { name: /^🛒 Carrito/ }))
    fireEvent.click(screen.getByText('Proceder al Pago'))
    expect(ubicacion()).toBe('/login')
  })

  it('el inicio ("/") muestra las recomendaciones', () => {
    renderApp('/')
    expect(screen.getByText('Recomendado para ti')).toBeTruthy()
  })


  it('con sesión, el check-in en un evento suma puntos al usuario', () => {
    localStorage.setItem('usuarioPerfil', JSON.stringify(usuarioAna))
    localStorage.setItem('sesionIniciada', 'true')
    renderApp('/eventos')
    // se toma un evento que siga vigente (no depende de la fecha en que se corran las pruebas)
    const boton = screen.getAllByRole('button', { name: /Check-In/ }).find((b) => !b.disabled)
    fireEvent.click(boton)
    expect(screen.getByText(/Check-in realizado/)).toBeTruthy()
    expect(JSON.parse(localStorage.getItem('usuarioPerfil')).puntos).toBeGreaterThan(usuarioAna.puntos)
  })
})
