// Pruebas de componentes: se dibujan con React Testing Library y se revisa el DOM.
// Los que usan Link/NavLink se dibujan dentro de un MemoryRouter (renderConRuta).
import { screen, fireEvent } from '@testing-library/react'
import { renderConRuta } from './ayudas-router.jsx'
import TarjetaProducto from '../componentes/TarjetaProducto.jsx'
import Catalogo from '../componentes/Catalogo.jsx'
import Carrito from '../componentes/Carrito.jsx'
import Encabezado from '../componentes/Encabezado.jsx'
import PiePagina from '../componentes/PiePagina.jsx'
import BotonSoporte from '../componentes/BotonSoporte.jsx'
import contacto from '../data/contacto.js'
import { catan, agotado } from './datos-prueba.js'

describe('TarjetaProducto', () => {
  it('al presionar "Añadir al Carrito" llama a onAgregar con el producto', () => {
    const onAgregar = vi.fn() // función falsa para ver cómo la llaman
    renderConRuta(<TarjetaProducto producto={catan} onAgregar={onAgregar} />)
    fireEvent.click(screen.getByRole('button', { name: 'Añadir al Carrito' }))
    expect(onAgregar).toHaveBeenCalledTimes(1)
    expect(onAgregar).toHaveBeenCalledWith(catan)
  })

  it('sin stock muestra el aviso y bloquea el botón', () => {
    const onAgregar = vi.fn()
    renderConRuta(<TarjetaProducto producto={agotado} onAgregar={onAgregar} />)
    expect(screen.getByText('No hay stock disponible')).toBeTruthy()
    const boton = screen.getByRole('button', { name: 'Sin stock' })
    expect(boton.disabled).toBe(true)
    fireEvent.click(boton)
    expect(onAgregar).not.toHaveBeenCalled()
  })
})

describe('TarjetaProducto · detalle', () => {
  it('trae un enlace «Ver detalle» a /producto/:id', () => {
    renderConRuta(<TarjetaProducto producto={catan} onAgregar={() => {}} />)
    expect(screen.getByRole('button', { name: 'Ver detalle' }).getAttribute('href')).toBe('/producto/1')
  })
})

describe('TarjetaProducto · stock y carrito', () => {
  it('muestra el stock ya descontado y cuántas unidades lleva el cliente', () => {
    renderConRuta(<TarjetaProducto producto={{ ...catan, stock: 9, enCarrito: 1 }} onAgregar={() => {}} />)
    expect(screen.getByText('9 unidades disponibles')).toBeTruthy()
    expect(screen.getByText(/Tienes 1 en tu carrito/)).toBeTruthy()
  })

  it('si ya lleva todo el stock lo indica y bloquea el botón', () => {
    renderConRuta(<TarjetaProducto producto={{ ...catan, stock: 0, enCarrito: 10 }} onAgregar={() => {}} />)
    expect(screen.getByText('Ya tienes todas las unidades en tu carrito')).toBeTruthy()
    expect(screen.getByRole('button', { name: 'Máximo en tu carrito' }).disabled).toBe(true)
  })
})

describe('Catalogo', () => {
  it('muestra un mensaje cuando no hay productos', () => {
    renderConRuta(<Catalogo productos={[]} onAgregar={() => {}} />)
    expect(screen.getByText('No hay productos que coincidan con tu búsqueda.')).toBeTruthy()
  })
})

describe('Carrito', () => {
  function dibujar(items, descuentoDisponible = 0) {
    const props = {
      mostrar: true,
      onCerrar: () => {},
      items,
      descuentoDisponible,
      onCambiarCantidad: vi.fn(),
      onQuitar: () => {},
      onVaciar: () => {},
      onPagar: () => {},
    }
    renderConRuta(<Carrito {...props} />)
    return props
  }

  it('calcula el total sumando precio × cantidad', () => {
    // 29.990 × 2 + 49.990 × 1 = 109.970
    dibujar([
      { ...catan, cantidad: 2 },
      { ...catan, id: 8, nombre: 'Mouse Logitech', precio: 49990, cantidad: 1 },
    ])
    expect(screen.getByText(/109\.970/)).toBeTruthy()
  })

  it('los botones + y − avisan con el id y el cambio', () => {
    const props = dibujar([{ ...catan, cantidad: 2 }])
    fireEvent.click(screen.getByLabelText('Sumar una unidad de Catan'))
    fireEvent.click(screen.getByLabelText('Restar una unidad de Catan'))
    expect(props.onCambiarCantidad.mock.calls).toEqual([
      [1, 1],
      [1, -1],
    ])
  })

  it('aplica el descuento canjeado y muestra el total con descuento', () => {
    dibujar([{ ...catan, cantidad: 1 }], 5000)
    expect(screen.getByText(/Descuento LevelUp/).textContent).toContain('5.000')
    // 29.990 − 5.000 = 24.990
    expect(screen.getByText(/Total a pagar/).textContent).toContain('24.990')
  })

  it('con el carrito vacío ofrece un enlace al catálogo', () => {
    dibujar([])
    expect(screen.getByRole('button', { name: 'Explorar catálogo' }).getAttribute('href')).toBe('/catalogo')
  })

  it('bloquea el botón + cuando ya lleva todo el stock', () => {
    dibujar([{ ...catan, cantidad: 10 }]) // el stock de catan es 10
    expect(screen.getByLabelText('Sumar una unidad de Catan').disabled).toBe(true)
    expect(screen.getByText('Máximo disponible')).toBeTruthy()
  })
})

describe('Encabezado', () => {
  const base = { sesionIniciada: false, cantidad: 0, onVerCarrito: () => {} }

  it('muestra "Iniciar Sesión" o "Mi Perfil" según la sesión', () => {
    const { unmount } = renderConRuta(<Encabezado {...base} />)
    expect(screen.getByText('Iniciar Sesión')).toBeTruthy()
    unmount()

    renderConRuta(<Encabezado {...base} sesionIniciada />)
    expect(screen.getByText('Mi Perfil')).toBeTruthy()
    expect(screen.queryByText('Iniciar Sesión')).toBeNull()
  })

  it('los enlaces del menú apuntan a rutas reales, no a #', () => {
    renderConRuta(<Encabezado {...base} />)
    expect(screen.getByRole('link', { name: 'Catálogo' }).getAttribute('href')).toBe('/catalogo')
    expect(screen.getByRole('link', { name: 'Eventos & Mapa' }).getAttribute('href')).toBe('/eventos')
    expect(screen.getByRole('link', { name: 'Iniciar Sesión' }).getAttribute('href')).toBe('/login')
  })

  it('NavLink marca como activo solo el enlace de la ruta actual (y "Inicio" lleva end)', () => {
    renderConRuta(<Encabezado {...base} />, '/catalogo')
    expect(screen.getByRole('link', { name: 'Catálogo' }).classList.contains('active')).toBe(true)
    // sin "end", "/" quedaría activo en todas las páginas
    expect(screen.getByRole('link', { name: 'Inicio' }).classList.contains('active')).toBe(false)
  })

  it('el botón del carrito muestra la cantidad y avisa al presionarlo', () => {
    const onVerCarrito = vi.fn()
    renderConRuta(<Encabezado {...base} cantidad={3} onVerCarrito={onVerCarrito} />)
    const boton = screen.getByRole('button', { name: /Carrito/ })
    expect(boton.textContent).toContain('3')
    fireEvent.click(boton)
    expect(onVerCarrito).toHaveBeenCalledTimes(1)
  })

  it('la lupa solo aparece si el Layout entrega un buscador y abre el buscador', () => {
    const buscador = {
      texto: '',
      onCambiarTexto: vi.fn(),
      categoria: 'Todas',
      onCambiarCategoria: () => {},
      categorias: ['Mouse'],
    }
    const { unmount } = renderConRuta(<Encabezado {...base} />)
    expect(screen.queryByLabelText('Buscar productos')).toBeNull()
    unmount()

    renderConRuta(<Encabezado {...base} buscador={buscador} />)
    fireEvent.click(screen.getByLabelText('Buscar productos'))
    fireEvent.change(screen.getByLabelText('Buscar producto por nombre'), { target: { value: 'ps5' } })
    expect(buscador.onCambiarTexto).toHaveBeenCalledWith('ps5')
  })
})

describe('PiePagina', () => {
  it('muestra el correo y un enlace por cada red social', () => {
    renderConRuta(<PiePagina />)
    expect(screen.getByText(contacto.email).getAttribute('href')).toBe(`mailto:${contacto.email}`)
    contacto.redes.forEach((red) => {
      const enlace = screen.getByLabelText(`${red.nombre} de Level-Up Gamer`)
      expect(enlace.getAttribute('href')).toBe(red.url)
    })
  })
})

describe('PiePagina · enlaces internos', () => {
  it('usa rutas del router (Link) para las páginas de la tienda', () => {
    renderConRuta(<PiePagina />)
    expect(screen.getByRole('link', { name: 'Catálogo' }).getAttribute('href')).toBe('/catalogo')
    expect(screen.getByRole('link', { name: /Comunidad/ }).getAttribute('href')).toBe('/comunidad')
  })
})

describe('BotonSoporte', () => {
  it('abre WhatsApp con el nombre del usuario', () => {
    const abrir = vi.spyOn(window, 'open').mockImplementation(() => null) // mock: así no se abre una pestaña de verdad
    renderConRuta(<BotonSoporte nombreUsuario="Ana" />)
    fireEvent.click(screen.getByRole('button', { name: /Soporte Técnico/ }))
    const [url, destino] = abrir.mock.lastCall
    expect(url).toContain('api.whatsapp.com')
    expect(url).toContain(encodeURIComponent('soy Ana'))
    expect(destino).toBe('_blank')
  })
})
