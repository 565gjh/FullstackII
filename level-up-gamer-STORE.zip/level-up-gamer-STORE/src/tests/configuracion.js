// Configuración global de las pruebas (Vitest). Se carga ANTES de cada archivo de pruebas
// porque vite.config.js la declara en test.setupFiles.
import '@testing-library/jest-dom/vitest' // matchers extra: toBeInTheDocument, toBeDisabled, toHaveTextContent…
import { cleanup } from '@testing-library/react'
import { afterEach, vi } from 'vitest'

// jsdom no implementa window.scrollTo (el Layout lo llama al cambiar de página)
window.scrollTo = vi.fn()

// jsdom tampoco implementa window.matchMedia, y el Offcanvas de React Bootstrap (el carrito)
// lo usa al dibujarse. Esta versión mínima responde "no coincide" y acepta los listeners.
// Es una función normal (no vi.fn) para que vi.restoreAllMocks no la deshaga.
window.matchMedia = (query) => ({
  matches: false,
  media: query,
  onchange: null,
  addListener() {},
  removeListener() {},
  addEventListener() {},
  removeEventListener() {},
  dispatchEvent: () => false,
})

// Después de CADA prueba: limpia el DOM, el localStorage y los mocks (vi.spyOn),
// para que una prueba no afecte a la siguiente. La dirección no hay que limpiarla:
// cada prueba crea su propio MemoryRouter.
afterEach(() => {
  cleanup()
  localStorage.clear()
  vi.restoreAllMocks()
})
