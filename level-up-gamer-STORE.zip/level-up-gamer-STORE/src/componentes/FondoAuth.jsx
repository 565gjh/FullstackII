import { Link } from 'react-router'

// Fondo con pixel art que comparten Login y Registro.
// Estas dos páginas no llevan header ni footer, por eso trae su propio
// enlace para volver a la tienda. "children" es el formulario.
function FondoAuth({ imagen, children }) {
  return (
    <div className="fondo-auth">
      <Link to="/" className="volver-inicio">
        ← Volver a la tienda
      </Link>

      <div className="envoltorio-auth">
        {imagen && <img src={imagen} alt="Logo Level-Up Gamer" className="imagen-auth" />}
        <div className="caja-auth">{children}</div>
      </div>
    </div>
  )
}

export default FondoAuth
