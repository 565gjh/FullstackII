import { useState } from 'react'
import { Link, NavLink } from 'react-router'
import { Navbar, Nav, Container, Button, Badge } from 'react-bootstrap'
import Buscador from './Buscador.jsx'

// Enlaces del menú. NavLink agrega la clase "active" solo cuando la ruta actual coincide.
// "end" en la portada evita que "/" quede marcada como activa en todas las páginas.
const ENLACES = [
  { destino: '/', texto: 'Inicio', end: true },
  { destino: '/catalogo', texto: 'Catálogo' },
  { destino: '/comunidad', texto: 'Comunidad & Blog' },
  { destino: '/eventos', texto: 'Eventos & Mapa' },
]

// ícono de lupa en SVG
function IconoLupa() {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor"
      strokeWidth="2.2" strokeLinecap="round" aria-hidden="true">
      <circle cx="11" cy="11" r="7" />
      <line x1="16.5" y1="16.5" x2="21" y2="21" />
    </svg>
  )
}

// Props: sesionIniciada, cantidad (del carrito), onVerCarrito y buscador (datos del buscador
// que arma el Layout desde la URL; null = sin lupa, o sea, fuera del catálogo).
function Encabezado({ sesionIniciada, cantidad, onVerCarrito, buscador = null }) {
  // solo el encabezado necesita saber si la barra de búsqueda está abierta
  const [busquedaAbierta, setBusquedaAbierta] = useState(false)
  // menú colapsable controlado: así se puede cerrar al tocar un enlace en el teléfono
  const [menuAbierto, setMenuAbierto] = useState(false)
  const cerrarMenu = () => setMenuAbierto(false)

  // la lupa solo sale en el catálogo; la barra queda abierta si hay un filtro activo
  const hayLupa = buscador !== null
  const hayFiltro = hayLupa && (buscador.texto.trim() !== '' || buscador.categoria !== 'Todas')
  const barraVisible = hayLupa && (busquedaAbierta || hayFiltro)

  return (
    // un solo header pegajoso para el menú y la barra de búsqueda
    <header className="encabezado-fijo sticky-top">
      <Navbar className="encabezado" data-bs-theme="dark" expand="lg" expanded={menuAbierto} onToggle={setMenuAbierto}>
        <Container className="contenedor">
          <Navbar.Brand as={Link} to="/" onClick={cerrarMenu}>
            LEVEL-UP <span>GAMER</span>
          </Navbar.Brand>

          {/* lupa y carrito fuera del menú colapsable para que se vean siempre */}
          <div className="acciones-encabezado d-flex gap-2 ms-auto me-2 ms-lg-0 order-lg-last">
            {hayLupa && (
              <Button
                variant="outline-primary"
                size="sm"
                className="boton-lupa"
                aria-label="Buscar productos"
                aria-expanded={barraVisible}
                onClick={() => setBusquedaAbierta((abierta) => !abierta)}
              >
                <IconoLupa />
              </Button>
            )}
            <Button variant="outline-primary" size="sm" onClick={onVerCarrito}>
              🛒 Carrito <Badge bg="primary">{cantidad}</Badge>
            </Button>
          </div>

          <Navbar.Toggle aria-controls="menu-principal" />
          <Navbar.Collapse id="menu-principal">
            <Nav className="me-auto">
              {ENLACES.map(({ destino, texto, end }) => (
                // as={NavLink}: el estilo lo pone Bootstrap y la navegación el router
                <Nav.Link key={destino} as={NavLink} to={destino} end={end} onClick={cerrarMenu}>
                  {texto}
                </Nav.Link>
              ))}
            </Nav>
            <Nav>
              {/* según haya sesión o no */}
              {sesionIniciada ? (
                <Nav.Link as={NavLink} to="/perfil" onClick={cerrarMenu}>
                  Mi Perfil
                </Nav.Link>
              ) : (
                <Nav.Link as={NavLink} to="/login" onClick={cerrarMenu}>
                  Iniciar Sesión
                </Nav.Link>
              )}
            </Nav>
          </Navbar.Collapse>
        </Container>
      </Navbar>

      {/* barra de búsqueda */}
      {barraVisible && (
        <div className="barra-busqueda">
          <Container className="contenedor py-3">
            <Buscador
              texto={buscador.texto}
              onCambiarTexto={buscador.onCambiarTexto}
              categoria={buscador.categoria}
              onCambiarCategoria={buscador.onCambiarCategoria}
              categorias={buscador.categorias}
              className="mb-0"
              autoFocus
            />
          </Container>
        </div>
      )}
    </header>
  )
}

export default Encabezado
