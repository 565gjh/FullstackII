import { Link } from 'react-router'
import { Card, Button, Badge } from 'react-bootstrap'
import { formatearPrecio } from '../utils/formato.js'

// con este stock o menos se avisa "últimas unidades"
const STOCK_BAJO = 5

// Componente de presentación: muestra lo que recibe por props y avisa con onAgregar.
// No sabe nada del carrito ni modifica las props.
function TarjetaProducto({ producto, onAgregar }) {
  const { id, codigo, categoria, nombre, descripcion, precio, imagen, fabricante, distribuidor, stock } =
    producto

  // "stock" ya viene descontado con lo que el cliente tiene en el carrito
  const enCarrito = producto.enCarrito ?? 0
  const sinStock = stock <= 0
  const todoEnCarrito = sinStock && enCarrito > 0 // no queda más porque ya lo lleva todo
  const agotado = sinStock && !todoEnCarrito
  const stockBajo = !sinStock && stock <= STOCK_BAJO

  return (
    <Card className={`tarjeta-producto h-100 ${agotado ? 'tarjeta-sin-stock' : ''}`}>
      <Card.Img
        variant="top"
        src={imagen}
        alt={`Imagen de ${nombre}`}
        className="imagen-producto"
        loading="lazy"
      />
      <Card.Body className="d-flex flex-column">
        <Badge className="etiqueta-producto align-self-start mb-2">
          [{codigo}] {categoria}
        </Badge>
        <Card.Title as="h3">{nombre}</Card.Title>
        <Card.Text className="descripcion">{descripcion}</Card.Text>

        <div className="origen-producto mb-3">
          <div>
            <strong>Fabricante:</strong> {fabricante}
          </div>
          <div>
            <strong>Distribuidor:</strong> {distribuidor}
          </div>
        </div>

        {/* estado del stock */}
        <p className={`estado-stock ${agotado ? 'agotado' : sinStock || stockBajo ? 'bajo' : 'disponible'}`}>
          {agotado
            ? 'No hay stock disponible'
            : todoEnCarrito
              ? 'Ya tienes todas las unidades en tu carrito'
              : stockBajo
                ? `¡Últimas ${stock} unidades!`
                : `${stock} unidades disponibles`}
        </p>
        {enCarrito > 0 && !todoEnCarrito && (
          <p className="en-carrito">🛒 Tienes {enCarrito} en tu carrito</p>
        )}

        <Card.Text className="precio mt-auto">{formatearPrecio(precio)}</Card.Text>
        {/* arrow function para que no se ejecute al renderizar */}
        <Button variant="primary" disabled={sinStock} onClick={() => onAgregar(producto)}>
          {todoEnCarrito ? 'Máximo en tu carrito' : agotado ? 'Sin stock' : 'Añadir al Carrito'}
        </Button>
        {/* cada tarjeta lleva a su propia dirección: /producto/3 */}
        <Button as={Link} to={`/producto/${id}`} variant="outline-primary" className="mt-2">
          Ver detalle
        </Button>
      </Card.Body>
    </Card>
  )
}

export default TarjetaProducto
