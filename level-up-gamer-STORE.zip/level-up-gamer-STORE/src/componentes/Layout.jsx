import { useEffect } from 'react'
import { Outlet, useLocation } from 'react-router'

import Encabezado from './Encabezado.jsx'
import PiePagina from './PiePagina.jsx'
import BotonSoporte from './BotonSoporte.jsx'
import { useFiltroCatalogo, CATEGORIAS } from '../hooks/useFiltroCatalogo.js'

// Plantilla del sitio: el encabezado y el pie se escriben UNA sola vez.
// <Outlet /> es el hueco donde el router dibuja la página que corresponde a la URL.
// "children" son los paneles que flotan sobre la página (carrito y avisos), que arma App.
function Layout({ sesionIniciada, cantidad, onVerCarrito, nombreUsuario, children }) {
  const { pathname } = useLocation()
  const filtro = useFiltroCatalogo()

  // en login y registro no se muestran ni el header ni el footer
  const esPaginaAuth = pathname === '/login' || pathname === '/registro'
  // la lupa solo existe en el catálogo
  const buscador =
    pathname === '/catalogo'
      ? {
          texto: filtro.texto,
          onCambiarTexto: filtro.cambiarTexto,
          categoria: filtro.categoria,
          onCambiarCategoria: filtro.cambiarCategoria,
          categorias: CATEGORIAS,
        }
      : null

  // al cambiar de página se vuelve arriba
  useEffect(() => {
    window.scrollTo(0, 0)
  }, [pathname])

  return (
    <div className="d-flex flex-column min-vh-100">
      {!esPaginaAuth && (
        <Encabezado
          sesionIniciada={sesionIniciada}
          cantidad={cantidad}
          onVerCarrito={onVerCarrito}
          buscador={buscador}
        />
      )}

      <main className="flex-grow-1">
        <Outlet />
      </main>

      {children}
      <BotonSoporte nombreUsuario={nombreUsuario} />
      {!esPaginaAuth && <PiePagina />}
    </div>
  )
}

export default Layout
