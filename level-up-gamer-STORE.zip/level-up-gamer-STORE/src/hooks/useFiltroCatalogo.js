import { useSearchParams } from 'react-router'
import productos from '../data/productos.js'

// categorías sin repetir, para el select del buscador
export const CATEGORIAS = [...new Set(productos.map((p) => p.categoria))]

// El filtro del catálogo vive en la URL: /catalogo?buscar=catan&categoria=Mouse
// Así se puede copiar el enlace, recargar con F5 y volver atrás paso a paso.
// useSearchParams se usa casi como useState, pero guarda el valor en la barra de direcciones.
export function useFiltroCatalogo() {
  const [parametros, setParametros] = useSearchParams()
  const texto = parametros.get('buscar') ?? ''
  const categoria = parametros.get('categoria') ?? 'Todas'

  // se copia el objeto (no se modifica el original); sin valor se borra la clave
  function actualizar(clave, valor) {
    const copia = new URLSearchParams(parametros)
    if (valor && valor !== 'Todas') copia.set(clave, valor)
    else copia.delete(clave)
    setParametros(copia)
  }

  return {
    texto,
    categoria,
    cambiarTexto: (valor) => actualizar('buscar', valor),
    cambiarCategoria: (valor) => actualizar('categoria', valor),
    limpiar: () => setParametros(new URLSearchParams()),
  }
}
