# Level-Up Gamer · versión React

Segunda versión de la tienda **Level-Up Gamer**, migrada de HTML + CSS + JavaScript a
**React + Vite + React Bootstrap + React Router**, siguiendo las guías «React desde cero» y
«React Router con diseño responsivo» (DSY1104).

## Cómo ejecutarlo

Necesitas Node.js LTS (22 o superior; mínimo 20.19).

```bash
npm install        # una sola vez: descarga las dependencias en node_modules
npm run dev        # servidor de desarrollo en http://localhost:5173
npm run build      # versión de producción en dist/
npm run preview    # prueba la versión de producción
npm run lint       # revisa el código con Oxlint
npm test               # pruebas (Vitest + Testing Library, corren en jsdom: no necesitan Chrome)
npm run test:watch     # las repite al guardar
npm run test:coverage  # lo mismo + informe de cobertura en coverage/index.html
```

`node_modules` y `dist` no se entregan ni se suben a Git.

## Estructura

```
level-up-gamer-react/
├── public/logo.png            favicon
├── index.html                 la única página HTML (con <div id="root">)
└── src/
    ├── main.jsx               punto de entrada: <BrowserRouter> envuelve <App /> y carga Bootstrap
    ├── App.jsx                estado compartido (carrito, sesión, usuario, avisos) y mapa de rutas
    ├── index.css              estilos propios (paleta y tipografías de la v1)
    ├── assets/                imágenes de productos, logo y fondo
    ├── data/                  productos.js · eventos.js · comunidad.js · contacto.js
    ├── utils/                 formato.js · niveles.js · almacenamiento.js · eventos.js · recomendaciones.js
    ├── hooks/                 useFiltroCatalogo (el filtro del catálogo vive en la URL)
    ├── componentes/           Layout · Encabezado · Portada · PiePagina · Buscador · Catalogo ·
    │                          TarjetaProducto · Carrito · TarjetaEvento · Aviso ·
    │                          BotonSoporte · FondoAuth · Recomendaciones
    ├── paginas/               Inicio · Productos · DetalleProducto · Comunidad · Eventos ·
    │                          Login · Registro · Perfil · NoEncontrada
    └── tests/                 configuracion.js (setup de Vitest) + pruebas (*.spec.js / *.spec.jsx)

vite.config.js                 también configura Vitest (bloque test: jsdom, globals, setupFiles)
docs/                          ERS (propuesta personalizada) · cobertura de testing · guía de presentación
```

## Qué se usa de cada clase de la guía

| Clase | Contenido | Dónde está |
| --- | --- | --- |
| 1 | Proyecto con Vite, `main.jsx`, `App.jsx` | `src/main.jsx`, `src/App.jsx` |
| 2 | JSX, componentes, React Bootstrap | `componentes/Encabezado`, `Portada`, `PiePagina` |
| 3 | Props, `map` con `key`, renderizado condicional | `Catalogo`, `TarjetaProducto`, `data/productos.js` |
| 4 | `useState`, eventos, estado levantado a `App` | `App.jsx`, `Carrito` (panel lateral) |
| 5 | Formularios controlados, `useEffect`, `localStorage` | `Buscador`, `Login`, `Registro`, `Comunidad`, `App.jsx` |
| Router | `BrowserRouter`, `Routes`, `Outlet`, `NavLink`, `useParams`, `useNavigate`, `useSearchParams`, 404 | `main.jsx`, `App.jsx`, `Layout`, `Encabezado`, `DetalleProducto`, `hooks/useFiltroCatalogo.js` |

## Rutas (React Router)

El mapa está en `App.jsx`. Todas las rutas cuelgan de un `Layout` (`componentes/Layout.jsx`) que
dibuja el encabezado y el pie una sola vez y deja un `<Outlet />` para cada página.

| Ruta | Página | Detalle |
| --- | --- | --- |
| `/` | `Inicio` | ruta `index` del Layout |
| `/catalogo` | `Productos` | filtro en la URL: `?buscar=catan&categoria=Mouse` (`useSearchParams`) |
| `/producto/:id` | `DetalleProducto` | `useParams` (el id llega como texto → `Number(id)`); un id inexistente muestra un mensaje |
| `/comunidad`, `/eventos` | `Comunidad`, `Eventos` | |
| `/login`, `/registro` | `Login`, `Registro` | sin header ni footer |
| `/perfil` | `Perfil` | |
| `*` | `NoEncontrada` | 404 con la dirección que se intentó abrir (`useLocation`) |

- El menú usa `Nav.Link as={NavLink}` (Bootstrap pone el estilo, el router la navegación) y se
  cierra al tocar un enlace en el teléfono. No queda ningún `<a href>` interno.
- Se navega desde el código con `useNavigate` (tras pagar, registrarse o iniciar sesión; el botón
  «Volver» del detalle usa `navigate(-1)`).
- El catálogo es una grilla responsiva: `<Row xs={1} sm={2} lg={3}>` con tarjetas de igual altura.

### Publicar (el 404 al recargar)

Con React Router, recargar en `/producto/3` hace que el servidor busque un archivo que no existe.
Hay que devolver siempre `index.html`:

- Netlify: ya viene `public/_redirects` (`/*  /index.html  200`).
- Nginx: `location / { try_files $uri $uri/ /index.html; }`.

## Login y registro

Estas dos páginas se muestran sin header ni footer (`esPaginaAuth` en `Layout.jsx`) y con el fondo a
pantalla completa. Como no hay menú, `FondoAuth` trae un enlace «Volver a la tienda».

## De la v1 a React

| Versión 1 (HTML + JS) | Versión React |
| --- | --- |
| `index.html` | `paginas/Inicio.jsx` (`/`) |
| `productos.html` + `catalogo.js` | `paginas/Productos.jsx` + `Buscador`, `Catalogo`, `TarjetaProducto` |
| `carrito.html` + `carrito.js` | `componentes/Carrito.jsx` (panel lateral) + funciones en `App.jsx` |
| `comunidad.html` + `comunidad.js` | `paginas/Comunidad.jsx` |
| `eventos.html` + `eventos.js` | `paginas/Eventos.jsx` + `TarjetaEvento` |
| `login.html` + `login.js` | `paginas/Login.jsx` |
| `registro.html` + `registro.js` | `paginas/Registro.jsx` |
| `perfil.html` + `perfil.js` | `paginas/Perfil.jsx` |
| `main.js` (contador del carrito, sesión en el menú, WhatsApp) | `Encabezado`, `App.jsx`, `BotonSoporte` |
| `alert(...)` | mensajes emergentes (`componentes/Aviso.jsx`) |

La navegación usa React Router (`/catalogo`, `/producto/3`, `/perfil`…): cada pantalla tiene su
propia dirección y los botones Atrás y Adelante del navegador funcionan.

## Datos guardados en el navegador (localStorage)

| Clave | Contenido |
| --- | --- |
| `carrito-levelup` | `[{ id, cantidad }]`; nombre, precio e imagen se toman del catálogo |
| `usuarioPerfil` | usuario registrado (nombre, correo, contraseña, puntos y rango) |
| `sesionIniciada` | `true` o `false` |
| `consejosComunidad` | consejos publicados en el foro |
| `stock-vendido` | `{ id: unidades }` ya vendidas; se restan del stock de `data/productos.js` |

El descuento canjeado con puntos se guarda dentro de `usuarioPerfil` (campo `descuento`).
Para reiniciar el stock de la demo basta borrar la clave `stock-vendido` en el navegador.

> La contraseña se guarda en texto plano solo porque todavía no hay backend. Cuando exista el
> servidor (Spring Boot), la autenticación debe hacerse allí y nunca guardarse así.
