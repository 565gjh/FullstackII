# Documento de cobertura de testing · Level-Up Gamer (React)

## 1. Herramientas

| Herramienta | Para qué se usa |
| --- | --- |
| Vitest | ejecutar las pruebas (`describe`, `it`, `expect`) y los mocks (`vi.fn`, `vi.spyOn`) |
| jsdom | navegador simulado donde corren las pruebas (no necesita Chrome) |
| React Testing Library | dibujar los componentes y consultar el DOM (`render`, `screen`, `fireEvent`) |
| `@testing-library/user-event` | simular a una persona: escribir letra por letra, hacer clic |
| `@testing-library/jest-dom` | matchers legibles: `toBeInTheDocument`, `toBeDisabled`, `toHaveTextContent` |
| `MemoryRouter` (React Router) | probar rutas, enlaces y hooks del router sin una barra de direcciones real |
| `@vitest/coverage-v8` | medir la cobertura de código |

La configuración está en el bloque `test` de `vite.config.js` y en `src/tests/configuracion.js`
(se carga antes de cada archivo de pruebas: matchers de jest-dom, limpieza y mocks).

## 2. Cómo ejecutar

```bash
npm install
npm test                 # corre las pruebas una vez
npm run test:coverage    # además genera el informe en coverage/index.html
```

No necesita navegador: Vitest usa jsdom.

## 3. Qué se prueba

| Archivo | Qué cubre | Pruebas |
| --- | --- | --- |
| `utilidades.spec.js` | `formato`, `niveles`, `almacenamiento`, `eventos`, `recomendaciones`, `precios` (total con descuento) | 10 |
| `componentes.spec.jsx` | `TarjetaProducto` (stock y enlace «Ver detalle»), `Catalogo`, `Carrito` (descuento y enlace al catálogo), `Encabezado` (enlaces, `NavLink` activo, lupa), `PiePagina`, `BotonSoporte` | 19 |
| `paginas.spec.jsx` | `Login`, `Registro`, `Perfil` (canje, descuento y enlaces sin sesión), `Comunidad` (incluye XSS), `TarjetaEvento` | 11 |
| `app.spec.jsx` | la app completa: carrito (y que sobrevive a una recarga), stock que baja al agregar, pago sin sesión → `/login`, login/registro sin header ni footer, flujo registro → login → perfil, check-in, canje de puntos → descuento → stock vendido | 10 |
| `usuario.spec.jsx` | interacciones con `userEvent`: escribir en el buscador, agregar y sumar en el carrito, tarjeta → detalle → «Volver», login con error | 5 |
| `rutas.spec.jsx` | ruta 404, `Layout` (header y footer una sola vez), `NavLink` activo, `/producto/:id` (`useParams`, id inexistente, «Volver» con `navigate(-1)`), filtro del catálogo en la URL (`useSearchParams`) | 25 |

Total: **80 pruebas**. Cada una revisa un comportamiento concreto (no solo que el componente
«se dibuje»): límites de rangos, validaciones de formularios, tope de stock, bloqueo de eventos
finalizados, texto con HTML mostrado como texto, etc.

## 4. Conceptos de testeo aplicados

- **Entorno de pruebas:** Vitest con jsdom; `globals: true` deja `describe`, `it`, `expect` y `vi` disponibles sin importarlos.
- **Aislamiento:** `configuracion.js` limpia el DOM, el `localStorage` y los mocks después de cada prueba; la dirección no se comparte porque cada prueba crea su propio `MemoryRouter`.
- **Router en las pruebas:** `ayudas-router.jsx` trae `renderConRuta` (un componente en una ruta dada), `renderApp` (la app completa con su historia inicial) y `UbicacionActual` (muestra la URL para comprobarla con `expect`).
- **Mocks:**
  - `vi.fn()` para comprobar que un componente llama a la función que recibe por props.
  - `vi.spyOn(window, 'open')` para no abrir WhatsApp de verdad.
  - `vi.spyOn(Storage.prototype, 'setItem')` para simular un `localStorage` lleno.
- **Estructura:** preparar los datos, ejecutar la acción y comprobar el resultado.
- **Casos límite:** 199 y 200 puntos, edad de 17 años, producto sin stock, evento que termina hoy, JSON dañado.
- **Datos de prueba propios** (`datos-prueba.js`), para no depender del catálogo real.

## 5. Resultados

**Pendiente:** estas cifras son de la versión anterior (42 pruebas con Jasmine + Karma, navegación con `#`). Vuelve a correr
`npm run test:coverage` y reemplaza la tabla con tus resultados.

Ejecución anterior con Chrome Headless 131:

| Métrica | Resultado |
| --- | --- |
| Pruebas ejecutadas / exitosas | 42 / 42 |
| Statements | 87,64 % (298 de 340) |
| Branches | 81,86 % (176 de 215) |
| Functions | 85,07 % (114 de 134) |
| Lines | 89,47 % (272 de 304) |

Se corrió varias veces seguidas con resultado estable. Al ejecutar `npm run test:coverage` en tu
equipo debería salir lo mismo; pega aquí una captura de la consola de Vitest y del informe
`coverage/index.html`.

## 6. Análisis de la cobertura

- **Cubiertos al 100 % de líneas:** `utils/`, `data/`, `Login`, `Registro`, `Encabezado`, `TarjetaProducto`, `PiePagina`, `Aviso`, `BotonSoporte`, `Catalogo`, `FondoAuth` y `Productos`.
- **Cubiertos parcialmente:**
  - `App.jsx` (81 % de líneas): faltan las funciones de cambiar cantidades, quitar productos, vaciar el carrito y cerrar sesión (los botones del carrito sí se prueban en `componentes.spec.jsx`, pero ahí `App` no participa).
  - `Buscador.jsx` (60 %): se prueba escribir en el texto, pero no el cambio de categoría.
  - `Carrito`, `Perfil` y `Comunidad` (83–91 %): faltan detalles menores, como eliminar un consejo del foro.
- **No se prueba:** `main.jsx` (solo monta la app), los estilos CSS (el aspecto se revisó a mano
  en el navegador) y el video de YouTube de Eventos.
- **Siguiente paso:** agregar pruebas para los puntos parcialmente cubiertos y, más adelante,
  pruebas de integración contra el backend.
