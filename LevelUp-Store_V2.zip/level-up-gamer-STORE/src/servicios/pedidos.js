import api from './api.js'

// POST /pedidos — envía solo qué producto y cuántas unidades.
// El precio no viaja: el servidor lo busca en su base de datos y calcula el
// total. Nunca se confía en un precio que viene del navegador.
export async function enviarPedido(carrito) {
  const solicitud = {
    lineas: carrito.map((linea) => ({ productoId: linea.id, cantidad: linea.cantidad })),
  }
  const respuesta = await api.post('/pedidos', solicitud)
  return respuesta.data // { id, fecha, unidades, total, detalles }
}

// GET /pedidos — historial de compras registradas en la API.
export async function listarPedidos() {
  const respuesta = await api.get('/pedidos')
  return respuesta.data
}
