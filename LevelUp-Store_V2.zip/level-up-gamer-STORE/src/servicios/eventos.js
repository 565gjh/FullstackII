import api from './api.js'

// GET /eventos — el radar de eventos ahora vive en la API.
export async function listarEventos() {
  const respuesta = await api.get('/eventos')
  return respuesta.data // [{ id, etiqueta, lugar, descripcion, fechaFin, puntos }]
}
