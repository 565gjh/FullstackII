// La API guarda en "imagen" el NOMBRE del archivo (por ejemplo "catannew.png"),
// porque las fotos del catálogo viven en src/assets y Vite las publica con un
// nombre distinto en cada build (catannew-Ab12Cd.png). Aquí se traduce ese
// nombre a la dirección real. Si la API manda una URL completa, se usa tal cual.

// import.meta.glob le pide a Vite todas las imágenes de src/assets: { './ruta': 'url' }
const archivos = import.meta.glob('../assets/*.{png,jpg,jpeg,webp,avif,gif,svg}', {
  eager: true,
  import: 'default',
})

const porNombre = Object.fromEntries(
  Object.entries(archivos).map(([ruta, url]) => [ruta.split('/').pop(), url]),
)

// nombres disponibles, para sugerirlos en el formulario del panel admin
export const IMAGENES_DISPONIBLES = Object.keys(porNombre).sort()

// imagen de respaldo (public/logo.png) para productos sin foto
const IMAGEN_RESPALDO = '/logo.png'

export function resolverImagen(imagen) {
  if (!imagen) return IMAGEN_RESPALDO
  if (/^(https?:|data:|blob:|\/)/.test(imagen)) return imagen
  return porNombre[imagen] ?? IMAGEN_RESPALDO
}
