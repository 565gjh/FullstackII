import { useState, useEffect, useCallback } from 'react'
import { Routes, Route, useNavigate } from 'react-router'

import Layout from './componentes/Layout.jsx'
import Carrito from './componentes/Carrito.jsx'
import Aviso from './componentes/Aviso.jsx'

import Inicio from './paginas/Inicio.jsx'
import Productos from './paginas/Productos.jsx'
import DetalleProducto from './paginas/DetalleProducto.jsx'
import Comunidad from './paginas/Comunidad.jsx'
import Eventos from './paginas/Eventos.jsx'
import Login from './paginas/Login.jsx'
import Registro from './paginas/Registro.jsx'
import Perfil from './paginas/Perfil.jsx'
import AdminProductos from './paginas/AdminProductos.jsx'
import FormularioProducto from './paginas/FormularioProducto.jsx'
import NoEncontrada from './paginas/NoEncontrada.jsx'

// El catálogo lo entrega la API (levelup-api). Los datos locales solo se muestran
// mientras llega la primera respuesta (o si la API no está disponible).
import productosLocales from './data/productos.js'
import { listarProductos } from './servicios/productos.js'
import { leerGuardado, guardar } from './utils/almacenamiento.js'
import { calcularNivel } from './utils/niveles.js'
import { calcularTotales } from './utils/precios.js'
import { formatearPrecio } from './utils/formato.js'

// claves de localStorage
const CLAVE_CARRITO = 'carrito-levelup'
const CLAVE_USUARIO = 'usuarioPerfil'
const CLAVE_SESION = 'sesionIniciada'

// Del carrito solo se guarda { id, cantidad }; nombre, precio e imagen salen del catálogo.
function cargarCarritoGuardado() {
  const guardado = leerGuardado(CLAVE_CARRITO, [])
  return Array.isArray(guardado) ? guardado : []
}

// Componente principal. Acá vive el estado que comparten varias rutas (carrito, sesión,
// usuario) y el mapa de rutas. Los hijos reciben datos por props y avisan con funciones.
// El filtro del catálogo NO está acá: vive en la URL (useSearchParams).
function App() {
  const navegar = useNavigate()

  // estado
  // useState con función: localStorage se lee solo en el primer render
  const [carrito, setCarrito] = useState(cargarCarritoGuardado)
  const [mostrarCarrito, setMostrarCarrito] = useState(false)
  const [usuario, setUsuario] = useState(() => leerGuardado(CLAVE_USUARIO, null))
  const [sesionIniciada, setSesionIniciada] = useState(() => leerGuardado(CLAVE_SESION, false))
  const [aviso, setAviso] = useState(null)
  // Productos conocidos por la app. Parte con los datos locales y se actualiza con lo que
  // entrega la API cada vez que el catálogo o el detalle la consultan.
  const [productos, setProductos] = useState(productosLocales)

  // Recibe los productos que llegaron de la API. Si es el catálogo completo, la API manda:
  // reemplaza la lista. Si es una parte (una categoría o un detalle), actualiza por id.
  // useCallback: la función no cambia entre renders, así no dispara efectos de más.
  const sincronizarProductos = useCallback((lista, completo = false) => {
    setProductos((actuales) => {
      if (completo) return lista
      const porId = new Map(actuales.map((p) => [p.id, p]))
      lista.forEach((p) => porId.set(p.id, p))
      return [...porId.values()].sort((a, b) => a.id - b.id)
    })
  }, [])

  // Vuelve a pedir el catálogo completo (al arrancar, tras una compra o un cambio en /admin).
  // Si la API no responde se conserva lo que ya había.
  const refrescarCatalogo = useCallback(async () => {
    try {
      sincronizarProductos(await listarProductos(), true)
    } catch {
      // el catálogo y el detalle muestran su propio error con Reintentar
    }
  }, [sincronizarProductos])

  // al arrancar: el catálogo real viene de la API
  useEffect(() => {
    listarProductos()
      .then((lista) => sincronizarProductos(lista, true))
      .catch(() => {})
  }, [sincronizarProductos])

  // efectos: se guarda en localStorage cuando cambia el dato
  useEffect(() => {
    guardar(CLAVE_CARRITO, carrito)
  }, [carrito])

  useEffect(() => {
    // sin usuario registrado no hay nada que guardar
    if (usuario !== null) guardar(CLAVE_USUARIO, usuario)
  }, [usuario])

  useEffect(() => {
    guardar(CLAVE_SESION, sesionIniciada)
  }, [sesionIniciada])

  // datos calculados (no se guardan)
  // V2: el stock lo descuenta el servidor al confirmar cada pedido.
  const stockReal = (producto) => Math.max(0, producto.stock)
  // categorías para la lupa y el panel admin, según lo que entregó la API
  const categorias = [...new Set(productos.map((p) => p.categoria))]

  // Junta { id, cantidad } con los datos del producto. Si el stock bajó desde la última
  // visita se ajusta la cantidad, y los agotados salen del carrito.
  const itemsCarrito = carrito
    .map(({ id, cantidad }) => {
      const producto = productos.find((p) => p.id === id)
      if (!producto || stockReal(producto) <= 0) return null
      return { ...producto, stock: stockReal(producto), cantidad: Math.min(cantidad, stockReal(producto)) }
    })
    .filter(Boolean)
  const cantidadTotal = itemsCarrito.reduce((suma, item) => suma + item.cantidad, 0)

  // Catálogo que ven las páginas: a cada stock se le restan las unidades que ya están en el carrito.
  const catalogo = productos.map((producto) => {
    const enCarrito = itemsCarrito.find((item) => item.id === producto.id)?.cantidad ?? 0
    return { ...producto, stock: stockReal(producto) - enCarrito, enCarrito }
  })

  // hay sesión si el usuario existe y quedó marcado como iniciado
  const haySesion = sesionIniciada === true && usuario !== null
  // descuento canjeado con puntos (solo se usa con sesión iniciada)
  const descuentoDisponible = haySesion ? (usuario.descuento ?? 0) : 0
  const totales = calcularTotales(itemsCarrito, descuentoDisponible)

  // el título de la pestaña muestra cuántos productos hay en el carrito
  useEffect(() => {
    document.title = `(${cantidadTotal}) Level-Up Gamer`
  }, [cantidadTotal])

  // funciones que modifican el estado
  // navegar desde el código (después de un evento): useNavigate en vez de tocar el #
  function irA(destino) {
    navegar(destino)
  }

  function mostrarAviso(texto, variante = 'success') {
    setAviso({ id: Date.now(), texto, variante })
  }

  function agregarAlCarrito(producto) {
    // no se puede pasar del stock
    // (el producto de la tarjeta ya trae el stock descontado, por eso se busca el original)
    const original = productos.find((p) => p.id === producto.id) ?? producto
    const unidadesEnCarrito = itemsCarrito.find((item) => item.id === producto.id)?.cantidad ?? 0
    const disponibles = stockReal(original)
    if (unidadesEnCarrito >= disponibles) {
      mostrarAviso(`Solo hay ${disponibles} unidades de "${producto.nombre}" disponibles.`, 'warning')
      return
    }

    setCarrito((carritoActual) => {
      const existe = carritoActual.find((item) => item.id === producto.id)
      if (existe) {
        // no se modifica el arreglo, se crea uno nuevo
        return carritoActual.map((item) =>
          item.id === producto.id ? { ...item, cantidad: item.cantidad + 1 } : item,
        )
      }
      return [...carritoActual, { id: producto.id, cantidad: 1 }]
    })
    mostrarAviso(`"${producto.nombre}" se agregó al carrito.`)
  }

  // Suma o resta unidades; si la cantidad llega a 0 el producto sale del carrito.
  function cambiarCantidad(id, cambio) {
    // al sumar también se respeta el stock
    if (cambio > 0) {
      const producto = productos.find((p) => p.id === id)
      const unidadesEnCarrito = itemsCarrito.find((item) => item.id === id)?.cantidad ?? 0
      if (!producto || unidadesEnCarrito + cambio > stockReal(producto)) {
        mostrarAviso('Ya tienes todas las unidades disponibles de este producto.', 'warning')
        return
      }
    }

    setCarrito((carritoActual) =>
      carritoActual
        .map((item) => (item.id === id ? { ...item, cantidad: item.cantidad + cambio } : item))
        .filter((item) => item.cantidad > 0),
    )
  }

  function quitarDelCarrito(id) {
    setCarrito((carritoActual) => carritoActual.filter((item) => item.id !== id))
  }

  // Comprar pide sesión. El pedido lo envía el Carrito (POST /api/pedidos).
  function requerirSesion() {
    setMostrarCarrito(false)
    mostrarAviso('Debes iniciar sesión para procesar tu compra.', 'warning')
    irA('/login')
  }

  // La API confirmó el pedido: ya descontó el stock y calculó el total con sus precios.
  // Aquí se gasta el descuento LevelUp aplicado, se vacía el carrito y se refresca el stock.
  function confirmarPedido(pedido) {
    setMostrarCarrito(false)
    if (totales.descuentoAplicado > 0) {
      setUsuario((actual) => ({ ...actual, descuento: (actual.descuento ?? 0) - totales.descuentoAplicado }))
    }
    const pagado = Math.max(0, pedido.total - totales.descuentoAplicado)
    mostrarAviso(
      `¡Compra procesada con éxito, ${usuario.nombre}! Pedido N° ${pedido.id} · Total pagado: ${formatearPrecio(pagado)}.`,
    )
    setCarrito([])
    refrescarCatalogo()
    irA('/perfil')
  }

  function registrarUsuario(nuevoUsuario) {
    setUsuario(nuevoUsuario)
    setSesionIniciada(false)
    mostrarAviso('¡Cuenta creada con éxito! Ahora inicia sesión.')
    irA('/login')
  }

  function iniciarSesion() {
    setSesionIniciada(true)
    mostrarAviso(`¡Inicio de sesión exitoso! Bienvenido, ${usuario.nombre}.`)
    irA('/perfil')
  }

  function cerrarSesion() {
    setSesionIniciada(false)
    mostrarAviso('Cerraste sesión.', 'info')
  }

  function realizarCheckIn(lugar, puntos) {
    if (!haySesion) {
      mostrarAviso('Debes iniciar sesión para acumular puntos por tus check-ins.', 'warning')
      irA('/login')
      return
    }
    setUsuario((actual) => {
      const total = actual.puntos + puntos
      return { ...actual, puntos: total, nivel: calcularNivel(total) }
    })
    mostrarAviso(`¡Check-in realizado con éxito en "${lugar}"! Ganaste +${puntos} Puntos LevelUp.`)
  }

  // Gasta puntos. Si el premio es un descuento, queda guardado en el usuario y se aplica en el carrito.
  function canjearPremio(costo, nombrePremio, descuento = 0) {
    if (!haySesion) return
    if (usuario.puntos < costo) {
      mostrarAviso(`Te faltan ${costo - usuario.puntos} puntos para canjear "${nombrePremio}".`, 'danger')
      return
    }
    setUsuario((actual) => {
      const total = actual.puntos - costo
      return {
        ...actual,
        puntos: total,
        nivel: calcularNivel(total),
        descuento: (actual.descuento ?? 0) + descuento,
      }
    })
    if (descuento > 0) {
      const acumulado = (usuario.descuento ?? 0) + descuento
      mostrarAviso(`¡Canje exitoso! Tienes ${formatearPrecio(acumulado)} de descuento para tu próxima compra.`)
    } else {
      mostrarAviso(`¡Canje exitoso! Obtuviste: ${nombrePremio}.`)
    }
  }

  return (
    <Routes>
      {/* ruta padre: dibuja el marco del sitio; las rutas hijas entran por el <Outlet /> del Layout */}
      <Route
        path="/"
        element={
          <Layout
            sesionIniciada={haySesion}
            cantidad={cantidadTotal}
            onVerCarrito={() => setMostrarCarrito(true)}
            nombreUsuario={usuario ? usuario.nombre : 'Cliente'}
            categorias={categorias}
          >
            <Carrito
              mostrar={mostrarCarrito}
              onCerrar={() => setMostrarCarrito(false)}
              items={itemsCarrito}
              descuentoDisponible={descuentoDisponible}
              onCambiarCantidad={cambiarCantidad}
              onQuitar={quitarDelCarrito}
              onVaciar={() => setCarrito([])}
              sesionIniciada={haySesion}
              onRequiereSesion={requerirSesion}
              onPedidoConfirmado={confirmarPedido}
              onStockDesactualizado={refrescarCatalogo}
            />
            <Aviso aviso={aviso} onCerrar={() => setAviso(null)} />
          </Layout>
        }
      >
        {/* index: lo que se ve cuando la URL es exactamente "/" */}
        <Route
          index
          element={<Inicio catalogo={catalogo} itemsCarrito={itemsCarrito} onAgregar={agregarAlCarrito} />}
        />
        <Route path="catalogo" element={
            <Productos catalogo={catalogo} onAgregar={agregarAlCarrito} onSincronizar={sincronizarProductos} />
          } />
        {/* ruta con parámetro: una sola ruta responde a /producto/1, /producto/2, … */}
        <Route
          path="producto/:id"
          element={
            <DetalleProducto catalogo={catalogo} onAgregar={agregarAlCarrito} onSincronizar={sincronizarProductos} />
          }
        />
        {/* panel de administración (en la V3 queda solo para el rol ADMIN) */}
        <Route path="admin" element={<AdminProductos onCatalogoCambiado={refrescarCatalogo} />} />
        <Route
          path="admin/nuevo"
          element={<FormularioProducto categorias={categorias} onCatalogoCambiado={refrescarCatalogo} />}
        />
        <Route
          path="admin/editar/:id"
          element={<FormularioProducto categorias={categorias} onCatalogoCambiado={refrescarCatalogo} />}
        />
        <Route path="comunidad" element={<Comunidad nombreUsuario={haySesion ? usuario.nombre : ''} />} />
        <Route path="eventos" element={<Eventos onCheckIn={realizarCheckIn} />} />
        <Route path="login" element={<Login usuarioGuardado={usuario} onIniciarSesion={iniciarSesion} />} />
        <Route path="registro" element={<Registro onRegistrar={registrarUsuario} />} />
        <Route
          path="perfil"
          element={
            <Perfil
              usuario={usuario}
              sesionIniciada={haySesion}
              onCerrarSesion={cerrarSesion}
              onCanjear={canjearPremio}
            />
          }
        />
        {/* comodín: cualquier dirección que no coincidió antes */}
        <Route path="*" element={<NoEncontrada />} />
      </Route>
    </Routes>
  )
}

export default App
