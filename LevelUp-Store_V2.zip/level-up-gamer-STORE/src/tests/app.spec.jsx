// Prueba de integración: la aplicación completa con su mapa de rutas.
// renderApp la dibuja dentro de un MemoryRouter y deja visible la dirección actual
// (data-testid="ubicacion") para comprobar a dónde navegó la app.
import { screen, fireEvent, within, waitFor } from '@testing-library/react'
import { renderApp, esperarCarga } from './ayudas-router.jsx'
import { usuarioAna } from './datos-prueba.js'

const escribir = (etiqueta, valor) =>
  fireEvent.change(screen.getByLabelText(etiqueta), { target: { value: valor } })
const ubicacion = () => screen.getByTestId('ubicacion').textContent

describe('App (integración)', () => {
  it('al agregar un producto actualiza el título y guarda el carrito', async () => {
    renderApp('/catalogo')
    await esperarCarga()
    fireEvent.click(screen.getAllByRole('button', { name: 'Añadir al Carrito' })[0])
    expect(document.title).toBe('(1) Level-Up Gamer')
    expect(screen.getByText(/se agregó al carrito/)).toBeTruthy()
    expect(JSON.parse(localStorage.getItem('carrito-levelup'))).toEqual([{ id: 1, cantidad: 1 }])
  })

  it('no deja agregar más unidades que el stock (la PS5 tiene 3)', async () => {
    renderApp('/catalogo')
    await esperarCarga()
    // el cuarto botón "Añadir" es el de la PS5 (el producto agotado no tiene ese botón)
    const botonPS5 = () => screen.getAllByRole('button', { name: 'Añadir al Carrito' })[3]
    for (let i = 0; i < 3; i++) fireEvent.click(botonPS5())
    expect(JSON.parse(localStorage.getItem('carrito-levelup'))).toEqual([{ id: 5, cantidad: 3 }])
    // ya lleva las 3 unidades: el botón queda bloqueado
    expect(screen.getByRole('button', { name: 'Máximo en tu carrito' }).disabled).toBe(true)
    expect(screen.getByText('Ya tienes todas las unidades en tu carrito')).toBeTruthy()
  })

  it('al agregar un producto el catálogo muestra una unidad menos', async () => {
    renderApp('/catalogo')
    await esperarCarga()
    expect(screen.getByText('12 unidades disponibles')).toBeTruthy() // Catan
    fireEvent.click(screen.getAllByRole('button', { name: 'Añadir al Carrito' })[0])
    expect(screen.getByText('11 unidades disponibles')).toBeTruthy()
    expect(screen.getByText(/Tienes 1 en tu carrito/)).toBeTruthy()
  })

  it('el carrito sobrevive a una recarga: se lee de localStorage al arrancar', async () => {
    localStorage.setItem('carrito-levelup', JSON.stringify([{ id: 1, cantidad: 2 }]))
    renderApp('/catalogo')
    await esperarCarga()
    expect(document.title).toBe('(2) Level-Up Gamer')
    expect(screen.getByText('10 unidades disponibles')).toBeTruthy() // 12 − 2 en el carrito
  })

  it('canjear puntos da un descuento que se aplica en el carrito; al pagar se envía el pedido a la API', async () => {
    localStorage.setItem('usuarioPerfil', JSON.stringify({ ...usuarioAna, puntos: 400 }))
    localStorage.setItem('sesionIniciada', 'true')
    const { container } = renderApp('/perfil')
    fireEvent.click(screen.getByRole('button', { name: /5\.000 dcto/ }))
    expect(screen.getByText(/Descuento disponible/)).toBeTruthy()

    // el enlace del header lleva al catálogo (sin recargar la página)
    fireEvent.click(within(container.querySelector('header')).getByText('Catálogo'))
    await screen.findByText('Inventario Disponible')
    await esperarCarga()
    expect(ubicacion()).toBe('/catalogo')
    fireEvent.click(screen.getAllByRole('button', { name: 'Añadir al Carrito' })[0]) // Catan $29.990
    fireEvent.click(screen.getByRole('button', { name: /^🛒 Carrito/ }))
    expect(screen.getByText(/Descuento LevelUp/).textContent).toContain('5.000')
    expect(screen.getByText(/Total a pagar/).textContent).toContain('24.990') // 29.990 − 5.000

    fireEvent.click(screen.getByText('Proceder al Pago'))
    // V2: solo viajan { productoId, cantidad }; el stock lo descuenta el servidor
    const { enviarPedido } = await import('../servicios/pedidos.js')
    await waitFor(() => expect(ubicacion()).toBe('/perfil')) // tras pagar, useNavigate lleva al perfil
    expect(enviarPedido).toHaveBeenCalledWith([expect.objectContaining({ id: 1, cantidad: 1 })])
    expect(screen.getByText(/Pedido N° 1 · Total pagado: \$24\.990/)).toBeTruthy()
    expect(JSON.parse(localStorage.getItem('usuarioPerfil')).descuento).toBe(0) // el descuento se usó
  })

  it('pagar sin sesión redirige a /login', async () => {
    renderApp('/catalogo')
    await esperarCarga()
    fireEvent.click(screen.getAllByRole('button', { name: 'Añadir al Carrito' })[0])
    fireEvent.click(screen.getByRole('button', { name: /^🛒 Carrito/ }))
    fireEvent.click(screen.getByText('Proceder al Pago'))
    expect(ubicacion()).toBe('/login')
  })

  it('si la API no responde, el catálogo muestra el error y «Reintentar» vuelve a pedirlo', async () => {
    const { listarProductos } = await import('../servicios/productos.js')
    listarProductos.mockRejectedValueOnce(Object.assign(new Error('Network Error'), { request: {} }))
    renderApp('/catalogo')
    expect(await screen.findByText('No pudimos cargar el catálogo')).toBeTruthy()
    expect(screen.getByText(/No hay conexión con el servidor/)).toBeTruthy()
    fireEvent.click(screen.getByRole('button', { name: 'Reintentar' }))
    await esperarCarga()
    expect(screen.getAllByRole('button', { name: 'Ver detalle' }).length).toBe(10)
  })

  it('el inicio ("/") muestra las recomendaciones', async () => {
    renderApp('/')
    expect(screen.getByText('Recomendado para ti')).toBeTruthy()
  })


  it('con sesión, el check-in en un evento suma puntos al usuario', async () => {
    localStorage.setItem('usuarioPerfil', JSON.stringify(usuarioAna))
    localStorage.setItem('sesionIniciada', 'true')
    renderApp('/eventos')
    await esperarCarga() // los eventos llegan desde la API
    // se toma un evento que siga vigente (no depende de la fecha en que se corran las pruebas)
    const boton = screen.getAllByRole('button', { name: /Check-In/ }).find((b) => !b.disabled)
    fireEvent.click(boton)
    expect(screen.getByText(/Check-in realizado/)).toBeTruthy()
    expect(JSON.parse(localStorage.getItem('usuarioPerfil')).puntos).toBeGreaterThan(usuarioAna.puntos)
  })
})

describe('Pedidos contra la API (V2)', () => {
  it('si falta stock (409) muestra el mensaje del servidor y NO vacía el carrito', async () => {
    localStorage.setItem('usuarioPerfil', JSON.stringify(usuarioAna))
    localStorage.setItem('sesionIniciada', 'true')
    localStorage.setItem('carrito-levelup', JSON.stringify([{ id: 5, cantidad: 2 }]))
    const { enviarPedido } = await import('../servicios/pedidos.js')
    const mensaje = 'No hay stock suficiente de «PlayStation 5»: quedan 1 unidades.'
    enviarPedido.mockRejectedValueOnce(
      Object.assign(new Error('409'), { response: { status: 409, data: { status: 409, mensaje, campos: {} } } }),
    )
    renderApp('/')
    fireEvent.click(screen.getByRole('button', { name: /^🛒 Carrito/ }))
    fireEvent.click(screen.getByText('Proceder al Pago'))
    expect(await screen.findByText(mensaje)).toBeTruthy()
    expect(JSON.parse(localStorage.getItem('carrito-levelup'))).toEqual([{ id: 5, cantidad: 2 }])
    expect(ubicacion()).toBe('/')
  })

  it('mientras se envía, el botón dice «Procesando pago…» y queda bloqueado', async () => {
    localStorage.setItem('usuarioPerfil', JSON.stringify(usuarioAna))
    localStorage.setItem('sesionIniciada', 'true')
    localStorage.setItem('carrito-levelup', JSON.stringify([{ id: 1, cantidad: 1 }]))
    const { enviarPedido } = await import('../servicios/pedidos.js')
    let responder
    enviarPedido.mockImplementationOnce(() => new Promise((resolver) => (responder = resolver)))
    renderApp('/')
    fireEvent.click(screen.getByRole('button', { name: /^🛒 Carrito/ }))
    fireEvent.click(screen.getByText('Proceder al Pago'))
    const boton = await screen.findByRole('button', { name: /Procesando pago/ })
    expect(boton.disabled).toBe(true)
    fireEvent.click(boton) // el doble clic no envía otro pedido
    expect(enviarPedido).toHaveBeenCalledTimes(1)
    responder({ id: 7, unidades: 1, total: 29990 })
    await waitFor(() => expect(ubicacion()).toBe('/perfil'))
  })
})
