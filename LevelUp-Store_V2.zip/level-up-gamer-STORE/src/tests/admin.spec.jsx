// Pruebas del panel de administración (V2): listado, eliminar, crear con errores 400 y editar.
// La capa de servicios está simulada en configuracion.js.
import { screen, fireEvent, within, waitFor } from '@testing-library/react'
import { renderApp, esperarCarga } from './ayudas-router.jsx'
import * as servicio from '../servicios/productos.js'

const ubicacion = () => screen.getByTestId('ubicacion').textContent
const escribir = (etiqueta, valor) => fireEvent.change(screen.getByLabelText(etiqueta), { target: { value: valor } })

describe('Panel de administración', () => {
  it('el menú tiene el enlace «Administrar» que lleva a /admin', () => {
    const { container } = renderApp('/')
    fireEvent.click(within(container.querySelector('header')).getByRole('link', { name: 'Administrar' }))
    expect(ubicacion()).toBe('/admin')
  })

  it('lista los productos de la API con Editar y Eliminar', async () => {
    renderApp('/admin')
    await esperarCarga()
    expect(screen.getByText('Inventario (10)')).toBeTruthy()
    expect(screen.getAllByRole('button', { name: /^Eliminar / })).toHaveLength(10)
    expect(screen.getByRole('button', { name: 'Editar Catan' }).getAttribute('href')).toBe('/admin/editar/1')
  })

  it('eliminar pide confirmación, llama a la API y quita la fila', async () => {
    vi.spyOn(window, 'confirm').mockReturnValue(true)
    servicio.eliminarProducto.mockResolvedValueOnce()
    renderApp('/admin')
    await esperarCarga()
    fireEvent.click(screen.getByRole('button', { name: 'Eliminar Catan' }))
    expect(await screen.findByText('Se eliminó «Catan».')).toBeTruthy()
    expect(servicio.eliminarProducto).toHaveBeenCalledWith(1)
    expect(screen.queryByRole('button', { name: 'Eliminar Catan' })).toBeNull()
  })

  it('si se cancela la confirmación no se elimina nada', async () => {
    vi.spyOn(window, 'confirm').mockReturnValue(false)
    renderApp('/admin')
    await esperarCarga()
    fireEvent.click(screen.getByRole('button', { name: 'Eliminar Catan' }))
    expect(servicio.eliminarProducto).not.toHaveBeenCalled()
  })

  it('un 400 de la API marca cada campo con su mensaje', async () => {
    const campos = { nombre: 'El nombre es obligatorio', precio: 'El precio debe ser mayor que cero' }
    servicio.crearProducto.mockRejectedValueOnce(
      Object.assign(new Error('400'), {
        response: { status: 400, data: { status: 400, mensaje: 'Revisa los datos marcados', campos } },
      }),
    )
    renderApp('/admin/nuevo')
    fireEvent.click(screen.getByRole('button', { name: 'Crear producto' }))
    expect(await screen.findByText('Revisa los datos marcados')).toBeTruthy()
    expect(screen.getByText('El nombre es obligatorio')).toBeTruthy()
    expect(screen.getByText('El precio debe ser mayor que cero')).toBeTruthy()
    expect(screen.getByLabelText('Nombre').classList.contains('is-invalid')).toBe(true)
    expect(screen.getByLabelText('Stock').classList.contains('is-invalid')).toBe(false)
  })

  it('crear envía números como números y vuelve al listado con el aviso', async () => {
    servicio.crearProducto.mockImplementationOnce(async (p) => ({ id: 11, ...p }))
    renderApp('/admin/nuevo')
    escribir('Código', 'jm003')
    escribir('Nombre', 'Dixit')
    escribir('Categoría', 'Juegos de Mesa')
    escribir('Precio (CLP)', '27990')
    escribir('Stock', '6')
    escribir('Descripción', 'Juego de cartas ilustradas.')
    fireEvent.click(screen.getByRole('button', { name: 'Crear producto' }))
    await waitFor(() => expect(ubicacion()).toBe('/admin'))
    expect(servicio.crearProducto).toHaveBeenCalledWith(
      expect.objectContaining({ codigo: 'JM003', nombre: 'Dixit', precio: 27990, stock: 6 }),
    )
    expect(await screen.findByText('Se guardó «Dixit».')).toBeTruthy()
  })

  it('editar carga el producto (con el nombre del archivo de imagen) y guarda con PUT', async () => {
    servicio.actualizarProducto.mockImplementationOnce(async (id, p) => ({ id: Number(id), ...p }))
    renderApp('/admin/editar/1')
    await esperarCarga()
    expect(screen.getByLabelText('Código').value).toBe('JM001')
    expect(screen.getByLabelText('Precio (CLP)').value).toBe('29990')
    escribir('Precio (CLP)', '25990')
    fireEvent.click(screen.getByRole('button', { name: 'Guardar cambios' }))
    await waitFor(() => expect(ubicacion()).toBe('/admin'))
    expect(servicio.actualizarProducto).toHaveBeenCalledWith('1', expect.objectContaining({ precio: 25990 }))
  })
})

describe('Eventos desde la API', () => {
  it('si la API falla muestra el error y «Reintentar» vuelve a pedirlos', async () => {
    const { listarEventos } = await import('../servicios/eventos.js')
    listarEventos.mockRejectedValueOnce(Object.assign(new Error('Network Error'), { request: {} }))
    renderApp('/eventos')
    expect(await screen.findByText('No pudimos cargar los eventos')).toBeTruthy()
    fireEvent.click(screen.getByRole('button', { name: 'Reintentar' }))
    await esperarCarga()
    expect(screen.getAllByRole('button', { name: /Check-In|Evento finalizado/ })).toHaveLength(6)
  })
})
