import { useEffect, useState } from 'react'
import { Link, useLocation } from 'react-router'
import { Container, Table, Button, Alert, Spinner } from 'react-bootstrap'

import Portada from '../componentes/Portada.jsx'
import { formatearPrecio } from '../utils/formato.js'
import { mensajeDeError } from '../servicios/errores.js'
import { eliminarProducto, listarProductos } from '../servicios/productos.js'

// Panel de administración: la "R" y la "D" del CRUD. La "C" y la "U" están en FormularioProducto.
// En la V3 esta ruta quedará solo para usuarios con rol ADMIN.
function AdminProductos({ onCatalogoCambiado = () => {} }) {
  // si venimos del formulario, trae un aviso en el state de la navegación
  const ubicacion = useLocation()
  const [aviso, setAviso] = useState(ubicacion.state?.aviso ?? null)

  const [productos, setProductos] = useState([])
  const [cargando, setCargando] = useState(true)
  const [error, setError] = useState(null)
  const [intento, setIntento] = useState(0)

  useEffect(() => {
    let ignorar = false

    async function cargar() {
      setCargando(true)
      setError(null)
      try {
        const datos = await listarProductos()
        if (!ignorar) setProductos(datos)
      } catch (e) {
        if (!ignorar) setError(mensajeDeError(e))
      } finally {
        if (!ignorar) setCargando(false)
      }
    }

    cargar()
    return () => {
      ignorar = true
    }
  }, [intento])

  async function eliminar(producto) {
    if (!window.confirm(`¿Eliminar «${producto.nombre}»? No se puede deshacer.`)) return

    try {
      await eliminarProducto(producto.id)
      // la API respondió 204: se quita de la tabla sin volver a pedir la lista
      setProductos((actual) => actual.filter((p) => p.id !== producto.id))
      setAviso(`Se eliminó «${producto.nombre}».`)
      onCatalogoCambiado()
    } catch (e) {
      setError(mensajeDeError(e))
    }
  }

  return (
    <>
      <Portada
        titulo="Panel de Administración"
        texto="Crea, edita y elimina los productos del catálogo oficial. Los cambios se guardan en la API y se ven al instante en la tienda."
      />

      <Container className="contenedor">
        <section className="panel">
          <div className="d-flex flex-column flex-sm-row justify-content-between align-items-sm-center gap-2 mb-3">
            <h2 className="titulo-admin mb-0">Inventario ({productos.length})</h2>
            <Button as={Link} to="/admin/nuevo" variant="primary">
              + Nuevo producto
            </Button>
          </div>

          {aviso && (
            <Alert variant="success" dismissible onClose={() => setAviso(null)}>
              {aviso}
            </Alert>
          )}

          {cargando ? (
            <div className="text-center py-5">
              <Spinner animation="border" role="status" />
              <p className="resumen-busqueda mt-2">Cargando productos…</p>
            </div>
          ) : error ? (
            <Alert variant="danger">
              <p>{error}</p>
              <Button variant="outline-danger" onClick={() => setIntento((n) => n + 1)}>
                Reintentar
              </Button>
            </Alert>
          ) : (
            <Table responsive hover className="tabla-admin align-middle mb-0">
              <thead>
                <tr>
                  <th>Producto</th>
                  <th>Categoría</th>
                  <th className="text-end">Precio</th>
                  <th className="text-end">Stock</th>
                  <th className="text-end">Acciones</th>
                </tr>
              </thead>
              <tbody>
                {productos.map((producto) => (
                  <tr key={producto.id}>
                    <td>
                      <div className="d-flex align-items-center gap-2">
                        <img src={producto.imagen} alt="" className="miniatura-admin" />
                        <div>
                          <div>{producto.nombre}</div>
                          <small className="text-secondary">{producto.codigo}</small>
                        </div>
                      </div>
                    </td>
                    <td>{producto.categoria}</td>
                    <td className="text-end text-nowrap">{formatearPrecio(producto.precio)}</td>
                    <td className={`text-end estado-stock ${producto.stock > 0 ? 'disponible' : 'agotado'}`}>
                      {producto.stock}
                    </td>
                    <td className="text-end text-nowrap">
                      <Button
                        as={Link}
                        to={`/admin/editar/${producto.id}`}
                        size="sm"
                        variant="outline-primary"
                        className="me-2"
                        aria-label={`Editar ${producto.nombre}`}
                      >
                        Editar
                      </Button>
                      <Button
                        size="sm"
                        variant="outline-danger"
                        aria-label={`Eliminar ${producto.nombre}`}
                        onClick={() => eliminar(producto)}
                      >
                        Eliminar
                      </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </Table>
          )}
        </section>
      </Container>
    </>
  )
}

export default AdminProductos
