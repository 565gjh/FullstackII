import { useEffect, useState } from 'react'
import { Container, Row, Col, Ratio, Alert, Button, Spinner } from 'react-bootstrap'

import Portada from '../componentes/Portada.jsx'
import TarjetaEvento from '../componentes/TarjetaEvento.jsx'
import { listarEventos } from '../servicios/eventos.js'
import { mensajeDeError } from '../servicios/errores.js'

// Eventos: tarjetas del radar y video. El check-in lo maneja App (ahí se guardan los puntos).
// V2: los eventos llegan desde la API (GET /api/eventos).
function Eventos({ onCheckIn }) {
  const [eventos, setEventos] = useState([])
  const [cargando, setCargando] = useState(true)
  const [error, setError] = useState(null)
  const [intento, setIntento] = useState(0) // sube en 1 para "Reintentar"

  useEffect(() => {
    let ignorar = false

    async function cargar() {
      setCargando(true)
      setError(null)
      try {
        const datos = await listarEventos()
        if (!ignorar) setEventos(datos)
      } catch (e) {
        if (!ignorar) setError(mensajeDeError(e))
      } finally {
        if (!ignorar) setCargando(false)
      }
    }

    cargar()
    return () => {
      ignorar = true
    }
  }, [intento])

  return (
    <>
      <Portada
        titulo="Mapa y Ubicaciones de Eventos Gamer"
        texto="Descubre torneos, encuentros de eSports y ferias tecnológicas presenciales a nivel nacional. Haz check-in en los eventos para ganar puntos LevelUp."
      />

      <Container className="contenedor">
        <section className="panel">
          <h2>Radar Nacional de Eventos</h2>
          <p>
            Haz clic en el botón de check-in de cada ubicación para confirmar tu asistencia y
            sumar +Puntos LevelUp a tu perfil.
          </p>
          <p className="text-primary fw-medium">📍 Chile - Red de Puntos Oficiales Level-Up</p>

          {cargando ? (
            <div className="text-center py-5">
              <Spinner animation="border" role="status" />
              <p className="resumen-busqueda mt-2">Cargando eventos…</p>
            </div>
          ) : error ? (
            <Alert variant="danger">
              <Alert.Heading as="h3" className="h5">
                No pudimos cargar los eventos
              </Alert.Heading>
              <p>{error}</p>
              <Button variant="outline-danger" onClick={() => setIntento((n) => n + 1)}>
                Reintentar
              </Button>
            </Alert>
          ) : (
            <Row xs={1} md={2} lg={3} className="g-3">
              {eventos.map((evento) => (
                <Col key={evento.id}>
                  <TarjetaEvento evento={evento} onCheckIn={onCheckIn} />
                </Col>
              ))}
            </Row>
          )}
        </section>

        <section className="panel">
          <h2>Revive The Game Awards 2025</h2>
          <p>
            Mientras se acerca la edición 2026, repasa la transmisión oficial del año pasado,
            donde Clair Obscur: Expedition 33 se llevó el Juego del Año.
          </p>
          {/* Ratio mantiene el 16:9 */}
          <Ratio aspectRatio="16x9" className="video-evento">
            <iframe
              src="https://www.youtube.com/embed/d-BDeU3R5ic"
              title="The Game Awards 2025 - Transmisión Oficial"
              loading="lazy"
              allowFullScreen
            />
          </Ratio>
        </section>
      </Container>
    </>
  )
}

export default Eventos
