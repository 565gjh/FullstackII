import { useEffect, useState } from 'react'
import { Link, useNavigate, useParams } from 'react-router'
import { Container, Row, Col, Form, Button, Alert, Spinner } from 'react-bootstrap'

import { CATEGORIAS } from '../hooks/useFiltroCatalogo.js'
import { mensajeDeError } from '../servicios/errores.js'
import { IMAGENES_DISPONIBLES, resolverImagen } from '../servicios/imagenes.js'
import { actualizarProducto, crearProducto, obtenerProducto } from '../servicios/productos.js'

const FORMULARIO_VACIO = {
  codigo: '',
  nombre: '',
  categoria: '',
  precio: '',
  stock: '',
  imagen: '',
  descripcion: '',
  fabricante: '',
  distribuidor: '',
}

// Un solo formulario para crear (/admin/nuevo) y editar (/admin/editar/:id).
// noValidate: valida el servidor, y su 400 trae un mensaje por campo que se muestra bajo cada input.
function FormularioProducto({ categorias = CATEGORIAS, onCatalogoCambiado = () => {} }) {
  const { id } = useParams()
  const esEdicion = id !== undefined
  const navegar = useNavigate()

  const [datos, setDatos] = useState(FORMULARIO_VACIO)
  const [cargando, setCargando] = useState(esEdicion)
  const [guardando, setGuardando] = useState(false)
  const [error, setError] = useState(null)
  const [erroresCampos, setErroresCampos] = useState({}) // { precio: 'El precio debe…' }

  // al editar, primero se trae el producto y se llena el formulario
  useEffect(() => {
    if (!esEdicion) return
    let ignorar = false

    async function cargar() {
      try {
        const producto = await obtenerProducto(id)
        // los inputs trabajan con texto: los números se pasan a String
        if (!ignorar) {
          setDatos({
            codigo: producto.codigo ?? '',
            nombre: producto.nombre ?? '',
            categoria: producto.categoria ?? '',
            precio: String(producto.precio ?? ''),
            stock: String(producto.stock ?? ''),
            imagen: producto.archivoImagen ?? '',
            descripcion: producto.descripcion ?? '',
            fabricante: producto.fabricante ?? '',
            distribuidor: producto.distribuidor ?? '',
          })
        }
      } catch (e) {
        if (!ignorar) setError(mensajeDeError(e))
      } finally {
        if (!ignorar) setCargando(false)
      }
    }

    cargar()
    return () => {
      ignorar = true
    }
  }, [id, esEdicion])

  function alEscribir(evento) {
    const { name, value } = evento.target
    setDatos((actual) => ({ ...actual, [name]: value }))
  }

  async function alGuardar(evento) {
    evento.preventDefault()
    setGuardando(true)
    setError(null)
    setErroresCampos({})

    // números como números; vacío viaja como null para que Spring diga "es obligatorio"
    const producto = {
      ...datos,
      codigo: datos.codigo.trim().toUpperCase(),
      precio: datos.precio === '' ? null : Number(datos.precio),
      stock: datos.stock === '' ? null : Number(datos.stock),
    }

    try {
      const guardado = esEdicion ? await actualizarProducto(id, producto) : await crearProducto(producto)
      onCatalogoCambiado()
      navegar('/admin', { state: { aviso: `Se guardó «${guardado.nombre}».` } })
    } catch (e) {
      setError(mensajeDeError(e))
      const estado = e.response?.status
      // 400: un mensaje por campo · 409: el código ya existe
      if (estado === 400) setErroresCampos(e.response.data?.campos ?? {})
      if (estado === 409) setErroresCampos({ codigo: e.response.data?.mensaje })
    } finally {
      setGuardando(false)
    }
  }

  // props comunes de cada input: valor, cambio y marca roja si el servidor lo rechazó
  const campo = (nombre) => ({
    name: nombre,
    value: datos[nombre],
    onChange: alEscribir,
    isInvalid: Boolean(erroresCampos[nombre]),
  })
  const mensaje = (nombre) => (
    <Form.Control.Feedback type="invalid">{erroresCampos[nombre]}</Form.Control.Feedback>
  )

  if (cargando) {
    return (
      <Container className="contenedor py-4">
        <div className="text-center py-5">
          <Spinner animation="border" role="status" />
          <p className="mt-2">Cargando producto…</p>
        </div>
      </Container>
    )
  }

  return (
    <Container className="contenedor py-4">
      <Button as={Link} to="/admin" variant="link" className="p-0 mb-3">
        ← Volver al panel
      </Button>

      <section className="panel">
        <h1 className="titulo-admin mb-4">{esEdicion ? 'Editar producto' : 'Nuevo producto'}</h1>

        {error && <Alert variant="danger">{error}</Alert>}

        <Form noValidate onSubmit={alGuardar}>
          <Row className="g-3">
            <Col xs={12} md={3}>
              <Form.Group controlId="codigo">
                <Form.Label>Código</Form.Label>
                <Form.Control {...campo('codigo')} placeholder="JM003" />
                {mensaje('codigo')}
              </Form.Group>
            </Col>
            <Col xs={12} md={9}>
              <Form.Group controlId="nombre">
                <Form.Label>Nombre</Form.Label>
                <Form.Control {...campo('nombre')} />
                {mensaje('nombre')}
              </Form.Group>
            </Col>

            <Col xs={12} md={4}>
              <Form.Group controlId="categoria">
                <Form.Label>Categoría</Form.Label>
                <Form.Control {...campo('categoria')} list="lista-categorias" placeholder="Elige o escribe una" />
                <datalist id="lista-categorias">
                  {categorias.map((categoria) => (
                    <option key={categoria} value={categoria} />
                  ))}
                </datalist>
                {mensaje('categoria')}
              </Form.Group>
            </Col>
            <Col xs={6} md={4}>
              <Form.Group controlId="precio">
                <Form.Label>Precio (CLP)</Form.Label>
                <Form.Control {...campo('precio')} type="number" min="1" />
                {mensaje('precio')}
              </Form.Group>
            </Col>
            <Col xs={6} md={4}>
              <Form.Group controlId="stock">
                <Form.Label>Stock</Form.Label>
                <Form.Control {...campo('stock')} type="number" min="0" />
                {mensaje('stock')}
              </Form.Group>
            </Col>

            <Col xs={12} md={6}>
              <Form.Group controlId="fabricante">
                <Form.Label>Fabricante</Form.Label>
                <Form.Control {...campo('fabricante')} />
                {mensaje('fabricante')}
              </Form.Group>
            </Col>
            <Col xs={12} md={6}>
              <Form.Group controlId="distribuidor">
                <Form.Label>Distribuidor</Form.Label>
                <Form.Control {...campo('distribuidor')} />
                {mensaje('distribuidor')}
              </Form.Group>
            </Col>

            <Col xs={12} md={8}>
              <Form.Group controlId="imagen">
                <Form.Label>Imagen</Form.Label>
                <Form.Control {...campo('imagen')} list="lista-imagenes" placeholder="catannew.png o https://…" />
                <datalist id="lista-imagenes">
                  {IMAGENES_DISPONIBLES.map((archivo) => (
                    <option key={archivo} value={archivo} />
                  ))}
                </datalist>
                <Form.Text className="text-secondary">
                  Nombre de un archivo de <code>src/assets</code> o una URL completa.
                </Form.Text>
                {mensaje('imagen')}
              </Form.Group>
            </Col>
            <Col xs={12} md={4} className="text-center">
              <img
                src={resolverImagen(datos.imagen)}
                alt="Vista previa de la imagen"
                className="img-fluid rounded vista-previa-imagen"
              />
            </Col>

            <Col xs={12}>
              <Form.Group controlId="descripcion">
                <Form.Label>Descripción</Form.Label>
                <Form.Control {...campo('descripcion')} as="textarea" rows={3} />
                {mensaje('descripcion')}
              </Form.Group>
            </Col>
          </Row>

          <div className="d-flex gap-2 mt-4">
            <Button type="submit" variant="primary" disabled={guardando}>
              {guardando ? 'Guardando…' : esEdicion ? 'Guardar cambios' : 'Crear producto'}
            </Button>
            <Button as={Link} to="/admin" variant="outline-secondary">
              Cancelar
            </Button>
          </div>
        </Form>
      </section>
    </Container>
  )
}

export default FormularioProducto
