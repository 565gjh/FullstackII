import { useState } from 'react'
import { Link } from 'react-router'
import { Offcanvas, ListGroup, Button, Alert, Spinner } from 'react-bootstrap'
import { formatearPrecio } from '../utils/formato.js'
import { calcularTotales } from '../utils/precios.js'
import { enviarPedido } from '../servicios/pedidos.js'
import { mensajeDeError } from '../servicios/errores.js'

// Panel lateral del carrito. Los cambios de cantidades los hace App con las funciones que recibe.
// V2: «Proceder al Pago» envía el pedido real a la API (POST /api/pedidos).
function Carrito({
  mostrar,
  onCerrar,
  items,
  descuentoDisponible = 0,
  onCambiarCantidad,
  onQuitar,
  onVaciar,
  sesionIniciada = false,
  onRequiereSesion = () => {},
  onPedidoConfirmado = () => {},
  onStockDesactualizado = () => {},
}) {
  const [enviando, setEnviando] = useState(false) // evita el doble clic
  const [error, setError] = useState(null)

  // los totales se calculan, no se guardan
  const { subtotal, descuentoAplicado, total } = calcularTotales(items, descuentoDisponible)
  const descuentoRestante = descuentoDisponible - descuentoAplicado

  function cerrar() {
    setError(null)
    onCerrar()
  }

  // Un clic dispara la petición: va en el manejador, no en un useEffect.
  async function pagar() {
    if (!sesionIniciada) {
      onRequiereSesion()
      return
    }
    setEnviando(true)
    setError(null)
    try {
      const pedido = await enviarPedido(items)
      onPedidoConfirmado(pedido)
    } catch (e) {
      // 409: falta stock. El carrito NO se vacía; se refresca el stock para ajustarlo.
      setError(mensajeDeError(e))
      if (e.response?.status === 409 || e.response?.status === 404) onStockDesactualizado()
    } finally {
      setEnviando(false)
    }
  }

  return (
    <Offcanvas show={mostrar} onHide={cerrar} placement="end">
      <Offcanvas.Header closeButton closeVariant="white">
        <Offcanvas.Title as="h2" className="fs-5">
          🛒 Tu carrito
        </Offcanvas.Title>
      </Offcanvas.Header>
      <Offcanvas.Body className="d-flex flex-column">
        {items.length === 0 ? (
          <div className="carrito-vacio">
            <p>Tu carrito se encuentra vacío actualmente.</p>
            <Button as={Link} variant="primary" to="/catalogo" onClick={cerrar}>
              Explorar catálogo
            </Button>
          </div>
        ) : (
          <>
            {error && (
              <Alert variant="danger" dismissible onClose={() => setError(null)}>
                {error}
              </Alert>
            )}
            <ListGroup className="mb-3">
              {items.map((item) => (
                <ListGroup.Item key={item.id} className="item-carrito">
                  <img src={item.imagen} alt="" className="item-carrito-imagen" />
                  <div className="flex-grow-1">
                    <div className="item-carrito-nombre">{item.nombre}</div>
                    <small className="precio-unitario">{formatearPrecio(item.precio)} c/u</small>
                    {/* ya lleva todo el stock */}
                    {item.cantidad >= item.stock && (
                      <small className="aviso-maximo">Máximo disponible</small>
                    )}
                    <div className="d-flex align-items-center gap-2 mt-2">
                      <Button
                        size="sm"
                        variant="outline-secondary"
                        aria-label={`Restar una unidad de ${item.nombre}`}
                        onClick={() => onCambiarCantidad(item.id, -1)}
                      >
                        −
                      </Button>
                      <span className="cantidad-item" aria-label={`Cantidad: ${item.cantidad}`}>
                        {item.cantidad}
                      </span>
                      <Button
                        size="sm"
                        variant="outline-secondary"
                        aria-label={`Sumar una unidad de ${item.nombre}`}
                        disabled={item.cantidad >= item.stock} // no se puede superar el stock
                        onClick={() => onCambiarCantidad(item.id, 1)}
                      >
                        +
                      </Button>
                      <strong className="ms-auto subtotal-item">
                        {formatearPrecio(item.precio * item.cantidad)}
                      </strong>
                    </div>
                  </div>
                  <Button
                    size="sm"
                    variant="link"
                    className="text-danger align-self-start"
                    aria-label={`Quitar ${item.nombre} del carrito`}
                    onClick={() => onQuitar(item.id)}
                  >
                    ✕
                  </Button>
                </ListGroup.Item>
              ))}
            </ListGroup>

            <div className="resumen-carrito mt-auto">
              {/* solo se muestra el detalle cuando hay un descuento canjeado */}
              {descuentoAplicado > 0 && (
                <div className="detalle-descuento">
                  <p>
                    Subtotal: <span>{formatearPrecio(subtotal)}</span>
                  </p>
                  <p className="linea-descuento">
                    Descuento LevelUp: <span>−{formatearPrecio(descuentoAplicado)}</span>
                  </p>
                  {descuentoRestante > 0 && (
                    <small>Te quedan {formatearPrecio(descuentoRestante)} de descuento para otra compra.</small>
                  )}
                </div>
              )}
              <p className="total-carrito">
                Total a pagar: <strong>{formatearPrecio(total)}</strong>
              </p>
              <div className="d-grid gap-2">
                <Button variant="primary" onClick={pagar} disabled={enviando}>
                  {enviando ? (
                    <>
                      <Spinner size="sm" animation="border" className="me-2" aria-hidden="true" />
                      Procesando pago…
                    </>
                  ) : (
                    'Proceder al Pago'
                  )}
                </Button>
                <Button variant="outline-secondary" onClick={cerrar}>
                  ← Seguir comprando
                </Button>
                <Button variant="link" className="text-danger" onClick={onVaciar} disabled={enviando}>
                  Vaciar carrito
                </Button>
              </div>
            </div>
          </>
        )}
      </Offcanvas.Body>
    </Offcanvas>
  )
}

export default Carrito
