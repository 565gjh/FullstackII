package com.example.levelup_api;

import static org.hamcrest.Matchers.hasSize;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.transaction.annotation.Transactional;

// Pruebas de los endpoints contra H2; cada test deshace sus cambios
@SpringBootTest
@AutoConfigureMockMvc
@Transactional
class ApiIntegrationTests {

    @Autowired
    private MockMvc mvc;

    private String pedido(long productoId, int cantidad) {
        return "{\"lineas\":[{\"productoId\":" + productoId + ",\"cantidad\":" + cantidad + "}]}";
    }

    @Test
    void listaLosDiezProductos() throws Exception {
        mvc.perform(get("/api/productos")).andExpect(status().isOk()).andExpect(jsonPath("$", hasSize(10)));
    }

    @Test
    void productoInexistenteResponde404ConElContrato() throws Exception {
        mvc.perform(get("/api/productos/999"))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.status").value(404))
                .andExpect(jsonPath("$.mensaje").value("No existe el producto 999"));
    }

    @Test
    void pedidoValidoDescuentaStockYCalculaElTotal() throws Exception {
        // PS5: 549.900 y 3 unidades
        mvc.perform(post("/api/pedidos").contentType(MediaType.APPLICATION_JSON).content(pedido(5, 2)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.unidades").value(2))
                .andExpect(jsonPath("$.total").value(1099800))
                .andExpect(jsonPath("$.detalles[0].precioUnitario").value(549900));
        mvc.perform(get("/api/productos/5")).andExpect(jsonPath("$.stock").value(1));
    }

    @Test
    void pedidoSinStockResponde409YNoDescuenta() throws Exception {
        mvc.perform(post("/api/pedidos").contentType(MediaType.APPLICATION_JSON).content(pedido(5, 4)))
                .andExpect(status().isConflict())
                .andExpect(jsonPath("$.mensaje").value("No hay stock suficiente de «PlayStation 5»: quedan 3 unidades."));
        mvc.perform(get("/api/productos/5")).andExpect(jsonPath("$.stock").value(3));
    }

    @Test
    void pedidoVacioResponde400() throws Exception {
        mvc.perform(post("/api/pedidos").contentType(MediaType.APPLICATION_JSON).content("{\"lineas\":[]}"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.campos.lineas").value("El pedido no tiene productos"));
    }

    @Test
    void listaLosSeisEventos() throws Exception {
        mvc.perform(get("/api/eventos"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(6)))
                .andExpect(jsonPath("$[0].fechaFin").value("2026-12-10"));
    }
}
