package com.example.levelup_api.controller;

import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.levelup_api.model.Evento;
import com.example.levelup_api.service.EventoService;

// Eventos del radar gamer
@RestController
@RequestMapping("/api/eventos")
public class EventoController {

    private final EventoService servicio;

    public EventoController(EventoService servicio) {
        this.servicio = servicio;
    }

    @GetMapping
    public List<Evento> listar() {
        return servicio.listar();
    }

    @GetMapping("/{id}")
    public Evento obtener(@PathVariable Long id) {
        return servicio.buscar(id);
    }
}
