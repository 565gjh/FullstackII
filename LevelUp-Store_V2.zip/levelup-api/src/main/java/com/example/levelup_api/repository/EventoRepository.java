package com.example.levelup_api.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.levelup_api.model.Evento;

public interface EventoRepository extends JpaRepository<Evento, Long> {
}
