package com.example.levelup_api.config;

import java.time.LocalDate;
import java.util.List;

import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.example.levelup_api.model.Evento;
import com.example.levelup_api.model.Producto;
import com.example.levelup_api.repository.EventoRepository;
import com.example.levelup_api.repository.ProductoRepository;

// Carga los productos y eventos de la tienda al arrancar
@Component
public class DataInitializer implements CommandLineRunner {

    private final ProductoRepository repositorio;
    private final EventoRepository eventos;

    public DataInitializer(ProductoRepository repositorio, EventoRepository eventos) {
        this.repositorio = repositorio;
        this.eventos = eventos;
    }

    @Override
    public void run(String... args) {
        cargarProductos();
        cargarEventos();
    }

    private void cargarProductos() {
        if (repositorio.count() > 0) {
            return;
        }
        repositorio.saveAll(List.of(
                new Producto("JM001", "Juegos de Mesa", "Catan", 29990, 12, "catannew.png",
                        "Un clásico juego de estrategia donde los jugadores compiten por colonizar y expandirse en la isla de Catan. Ideal para 3-4 jugadores y perfecto para noches de juego en familia o con amigos.",
                        "KOSMOS / Devir", "Devir Chile"),
                new Producto("JM002", "Juegos de Mesa", "Carcassonne", 24990, 8, "images.jpg",
                        "Un juego de colocación de fichas donde los jugadores construyen el paisaje alrededor de la fortaleza medieval de Carcassonne. Ideal para 2-5 jugadores y fácil de aprender.",
                        "Hans im Glück / Devir", "Devir Chile"),
                new Producto("AC001", "Accesorios", "Controlador Inalámbrico Xbox Series X", 59990, 5, "controlxboxsx.png",
                        "Ofrece una experiencia de juego cómoda con botones mapeables y una respuesta táctil mejorada. Compatible con consolas Xbox y PC.",
                        "Microsoft", "Distribuidores Oficiales Latam"),
                new Producto("AC002", "Accesorios", "Auriculares Gamer HyperX Cloud II", 79990, 0, "hyperxcloudii.avif",
                        "Proporcionan un sonido envolvente de calidad con un micrófono desmontable y almohadillas de espuma viscoelástica para mayor comodidad durante largas sesiones de juego.",
                        "HP / HyperX", "HyperX Chile"),
                new Producto("CO001", "Consolas", "PlayStation 5", 549900, 3, "ps5-product.webp",
                        "La consola de última generación de Sony, que ofrece gráficos impresionantes y tiempos de carga ultrarrápidos para una experiencia de juego inmersiva.",
                        "Sony Interactive Entertainment", "Sony Chile / Microplay"),
                new Producto("CG001", "Computadores Gamers", "PC Gamer ASUS ROG Strix", 1299900, 2, "h732.png",
                        "Un potente equipo diseñado para los gamers más exigentes, equipado con los últimos componentes para ofrecer un rendimiento excepcional en cualquier juego.",
                        "ASUS / Republic of Gamers", "ASUS Chile / Ingram Micro"),
                new Producto("SG001", "Sillas Gamers", "Silla Gamer Secretlab Titan", 349900, 4, "teamsecret-titanevo.webp",
                        "Diseñada para el máximo confort, esta silla ofrece un soporte ergonómico y personalización ajustable para sesiones de juego prolongadas.",
                        "Secretlab", "ErgoGamer Corp Latam"),
                new Producto("MS001", "Mouse", "Mouse Gamer Logitech G502 HERO", 49990, 15, "640.webp",
                        "Con sensor de alta precisión y botones personalizables, este mouse es ideal para gamers que buscan un control preciso y personalización.",
                        "Logitech G", "Logitech Chile"),
                new Producto("MP001", "Mousepad", "Mousepad Razer Goliathus Extended Chroma", 29990, 20, "razer67.png",
                        "Ofrece un área de juego amplia con iluminación RGB personalizable, asegurando una superficie suave y uniforme para el movimiento del mouse.",
                        "Razer", "Razer Official Distributor"),
                new Producto("PP001", "Poleras Personalizadas", "Polera Gamer Personalizada 'Level-Up'", 14990, 30, "3041941_01.webp",
                        "Una camiseta cómoda y estilizada, con la posibilidad de personalizarla con tu gamer tag o diseño favorito.",
                        "Level-Up Custom Textiles", "Taller Gráfico Propio (Melipilla)")));
    }

    private void cargarEventos() {
        if (eventos.count() > 0) {
            return;
        }
        eventos.saveAll(List.of(
                new Evento("THE GAME AWARDS 2026 / Transmisión en VIVO", "Peacock Theater en Los Ángeles, California",
                        "Se celebrará oficialmente el jueves 10 de diciembre. Ceremonia de cierre de año para premiar a los mejores videojuegos.",
                        LocalDate.of(2026, 12, 10), 170),
                new Evento("EXPOGAME 2026 / PRESENCIAL", "Centro Cultural Estación Mapocho, Santiago",
                        "Se realizó del 2 al 4 de octubre, con invitados como el streamer El Mariana y el rapero Kblade, además de competencias de esports. Las entradas se adquieren en Puntoticket.",
                        LocalDate.of(2026, 10, 4), 135),
                new Evento("FESTIGAME 2026 / PRESENCIAL", "Movistar Arena, Santiago",
                        "Se celebrará el 25 de octubre, con horario extendido de 10:00 a 00:00 horas. Incluye experiencias de realidad virtual, torneos relámpago, competencias de cosplay y K-pop.",
                        LocalDate.of(2026, 10, 25), 115),
                new Evento("Zona Gamers Bienvenida / PRESENCIAL", "Duoc UC Sede Melipilla - Local Party",
                        "Un punto de encuentro y comunidad diseñado especialmente para los entusiastas de los videojuegos, el hardware y la cultura geek.",
                        null, 100),
                new Evento("CHARLA MAGISTRAL: LA IA COMO MOTOR PROFESIONAL - ONLINE", "Duoc UC Sede Antonio Varas - CITT",
                        "Una conferencia magistral enfocada en cómo la Inteligencia Artificial está transformando el campo laboral y actúa como un motor de desarrollo profesional.",
                        null, 80),
                new Evento("3er Seminario de Competencias Ágiles - PRESENCIAL", "Duoc UC Sede Plaza Norte - CITT",
                        "Un espacio enfocado en el desarrollo, profundización y aplicación de metodologías ágiles en el ámbito profesional y académico.",
                        null, 75)));
    }
}
