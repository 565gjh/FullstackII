package com.example.levelup_api.model;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToMany;

// Una compra confirmada con su detalle
@Entity
public class Pedido {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private LocalDateTime fecha;
    private Integer unidades;
    private Integer total;

    @OneToMany(cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.EAGER)
    @JoinColumn(name = "pedido_id")
    private List<DetallePedido> detalles = new ArrayList<>();

    public Pedido() {
    }

    public Pedido(LocalDateTime fecha, Integer unidades, Integer total, List<DetallePedido> detalles) {
        this.fecha = fecha;
        this.unidades = unidades;
        this.total = total;
        this.detalles = detalles;
    }

    public Long getId() { return id; }
    public LocalDateTime getFecha() { return fecha; }
    public Integer getUnidades() { return unidades; }
    public Integer getTotal() { return total; }
    public List<DetallePedido> getDetalles() { return detalles; }
}
