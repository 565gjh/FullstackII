package com.example.levelup_api.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.levelup_api.model.Pedido;

public interface PedidoRepository extends JpaRepository<Pedido, Long> {
}
