package com.example.levelup_api.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

// Línea del pedido con el precio que tenía el producto al comprar
@Entity
public class DetallePedido {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Long productoId;
    private String codigo;
    private String nombre;
    private Integer cantidad;
    private Integer precioUnitario;
    private Integer subtotal;

    public DetallePedido() {
    }

    public DetallePedido(Producto producto, Integer cantidad) {
        this.productoId = producto.getId();
        this.codigo = producto.getCodigo();
        this.nombre = producto.getNombre();
        this.cantidad = cantidad;
        this.precioUnitario = producto.getPrecio();
        this.subtotal = producto.getPrecio() * cantidad;
    }

    public Long getId() { return id; }
    public Long getProductoId() { return productoId; }
    public String getCodigo() { return codigo; }
    public String getNombre() { return nombre; }
    public Integer getCantidad() { return cantidad; }
    public Integer getPrecioUnitario() { return precioUnitario; }
    public Integer getSubtotal() { return subtotal; }
}
