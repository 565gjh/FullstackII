package com.example.levelup_api.dto;

import java.util.List;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotEmpty;

// Cuerpo de POST /api/pedidos: { "lineas": [ { "productoId": 3, "cantidad": 2 } ] }
public record PedidoRequestDTO(
        @NotEmpty(message = "El pedido no tiene productos") @Valid List<LineaPedidoDTO> lineas) {
}
