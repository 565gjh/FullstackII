package com.example.levelup_api.model;

import java.time.LocalDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

// Evento del radar; sin fechaFin el check-in no vence
@Entity
public class Evento {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String etiqueta;
    private String lugar;

    @Column(length = 500)
    private String descripcion;

    private LocalDate fechaFin;
    private Integer puntos;

    public Evento() {
    }

    public Evento(String etiqueta, String lugar, String descripcion, LocalDate fechaFin, Integer puntos) {
        this.etiqueta = etiqueta;
        this.lugar = lugar;
        this.descripcion = descripcion;
        this.fechaFin = fechaFin;
        this.puntos = puntos;
    }

    public Long getId() { return id; }
    public String getEtiqueta() { return etiqueta; }
    public String getLugar() { return lugar; }
    public String getDescripcion() { return descripcion; }
    public LocalDate getFechaFin() { return fechaFin; }
    public Integer getPuntos() { return puntos; }
}
