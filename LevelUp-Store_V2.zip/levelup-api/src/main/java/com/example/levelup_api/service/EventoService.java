package com.example.levelup_api.service;

import java.util.List;

import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.levelup_api.exception.ResourceNotFoundException;
import com.example.levelup_api.model.Evento;
import com.example.levelup_api.repository.EventoRepository;

@Service
public class EventoService {

    private final EventoRepository repositorio;

    public EventoService(EventoRepository repositorio) {
        this.repositorio = repositorio;
    }

    @Transactional(readOnly = true)
    public List<Evento> listar() {
        return repositorio.findAll(Sort.by("id"));
    }

    @Transactional(readOnly = true)
    public Evento buscar(Long id) {
        return repositorio.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("No existe el evento " + id));
    }
}
