package com.example.levelup_api.service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.levelup_api.dto.LineaPedidoDTO;
import com.example.levelup_api.dto.PedidoRequestDTO;
import com.example.levelup_api.exception.InsufficientStockException;
import com.example.levelup_api.exception.ResourceNotFoundException;
import com.example.levelup_api.model.DetallePedido;
import com.example.levelup_api.model.Pedido;
import com.example.levelup_api.model.Producto;
import com.example.levelup_api.repository.PedidoRepository;
import com.example.levelup_api.repository.ProductoRepository;

@Service
public class PedidoService {

    private final ProductoRepository productos;
    private final PedidoRepository pedidos;

    public PedidoService(ProductoRepository productos, PedidoRepository pedidos) {
        this.productos = productos;
        this.pedidos = pedidos;
    }

    @Transactional(readOnly = true)
    public List<Pedido> listar() {
        return pedidos.findAll(Sort.by("id"));
    }

    // Si una línea falla, no se descuenta el stock de ninguna
    @Transactional
    public Pedido crear(PedidoRequestDTO solicitud) {
        int unidades = 0;
        int total = 0;
        List<DetallePedido> detalles = new ArrayList<>();

        for (LineaPedidoDTO linea : solicitud.lineas()) {
            Producto producto = productos.findById(linea.productoId())
                    .orElseThrow(() -> new ResourceNotFoundException(
                            "No existe el producto " + linea.productoId()));

            if (producto.getStock() < linea.cantidad()) {
                throw new InsufficientStockException("No hay stock suficiente de «" + producto.getNombre()
                        + "»: quedan " + producto.getStock() + " unidades.");
            }

            producto.setStock(producto.getStock() - linea.cantidad());
            DetallePedido detalle = new DetallePedido(producto, linea.cantidad());
            detalles.add(detalle);
            unidades += linea.cantidad();
            // Precio de la base de datos, nunca el del navegador
            total += detalle.getSubtotal();
        }

        return pedidos.save(new Pedido(LocalDateTime.now(), unidades, total, detalles));
    }
}
