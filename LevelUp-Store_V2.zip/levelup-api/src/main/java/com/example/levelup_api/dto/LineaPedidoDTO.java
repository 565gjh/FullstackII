package com.example.levelup_api.dto;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;

// El precio no viaja: lo pone el servidor
public record LineaPedidoDTO(
        @NotNull(message = "Falta el producto") Long productoId,
        @NotNull(message = "Falta la cantidad") @Min(value = 1, message = "La cantidad mínima es 1") Integer cantidad) {
}
