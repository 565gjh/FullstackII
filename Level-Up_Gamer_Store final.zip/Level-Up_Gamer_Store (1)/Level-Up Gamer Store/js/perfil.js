document.addEventListener('DOMContentLoaded', function () {
    // 1. Leemos el local storage
    const sesionIniciada = localStorage.getItem('sesionIniciada');
    const usuario = JSON.parse(localStorage.getItem('usuarioPerfil'));

    // Para ver en la consola si los datos están llegando bien
    console.log("Estado de sesión:", sesionIniciada);
    console.log("Datos del usuario:", usuario);

    // 2. Buscamos los contenedores en el HTML
    const vistaInvitado = document.getElementById('vistaInvitado');
    const vistaUsuario = document.getElementById('vistaUsuario');

    if (!vistaInvitado || !vistaUsuario) {
        console.error("ERROR: No se encontraron los contenedores 'vistaInvitado' o 'vistaUsuario' en tu HTML.");
        return; // El código se detiene aquí si faltan los IDs
    }

    // 3. Mostramos la vista correcta
    if (sesionIniciada === 'true' && usuario) {
        // Ocultar invitado, mostrar usuario
        vistaInvitado.style.display = 'none';
        vistaUsuario.style.display = 'block';

        // Llenar los datos
        document.getElementById('perfilNombre').textContent = usuario.nombre || 'Gamer';
        document.getElementById('perfilCorreo').textContent = usuario.correo || '';
        document.getElementById('perfilNivel').textContent = usuario.nivel || 'Hierro 🛡️';
        
        const puntosElem = document.getElementById('perfilPuntos');
        if (puntosElem) {
            puntosElem.textContent = `${usuario.puntos || 0} Puntos LevelUp`;
        }
    } else {
        // Mostrar invitado, ocultar usuario
        vistaInvitado.style.display = 'block';
        vistaUsuario.style.display = 'none';
    }

    // 4. Botón de Cerrar Sesión
    const btnCerrarSesion = document.getElementById('btnCerrarSesion');
    if (btnCerrarSesion) {
        btnCerrarSesion.addEventListener('click', function () {
            localStorage.setItem('sesionIniciada', 'false');
            window.location.reload();
        });
    }
});